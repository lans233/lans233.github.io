/* 
get-svg-colors-browser v2.0.5
Copyright (c) 2021 Georg Fischer
@license MIT
https://github.com/snorpey/get-svg-colors-browser.git */
var _0x52102f = _0x3451;
(function (_0x2b6f76, _0x4dd6b2) {
    var _0x4357c3 = _0x3451, _0x5d629c = _0x2b6f76();
    while (!![]) {
        try {
            var _0x18a1e6 = parseInt(_0x4357c3(0x3fd)) / 0x1 * (parseInt(_0x4357c3(0x181)) / 0x2) + -parseInt(_0x4357c3(0x16c)) / 0x3 + -parseInt(_0x4357c3(0x404)) / 0x4 * (-parseInt(_0x4357c3(0x26d)) / 0x5) + -parseInt(_0x4357c3(0x3f9)) / 0x6 + -parseInt(_0x4357c3(0x211)) / 0x7 * (parseInt(_0x4357c3(0x660)) / 0x8) + -parseInt(_0x4357c3(0x687)) / 0x9 * (-parseInt(_0x4357c3(0x366)) / 0xa) + parseInt(_0x4357c3(0x4b1)) / 0xb;
            if (_0x18a1e6 === _0x4dd6b2)
                break;
            else
                _0x5d629c['push'](_0x5d629c['shift']());
        } catch (_0x36f630) {
            _0x5d629c['push'](_0x5d629c['shift']());
        }
    }
}(_0x12c6, 0xdfab8), !function (_0x4a8f51, _0x5bfdfc) {
    var _0x551573 = _0x3451, _0x5bfe8d = {
            'HpYwL': function (_0x40dd18, _0x28ba39) {
                return _0x40dd18 == _0x28ba39;
            },
            'tELsY': 'object',
            'XyAKr': function (_0x6a0391, _0x3b6ce4) {
                return _0x6a0391 != _0x3b6ce4;
            },
            'JQKyO': _0x551573(0x3c5),
            'wMwQF': function (_0x411a3a) {
                return _0x411a3a();
            },
            'jMVmP': _0x551573(0x4d0),
            'hwzIf': function (_0x3d1074, _0x4fba7b) {
                return _0x3d1074(_0x4fba7b);
            },
            'aTBaF': function (_0x3ce1af, _0x26ae60) {
                return _0x3ce1af != _0x26ae60;
            },
            'qCyBC': function (_0x1b9e8a, _0x3bb50b) {
                return _0x1b9e8a || _0x3bb50b;
            }
        };
    _0x5bfe8d[_0x551573(0x224)](_0x5bfe8d[_0x551573(0x42d)], typeof exports) && _0x5bfe8d['XyAKr'](_0x5bfe8d[_0x551573(0x5e1)], typeof module) ? module[_0x551573(0x2d2)] = _0x5bfe8d[_0x551573(0x1c7)](_0x5bfdfc) : _0x5bfe8d['HpYwL'](_0x5bfe8d['jMVmP'], typeof define) && define[_0x551573(0x3d7)] ? _0x5bfe8d[_0x551573(0x2d5)](define, _0x5bfdfc) : (_0x4a8f51 = _0x5bfe8d[_0x551573(0x223)](_0x5bfe8d[_0x551573(0x5e1)], typeof globalThis) ? globalThis : _0x5bfe8d[_0x551573(0x202)](_0x4a8f51, self))['getSVGColors'] = _0x5bfdfc();
}(this, function () {
    'use strict';
    var _0x581f64 = _0x3451, _0x47d878 = {
            'mryIv': function (_0x2e0a90, _0x1cbd6e) {
                return _0x2e0a90 === _0x1cbd6e;
            },
            'EVnaG': function (_0x1b3b82, _0x1de2e1) {
                return _0x1b3b82 < _0x1de2e1;
            },
            'IaoWB': function (_0x56cbf7, _0x347840) {
                return _0x56cbf7 !== _0x347840;
            },
            'WQKwW': _0x581f64(0x20a),
            'tGftj': function (_0x34cab4, _0x260294) {
                return _0x34cab4 !== _0x260294;
            },
            'nTckI': function (_0x138742, _0x1dccce) {
                return _0x138742 === _0x1dccce;
            },
            'NJjUF': _0x581f64(0x38f),
            'GzYQk': _0x581f64(0x6aa),
            'NJuJB': function (_0x5e66f2, _0x947572) {
                return _0x5e66f2 + _0x947572;
            },
            'ewIRU': function (_0xc22462, _0x50beee) {
                return _0xc22462 + _0x50beee;
            },
            'ATcLJ': _0x581f64(0x231),
            'bXWPW': function (_0x2fb7d9, _0x34757c) {
                return _0x2fb7d9(_0x34757c);
            },
            'VRxgA': function (_0x3df0dc, _0x1c7927) {
                return _0x3df0dc instanceof _0x1c7927;
            },
            'lLEog': function (_0x4b2468, _0x440431) {
                return _0x4b2468(_0x440431);
            },
            'JeOfB': _0x581f64(0x637),
            'bLWsY': function (_0x2acff6, _0x17ae6e) {
                return _0x2acff6 === _0x17ae6e;
            },
            'ppxBt': _0x581f64(0x5a9),
            'NLUtd': function (_0x1c4595, _0x128d4d, _0x3821f0) {
                return _0x1c4595(_0x128d4d, _0x3821f0);
            },
            'zRvjy': 'stop-color',
            'zoCvr': _0x581f64(0x6ba),
            'xGzpg': _0x581f64(0x568),
            'EaAKM': function (_0x59cbfa, _0x2a9ff3, _0x5be07e) {
                return _0x59cbfa(_0x2a9ff3, _0x5be07e);
            },
            'vhQWL': '[stop-color]',
            'cdAAB': '[style]',
            'tgoXl': function (_0x4b5fe3, _0x3fd0a2, _0x425de0) {
                return _0x4b5fe3(_0x3fd0a2, _0x425de0);
            },
            'ccABq': _0x581f64(0x39b),
            'YUylH': _0x581f64(0x420),
            'mxESP': _0x581f64(0x19a),
            'YiKRq': _0x581f64(0x1f3),
            'ofjZS': _0x581f64(0x45a),
            'nTdeR': _0x581f64(0x4dd),
            'PbBqT': 'maroon',
            'OyoAy': _0x581f64(0x405),
            'VsmqQ': _0x581f64(0x417),
            'xAtrz': _0x581f64(0x15b),
            'HJjYk': 'green',
            'ulzpQ': _0x581f64(0x32b),
            'LEyrd': 'olive',
            'OJTwN': _0x581f64(0x1b5),
            'FoAuk': _0x581f64(0x58d),
            'Ycjjt': _0x581f64(0x495),
            'ydAph': _0x581f64(0x3d8),
            'nOlTy': _0x581f64(0x400),
            'cULDd': _0x581f64(0x6b8),
            'tZVbI': _0x581f64(0x18f),
            'woUAA': _0x581f64(0x5a5),
            'imCGB': _0x581f64(0x30d),
            'PGRdZ': 'brown',
            'yilIL': 'burlywood',
            'DGRVq': _0x581f64(0x3e1),
            'BLYGK': _0x581f64(0x14c),
            'rkRPQ': _0x581f64(0x3ff),
            'kunzH': 'coral',
            'Oofjv': _0x581f64(0x651),
            'UFJED': _0x581f64(0x5dd),
            'XBtMf': _0x581f64(0x29b),
            'MNNWX': _0x581f64(0x180),
            'rKDWt': _0x581f64(0x1a9),
            'WTGOZ': _0x581f64(0x2af),
            'YJiwW': _0x581f64(0x5c3),
            'AulDZ': _0x581f64(0x435),
            'SCwCL': 'darkorchid',
            'wBtdv': _0x581f64(0x55d),
            'JxPYh': _0x581f64(0x148),
            'gItxw': _0x581f64(0x3a9),
            'BqnmV': 'darkslateblue',
            'rsKNu': _0x581f64(0x6bb),
            'EEYyy': _0x581f64(0x5ab),
            'FYtjv': _0x581f64(0x1c3),
            'NiPPh': _0x581f64(0x1e6),
            'nSXgg': _0x581f64(0x1e9),
            'VdMDR': _0x581f64(0x658),
            'IJEBU': 'dimgrey',
            'hJpGb': _0x581f64(0x236),
            'SOUrY': 'floralwhite',
            'RvpFA': _0x581f64(0x45b),
            'YescT': _0x581f64(0x368),
            'DymHD': _0x581f64(0x2e3),
            'JPaAM': _0x581f64(0x516),
            'DnNcz': _0x581f64(0x1e1),
            'YecKb': _0x581f64(0x2ee),
            'wcLnH': _0x581f64(0x5e5),
            'yyvPy': 'lavender',
            'RbWkY': 'lavenderblush',
            'sZLEb': 'lemonchiffon',
            'tFUGE': _0x581f64(0x5d2),
            'UzPxZ': _0x581f64(0x5c9),
            'bCDML': _0x581f64(0x520),
            'YUzOJ': _0x581f64(0x262),
            'TkPQQ': _0x581f64(0x664),
            'mxSsb': _0x581f64(0x670),
            'sRjit': _0x581f64(0x4ca),
            'xQJTL': _0x581f64(0x59f),
            'kIXLE': _0x581f64(0x4ed),
            'Vdave': 'lightskyblue',
            'EcPyq': 'lightslategray',
            'nupKo': _0x581f64(0x397),
            'DyvKo': 'lightsteelblue',
            'nPrxY': 'lightyellow',
            'OWvNG': _0x581f64(0x682),
            'uNdni': 'linen',
            'MyQDJ': _0x581f64(0x2ec),
            'JUMqo': 'mediumaquamarine',
            'PuaQO': _0x581f64(0x64c),
            'YThnE': _0x581f64(0x59b),
            'UjxoP': _0x581f64(0x2da),
            'qMYJF': 'mediumspringgreen',
            'BNcLk': _0x581f64(0x2f3),
            'LyXVb': 'mediumvioletred',
            'WQlJi': _0x581f64(0x6d7),
            'AGfGe': _0x581f64(0x394),
            'oNgEn': 'oldlace',
            'yhTbk': 'olivedrab',
            'rcpPX': _0x581f64(0x2c3),
            'bqgDw': _0x581f64(0x28c),
            'sAbVF': _0x581f64(0x281),
            'JtJGw': _0x581f64(0x6a9),
            'LPdAM': 'palegreen',
            'IKPaE': _0x581f64(0x466),
            'wngPw': _0x581f64(0x573),
            'jLxTa': 'papayawhip',
            'zSEar': _0x581f64(0x673),
            'Lqfee': _0x581f64(0x238),
            'YqCGO': _0x581f64(0x480),
            'KXSKM': 'powderblue',
            'mlhoY': _0x581f64(0x1df),
            'lAUHT': _0x581f64(0x38a),
            'qoBmF': _0x581f64(0x35e),
            'Pczhk': _0x581f64(0x30a),
            'qjQOm': _0x581f64(0x62c),
            'MfymA': _0x581f64(0x460),
            'cIeBW': _0x581f64(0x20c),
            'HVkbU': _0x581f64(0x50f),
            'LsQBR': _0x581f64(0x475),
            'HUFSO': _0x581f64(0x1f5),
            'KGKLK': _0x581f64(0x66c),
            'AkQiq': _0x581f64(0x207),
            'xfHMT': 'tan',
            'vhfPX': _0x581f64(0x43b),
            'xorjE': 'turquoise',
            'xBnVa': _0x581f64(0x37e),
            'wwCbn': 'wheat',
            'yBKKh': _0x581f64(0x392),
            'qtERi': _0x581f64(0x692),
            'ztTMu': _0x581f64(0x152)
        };
    var _0x51d101 = /<!--([\s\S]*?)-->/g, _0x186a58 = _0x47d878[_0x581f64(0x168)], _0x168a46 = /(#(?:[0-9a-f]{2}){2,4}|(#[0-9a-f]{3})|(rgb|hsl)a?\((-?\d+%?[,\s]+){2,3}\s*[\d\.]+%?\))/i, _0x303b51 = [
            _0x47d878['mxESP'],
            _0x47d878['YiKRq'],
            _0x47d878[_0x581f64(0x5b1)],
            _0x47d878['nTdeR'],
            _0x47d878['PbBqT'],
            _0x47d878['OyoAy'],
            _0x47d878['VsmqQ'],
            _0x47d878[_0x581f64(0x467)],
            _0x47d878[_0x581f64(0x4a4)],
            _0x47d878[_0x581f64(0x6c3)],
            _0x47d878[_0x581f64(0x56e)],
            'yellow',
            _0x47d878[_0x581f64(0x5ad)],
            _0x47d878[_0x581f64(0x267)],
            _0x581f64(0x638),
            _0x581f64(0x400),
            _0x47d878['Ycjjt'],
            _0x47d878[_0x581f64(0x61a)],
            _0x47d878['nOlTy'],
            _0x47d878[_0x581f64(0x3c4)],
            _0x581f64(0x3b9),
            _0x47d878['tZVbI'],
            _0x581f64(0x59a),
            _0x47d878[_0x581f64(0x513)],
            _0x47d878[_0x581f64(0x457)],
            _0x581f64(0x58d),
            _0x47d878['imCGB'],
            _0x47d878[_0x581f64(0x184)],
            _0x47d878[_0x581f64(0x297)],
            _0x47d878[_0x581f64(0x270)],
            _0x47d878[_0x581f64(0x67a)],
            _0x47d878[_0x581f64(0x477)],
            _0x47d878[_0x581f64(0x4e3)],
            _0x581f64(0x65b),
            _0x47d878[_0x581f64(0x577)],
            _0x47d878[_0x581f64(0x185)],
            _0x581f64(0x5da),
            'darkblue',
            _0x47d878[_0x581f64(0x64d)],
            _0x47d878[_0x581f64(0x6b5)],
            _0x47d878['rKDWt'],
            _0x47d878[_0x581f64(0x60d)],
            _0x47d878[_0x581f64(0x2d4)],
            _0x581f64(0x4a3),
            _0x581f64(0x444),
            _0x47d878[_0x581f64(0x646)],
            _0x581f64(0x3f3),
            _0x47d878[_0x581f64(0x2aa)],
            _0x47d878[_0x581f64(0x584)],
            _0x47d878[_0x581f64(0x1eb)],
            _0x47d878['gItxw'],
            _0x47d878['BqnmV'],
            _0x47d878[_0x581f64(0x536)],
            _0x47d878[_0x581f64(0x22e)],
            _0x47d878['FYtjv'],
            _0x47d878[_0x581f64(0x690)],
            _0x47d878[_0x581f64(0x36b)],
            _0x47d878['VdMDR'],
            _0x581f64(0x34c),
            _0x47d878[_0x581f64(0x259)],
            _0x47d878['hJpGb'],
            _0x581f64(0x2cc),
            _0x47d878[_0x581f64(0x1d7)],
            _0x47d878[_0x581f64(0x5eb)],
            _0x47d878[_0x581f64(0x467)],
            _0x581f64(0x354),
            _0x581f64(0x263),
            _0x47d878['YescT'],
            _0x47d878[_0x581f64(0x147)],
            _0x47d878[_0x581f64(0x5b1)],
            _0x47d878['HJjYk'],
            _0x47d878[_0x581f64(0x59d)],
            _0x47d878['DnNcz'],
            _0x47d878['YecKb'],
            _0x581f64(0x533),
            _0x581f64(0x4ac),
            _0x581f64(0x24b),
            _0x47d878[_0x581f64(0x3f1)],
            _0x581f64(0x2bf),
            _0x47d878[_0x581f64(0x430)],
            _0x47d878[_0x581f64(0x648)],
            _0x581f64(0x454),
            _0x47d878[_0x581f64(0x6bd)],
            _0x47d878[_0x581f64(0x554)],
            _0x47d878['UzPxZ'],
            _0x47d878['bCDML'],
            _0x47d878[_0x581f64(0x476)],
            _0x47d878[_0x581f64(0x1ee)],
            _0x47d878['mxSsb'],
            _0x47d878[_0x581f64(0x2ab)],
            _0x581f64(0x192),
            _0x47d878['xQJTL'],
            _0x47d878[_0x581f64(0x1cb)],
            _0x47d878[_0x581f64(0x591)],
            _0x47d878['EcPyq'],
            _0x47d878['nupKo'],
            _0x47d878['DyvKo'],
            _0x47d878[_0x581f64(0x53e)],
            _0x47d878['ulzpQ'],
            _0x47d878['OWvNG'],
            _0x47d878[_0x581f64(0x182)],
            _0x47d878[_0x581f64(0x65e)],
            _0x47d878[_0x581f64(0x5e8)],
            _0x47d878[_0x581f64(0x463)],
            _0x47d878['PuaQO'],
            _0x47d878[_0x581f64(0x424)],
            _0x47d878[_0x581f64(0x661)],
            _0x581f64(0x1f0),
            _0x581f64(0x614),
            _0x47d878[_0x581f64(0x165)],
            _0x47d878[_0x581f64(0x3d1)],
            _0x47d878[_0x581f64(0x56c)],
            _0x47d878[_0x581f64(0x4ae)],
            'mintcream',
            _0x47d878['AGfGe'],
            _0x581f64(0x5aa),
            _0x581f64(0x385),
            _0x47d878[_0x581f64(0x5ad)],
            _0x47d878[_0x581f64(0x46c)],
            _0x581f64(0x43f),
            _0x47d878['yhTbk'],
            _0x47d878[_0x581f64(0x51a)],
            _0x47d878[_0x581f64(0x2fc)],
            _0x47d878[_0x581f64(0x469)],
            _0x47d878[_0x581f64(0x393)],
            _0x47d878[_0x581f64(0x3bf)],
            _0x47d878['IKPaE'],
            _0x47d878[_0x581f64(0x676)],
            _0x47d878[_0x581f64(0x32f)],
            _0x47d878[_0x581f64(0x1bb)],
            _0x47d878[_0x581f64(0x2ac)],
            _0x47d878['YqCGO'],
            'plum',
            _0x47d878[_0x581f64(0x14b)],
            _0x581f64(0x417),
            _0x47d878[_0x581f64(0x45f)],
            'rosybrown',
            _0x47d878[_0x581f64(0x5f9)],
            _0x47d878[_0x581f64(0x4d1)],
            _0x47d878[_0x581f64(0x3ea)],
            _0x47d878[_0x581f64(0x387)],
            _0x581f64(0x4df),
            _0x581f64(0x633),
            _0x47d878[_0x581f64(0x4ce)],
            _0x47d878['YiKRq'],
            _0x47d878['MfymA'],
            _0x47d878[_0x581f64(0x2b8)],
            _0x47d878[_0x581f64(0x487)],
            _0x47d878['LsQBR'],
            _0x47d878['HUFSO'],
            _0x47d878[_0x581f64(0x5e6)],
            _0x47d878[_0x581f64(0x4b5)],
            _0x47d878[_0x581f64(0x427)],
            _0x581f64(0x638),
            _0x47d878['vhfPX'],
            _0x581f64(0x65f),
            _0x47d878[_0x581f64(0x3e9)],
            _0x47d878['xBnVa'],
            _0x47d878[_0x581f64(0x3d4)],
            _0x47d878['nTdeR'],
            _0x47d878['yBKKh'],
            _0x47d878[_0x581f64(0x341)],
            _0x47d878[_0x581f64(0x669)]
        ];
    function _0x18a5fc(_0x4b62e0, _0x56db47, _0x3f30c4) {
        var _0x4d4a46 = _0x581f64;
        return _0x47d878[_0x4d4a46(0x3d6)](_0x3f30c4[_0x4d4a46(0x2f5)](_0x4b62e0), _0x56db47);
    }
    function _0x143409(_0x1087d8) {
        for (var _0x32b5bb = -0x1, _0x7ff0ea = _0x1087d8 ? _0x1087d8['length'] : 0x0, _0x2e4b0e = 0x0, _0x196a43 = []; _0x47d878['EVnaG'](++_0x32b5bb, _0x7ff0ea);) {
            var _0x5ef78f = _0x1087d8[_0x32b5bb];
            _0x5ef78f && (_0x196a43[_0x2e4b0e++] = _0x5ef78f);
        }
        return _0x196a43;
    }
    function _0x44568a(_0x3153fe) {
        var _0x399134 = _0x581f64;
        return _0x3153fe[_0x399134(0x3ec)]();
    }
    function _0x3605bc(_0x299ae7) {
        var _0x4dfb56 = _0x581f64;
        return !!_0x299ae7 && (_0x47d878[_0x4dfb56(0x33b)](_0x47d878['WQKwW'], _0x299ae7) && (_0x47d878['tGftj'](-0x1, _0x303b51[_0x4dfb56(0x2f5)](_0x299ae7[_0x4dfb56(0x3ec)]())) || _0x299ae7['match'](_0x168a46)));
    }
    function _0x5631ab(_0x4d8489) {
        var _0x8a7b3a = _0x581f64, _0x49585b = new DOMParser();
        return _0x47d878[_0x8a7b3a(0x2e2)](-0x1, _0x4d8489[_0x8a7b3a(0x2f5)](_0x47d878[_0x8a7b3a(0x1d5)])) && -0x1 !== _0x4d8489[_0x8a7b3a(0x2f5)](_0x47d878[_0x8a7b3a(0x5b0)]) && _0x4d8489['replace'](_0x47d878[_0x8a7b3a(0x5b0)], _0x47d878['NJuJB'](_0x47d878['ewIRU'](_0x47d878[_0x8a7b3a(0x3b2)], _0x186a58), '\x22')), _0x49585b['parseFromString'](_0x4d8489, _0x8a7b3a(0x2c8));
    }
    function _0x50eb7f(_0x3b8d7c, _0x50ddba) {
        var _0x39fe49 = _0x581f64;
        return _0x4fb625 = _0x50ddba[_0x39fe49(0x27c)](_0x3b8d7c), Array[_0x39fe49(0x2b3)][_0x39fe49(0x3e0)][_0x39fe49(0x649)](_0x4fb625);
        var _0x4fb625;
    }
    function _0x37cad6(_0x47457f) {
        var _0x10e938 = _0x581f64;
        return _0x47d878[_0x10e938(0x330)](_0x47457f, SVGElement) ? Promise[_0x10e938(0x2d0)](_0x47457f) : /^\s*(?:<\?xml[^>]*>\s*)?(?:<!doctype svg[^>]*\s*(?:\[?(?:\s*<![^>]*>\s*)*\]?)*[^>]*>\s*)?<svg[^>]*>[^]*<\/svg>\s*$/i[_0x10e938(0x316)](_0x47457f[_0x10e938(0x468)](_0x51d101, '')) ? Promise[_0x10e938(0x2d0)](_0x47d878[_0x10e938(0x17c)](_0x5631ab, _0x47457f)) : _0x47d878[_0x10e938(0x47f)] == typeof _0x47457f ? _0x47d878[_0x10e938(0x17c)](fetch, _0x47457f)[_0x10e938(0x4bd)](function (_0x50a68d) {
            var _0x386b50 = _0x10e938;
            return _0x50a68d[_0x386b50(0x17f)]();
        })[_0x10e938(0x4bd)](function (_0x5c53a0) {
            return _0x47d878['bXWPW'](_0x5631ab, _0x5c53a0);
        }) : void 0x0;
    }
    function _0x344188(_0x279f5e, _0x239cb9) {
        var _0x3d260e = _0x581f64, _0x1ee053 = {
                'PbmXo': function (_0x1e114b, _0x33169b) {
                    return _0x1e114b !== _0x33169b;
                }
            };
        return _0x279f5e[_0x3d260e(0x468)](/(\s|\n|\R|\r)/g, '')['split'](/(\{|\}|\;)/)[_0x3d260e(0x22a)](function (_0x570944) {
            var _0x57d0d5 = _0x3d260e;
            return _0x570944[_0x57d0d5(0x691)]();
        })[_0x3d260e(0x22a)](_0x44568a)[_0x3d260e(0x55b)](function (_0x3a1409) {
            var _0x67063e = _0x3d260e;
            return _0x3a1409 && _0x3a1409[_0x67063e(0x362)];
        })[_0x3d260e(0x55b)](function (_0x3eb8ba) {
            var _0x33b5eb = _0x3d260e;
            return _0x47d878[_0x33b5eb(0x459)](0x0, _0x3eb8ba['indexOf'](_0x239cb9));
        })[_0x3d260e(0x22a)](function (_0x5d1c3d) {
            var _0x241db0 = {
                'RmaUt': function (_0x93686f, _0x5ef2e7) {
                    return _0x93686f !== _0x5ef2e7;
                }
            };
            return _0x5d1c3d['split'](':')['map'](function (_0x13bc3b) {
                var _0x77abaa = _0x3451;
                return _0x13bc3b[_0x77abaa(0x691)]();
            })['filter'](function (_0x3119a0) {
                return _0x241db0['RmaUt'](_0x3119a0, _0x239cb9);
            });
        })['reduce'](function (_0x466e33, _0x582cdf) {
            var _0x3e505e = _0x3d260e;
            return _0x466e33[_0x3e505e(0x5cc)](_0x582cdf);
        }, [])[_0x3d260e(0x55b)](function (_0x125c45) {
            var _0x55cec7 = _0x3d260e;
            return _0x1ee053[_0x55cec7(0x49e)](-0x1, _0x303b51[_0x55cec7(0x2f5)](_0x125c45)) || _0x168a46[_0x55cec7(0x316)](_0x125c45);
        });
    }
    return function (_0x5e5c73, _0x137af6) {
        var _0x20d4a0 = _0x581f64, _0x21424a = { 'njJsU': _0x47d878[_0x20d4a0(0x6c1)] };
        return _0x47d878[_0x20d4a0(0x17c)](_0x37cad6, _0x5e5c73)[_0x20d4a0(0x4bd)](function (_0x372ffc) {
            var _0x231527 = _0x20d4a0, _0x115c4b = {
                    'cGmPN': _0x47d878['ppxBt'],
                    'qUkyz': _0x231527(0x5ce),
                    'JELzl': function (_0x5962a6, _0x411c2b, _0x4a8792) {
                        return _0x47d878['NLUtd'](_0x5962a6, _0x411c2b, _0x4a8792);
                    },
                    'xTVnW': _0x47d878[_0x231527(0x6c1)]
                }, _0x59a758 = _0x47d878[_0x231527(0x550)](_0x50eb7f, _0x47d878[_0x231527(0x28e)], _0x372ffc)['map'](function (_0x2ec5c3) {
                    var _0x10822d = _0x231527;
                    return _0x2ec5c3[_0x10822d(0x5fb)](_0x115c4b['cGmPN']);
                }), _0x209cdc = _0x47d878['NLUtd'](_0x50eb7f, _0x47d878[_0x231527(0x2c0)], _0x372ffc)['map'](function (_0x39516e) {
                    var _0x569f0b = _0x231527;
                    return _0x39516e[_0x569f0b(0x5fb)](_0x115c4b['qUkyz']);
                }), _0x528c30 = _0x47d878[_0x231527(0x369)](_0x50eb7f, _0x47d878[_0x231527(0x1a5)], _0x372ffc)[_0x231527(0x22a)](function (_0x2bb3f4) {
                    var _0x5aa820 = _0x231527;
                    return _0x2bb3f4[_0x5aa820(0x5fb)](_0x21424a['njJsU']);
                });
            return _0x47d878[_0x231527(0x369)](_0x50eb7f, _0x47d878['cdAAB'], _0x372ffc)['forEach'](function (_0xf98c78) {
                var _0x48dc32 = _0x231527;
                _0x59a758[_0x48dc32(0x1b6)](_0xf98c78[_0x48dc32(0x39b)][_0x48dc32(0x5a9)]), _0x209cdc[_0x48dc32(0x1b6)](_0xf98c78[_0x48dc32(0x39b)][_0x48dc32(0x5ce)]), _0x528c30[_0x48dc32(0x1b6)](_0xf98c78[_0x48dc32(0x39b)][_0x48dc32(0x23c)]);
            }), _0x47d878[_0x231527(0x569)](_0x50eb7f, _0x47d878[_0x231527(0x23b)], _0x372ffc)[_0x231527(0x618)](function (_0x4818c9) {
                var _0x515995 = _0x231527, _0x1d144b = _0x4818c9[_0x515995(0x217)];
                _0x115c4b['JELzl'](_0x344188, _0x1d144b, _0x515995(0x5a9))[_0x515995(0x618)](function (_0x302bbd) {
                    var _0x55211d = _0x515995;
                    return _0x59a758[_0x55211d(0x1b6)](_0x302bbd);
                }), _0x344188(_0x1d144b, _0x515995(0x5ce))[_0x515995(0x618)](function (_0x1ab793) {
                    var _0x1231a4 = _0x515995;
                    return _0x209cdc[_0x1231a4(0x1b6)](_0x1ab793);
                }), _0x344188(_0x1d144b, _0x115c4b['xTVnW'])['forEach'](function (_0x325c82) {
                    var _0x7adb2 = _0x515995;
                    return _0x528c30[_0x7adb2(0x1b6)](_0x325c82);
                });
            }), _0x137af6 && _0x137af6[_0x231527(0x5d6)] ? _0x143409(_0x59a758[_0x231527(0x5cc)](_0x209cdc)[_0x231527(0x5cc)](_0x528c30)[_0x231527(0x55b)](_0x3605bc)[_0x231527(0x22a)](_0x44568a)[_0x231527(0x55b)](_0x18a5fc)) : {
                'fills': _0x143409(_0x59a758[_0x231527(0x55b)](_0x3605bc)[_0x231527(0x22a)](_0x44568a)['filter'](_0x18a5fc)),
                'strokes': _0x47d878[_0x231527(0x17c)](_0x143409, _0x209cdc[_0x231527(0x55b)](_0x3605bc)['map'](_0x44568a)['filter'](_0x18a5fc)),
                'stops': _0x47d878[_0x231527(0x17c)](_0x143409, _0x528c30[_0x231527(0x55b)](_0x3605bc)[_0x231527(0x22a)](_0x44568a)['filter'](_0x18a5fc))
            };
        });
    };
}));
!String['prototype'][_0x52102f(0x5f0)] && (String['prototype'][_0x52102f(0x5f0)] = function (_0x484906, _0x479359) {
    var _0x1cca65 = _0x52102f;
    return this[_0x1cca65(0x468)](new RegExp(_0x484906, 'g'), _0x479359);
});
window[_0x52102f(0x3ae)] = window[_0x52102f(0x3ae)] || window[_0x52102f(0x151)];
const NUM_ALLOWED_WEBSITES_FOR_TRIAL = (_0x52102f(0x241)['length'] - 0x12 / 0x2) / 0x2 + 0xa;
String[_0x52102f(0x2b3)][_0x52102f(0x2a1)] = function () {
    var _0x208bd5 = _0x52102f, _0x542917 = {
            'eOOJL': function (_0xd602d0, _0x537c94) {
                return _0xd602d0 < _0x537c94;
            },
            'dMPLH': function (_0x45cc51, _0xea0cc2) {
                return _0x45cc51 + _0xea0cc2;
            }
        }, _0x47b29b = 0x0;
    for (var _0xe208d1 = 0x0; _0x542917[_0x208bd5(0x5ea)](_0xe208d1, this[_0x208bd5(0x362)]); _0xe208d1++) {
        var _0x4a2e6 = this['charCodeAt'](_0xe208d1);
        _0x47b29b = _0x542917[_0x208bd5(0x1f8)]((_0x47b29b << 0x5) - _0x47b29b, _0x4a2e6), _0x47b29b = _0x47b29b & _0x47b29b;
    }
    return Math[_0x208bd5(0x413)](_0x47b29b);
};
const defaultedSettingForHost = _0x336188 => {
        var _0x473bf0 = _0x52102f, _0x109a10 = {
                'Dtbgn': _0x473bf0(0x2c5),
                'MKhbs': function (_0xde6e76, _0x2e1916) {
                    return _0xde6e76 === _0x2e1916;
                },
                'sXBNB': function (_0x35bd7c, _0x6b741) {
                    return _0x35bd7c === _0x6b741;
                }
            }, _0x115487 = _0x109a10[_0x473bf0(0x149)][_0x473bf0(0x523)]('|'), _0x3d918d = 0x0;
        while (!![]) {
            switch (_0x115487[_0x3d918d++]) {
            case '0':
                _0x336188[_0x473bf0(0x494)] = _0x109a10['MKhbs'](_0x336188[_0x473bf0(0x494)], undefined) ? 0x1 : _0x336188[_0x473bf0(0x494)];
                continue;
            case '1':
                !_0x336188 && (_0x336188 = {
                    'darkMode': !![],
                    'invertPng': ![],
                    'imageBrightness': 0x1
                });
                continue;
            case '2':
                return _0x336188;
            case '3':
                _0x336188[_0x473bf0(0x30e)] = _0x336188[_0x473bf0(0x30e)] === undefined ? ![] : _0x336188[_0x473bf0(0x30e)];
                continue;
            case '4':
                _0x336188[_0x473bf0(0x1e5)] = _0x109a10[_0x473bf0(0x380)](_0x336188[_0x473bf0(0x1e5)], undefined) ? !![] : _0x336188[_0x473bf0(0x1e5)];
                continue;
            }
            break;
        }
    }, getSettings = async _0x3259d7 => {
        var _0x545b70 = _0x52102f, _0x1d3dc6 = {
                'mhHxK': function (_0x52dd5d, _0x3e5641) {
                    return _0x52dd5d === _0x3e5641;
                },
                'Uamft': _0x545b70(0x51d),
                'nWAVG': function (_0x3a6e5d, _0x36b774) {
                    return _0x3a6e5d(_0x36b774);
                },
                'NQXRl': function (_0x93ccad, _0x2e7d32) {
                    return _0x93ccad(_0x2e7d32);
                }
            };
        return new Promise((_0x3f7281, _0x1595cb) => {
            var _0x238bad = _0x545b70;
            let _0x32b4a7 = DELUMINATOR_SETTINGS_STRING;
            _0x32b4a7[_0x238bad(0x684)] = _0x32b4a7[_0x238bad(0x684)] === undefined ? !![] : _0x32b4a7[_0x238bad(0x684)], _0x32b4a7[_0x238bad(0x293)] = _0x1d3dc6['mhHxK'](_0x32b4a7[_0x238bad(0x293)], undefined) ? _0x1d3dc6[_0x238bad(0x1fa)] : _0x32b4a7[_0x238bad(0x293)], _0x32b4a7[_0x238bad(0x6bf)] = _0x1d3dc6[_0x238bad(0x1cc)](_0x32b4a7[_0x238bad(0x6bf)], undefined) ? [] : _0x32b4a7[_0x238bad(0x6bf)], _0x32b4a7[_0x238bad(0x57d)] = _0x32b4a7[_0x238bad(0x57d)] === undefined ? ![] : _0x32b4a7[_0x238bad(0x57d)], _0x32b4a7[_0x238bad(0x5e3)] = _0x32b4a7['darkMaps'] === undefined ? !![] : _0x32b4a7[_0x238bad(0x5e3)], _0x3259d7 && (_0x32b4a7[_0x3259d7] = _0x1d3dc6[_0x238bad(0x370)](defaultedSettingForHost, _0x32b4a7[_0x3259d7])), _0x1d3dc6[_0x238bad(0x144)](_0x3f7281, _0x32b4a7);
        });
    }, getSettingForHost = async _0x197129 => {
        let _0x27cd68 = await getSettings(_0x197129);
        return _0x27cd68[_0x197129];
    }, saveSetting = async (_0x274da7, _0x116fca) => {
        var _0x5112be = _0x52102f, _0x260630 = {
                'sSPJA': function (_0x7e20d5) {
                    return _0x7e20d5();
                },
                'uriYD': function (_0x29b14c, _0x3e8b15) {
                    return _0x29b14c(_0x3e8b15);
                }
            };
        let _0xeeb7cf = await _0x260630['sSPJA'](getSettings);
        _0xeeb7cf[_0x274da7] = _0x116fca, _0x260630[_0x5112be(0x5b4)](saveSettings, _0xeeb7cf);
    }, getSetting = async (_0x32263b, _0x3f6d3d) => {
        var _0x56c299 = _0x52102f, _0x45efba = {
                'MlLLP': function (_0x2318b2) {
                    return _0x2318b2();
                },
                'jIseM': function (_0x359b8a, _0x15345b) {
                    return _0x359b8a === _0x15345b;
                }
            };
        let _0x13116b = await _0x45efba[_0x56c299(0x627)](getSettings), _0x1d192c = _0x13116b[_0x32263b];
        return _0x45efba[_0x56c299(0x6cd)](_0x1d192c, undefined) ? _0x3f6d3d : _0x1d192c;
    }, saveSettings = async _0x5f573e => {
    }, isLicenseStringOriginal = _0xdcb9ab => {
        var _0x501764 = _0x52102f, _0x57c05 = {
                'xcGRl': function (_0x5e54dc, _0x4bff7e) {
                    return _0x5e54dc < _0x4bff7e;
                },
                'GhdNN': function (_0x55ec92, _0x5c5f2c) {
                    return _0x55ec92 == _0x5c5f2c;
                }
            };
        let _0x1819af = _0xdcb9ab[_0x501764(0x523)]('__');
        if (_0x57c05[_0x501764(0x324)](_0x1819af[_0x501764(0x362)], 0x2))
            return ![];
        let _0x2cb5da = _0x1819af[0x0], _0x5c6cb7 = _0x1819af[0x1], _0x61bf2f = _0x2cb5da[_0x501764(0x2a1)]();
        return _0x57c05['GhdNN'](_0x61bf2f, _0x5c6cb7);
    }, hasPremium = _0x444c1c => {
        var _0x46f0d7 = _0x52102f, _0x564730 = {
                'IcXXZ': function (_0x1a3d84, _0x5a367f) {
                    return _0x1a3d84(_0x5a367f);
                }
            };
        let _0x376b42 = _0x444c1c[_0x46f0d7(0x2c7)];
        if (!_0x376b42)
            return ![];
        return _0x564730[_0x46f0d7(0x44c)](isLicenseStringOriginal, _0x376b42);
    }, hasTrialExpired = _0x492f22 => {
        var _0xbc3545 = _0x52102f;
        if (hasPremium(_0x492f22))
            return ![];
        if (_0x492f22[_0xbc3545(0x6bf)][_0xbc3545(0x362)] > NUM_ALLOWED_WEBSITES_FOR_TRIAL)
            return !![];
        return ![];
    }, isAllowedToUseExtension = _0x1c3ee2 => {
        var _0x232547 = _0x52102f, _0x55ed15 = {
                'DgZgz': function (_0x14678c, _0x9d2dd6) {
                    return _0x14678c(_0x9d2dd6);
                }
            };
        return _0x55ed15[_0x232547(0x68c)](hasPremium, _0x1c3ee2) || !_0x55ed15[_0x232547(0x68c)](hasTrialExpired, _0x1c3ee2);
    }, getMainDomain = _0x59a975 => {
        var _0x11dec4 = _0x52102f, _0x227cb0 = {
                'jZsKr': _0x11dec4(0x1ac),
                'kqRVe': _0x11dec4(0x51f),
                'cWxQn': _0x11dec4(0x345),
                'hZxKc': _0x11dec4(0x59c),
                'mBvIh': function (_0x40df04, _0x4c1b2e) {
                    return _0x40df04 + _0x4c1b2e;
                },
                'hUIyf': '.com.'
            };
        (_0x59a975['endsWith'](_0x11dec4(0x5ef)) || _0x59a975['endsWith'](_0x11dec4(0x653)) || _0x59a975[_0x11dec4(0x3a5)](_0x227cb0[_0x11dec4(0x159)]) || _0x59a975['endsWith'](_0x227cb0[_0x11dec4(0x675)]) || _0x59a975[_0x11dec4(0x3a5)](_0x11dec4(0x1fc)) || _0x59a975[_0x11dec4(0x3a5)](_0x11dec4(0x276)) || _0x59a975[_0x11dec4(0x3a5)](_0x11dec4(0x277)) || _0x59a975[_0x11dec4(0x3a5)](_0x227cb0[_0x11dec4(0x2c4)]) || _0x59a975[_0x11dec4(0x3a5)](_0x11dec4(0x603)) || _0x59a975[_0x11dec4(0x3a5)](_0x227cb0[_0x11dec4(0x5c4)])) && (_0x59a975 = _0x59a975[_0x11dec4(0x654)](0x0, _0x227cb0[_0x11dec4(0x6ae)](_0x59a975[_0x11dec4(0x2f5)](_0x227cb0[_0x11dec4(0x292)]), 0x4)));
        let _0x24615f = _0x59a975[_0x11dec4(0x468)](/^(?:[a-z0-9\-\.]+\.)??([a-z0-9\-]+)(?:\.com|\.mu|\.net|\.org|\.biz|\.ws|\.in|\.me|\.co\.uk|\.co|\.org\.uk|\.ltd\.uk|\.plc\.uk|\.me\.uk|\.edu|\.mil|\.br\.com|\.cn\.com|\.eu\.com|\.hu\.com|\.no\.com|\.qc\.com|\.sa\.com|\.se\.com|\.se\.net|\.us\.com|\.uy\.com|\.ac|\.co\.ac|\.gv\.ac|\.or\.ac|\.ac\.ac|\.af|\.am|\.as|\.at|\.ac\.at|\.co\.at|\.gv\.at|\.or\.at|\.asn\.au|\.com\.au|\.edu\.au|\.org\.au|\.net\.au|\.id\.au|\.be|\.ac\.be|\.adm\.br|\.adv\.br|\.am\.br|\.arq\.br|\.art\.br|\.bio\.br|\.cng\.br|\.cnt\.br|\.com\.br|\.ecn\.br|\.eng\.br|\.esp\.br|\.etc\.br|\.eti\.br|\.fm\.br|\.fot\.br|\.fst\.br|\.g12\.br|\.gov\.br|\.ind\.br|\.inf\.br|\.jor\.br|\.lel\.br|\.med\.br|\.mil\.br|\.net\.br|\.nom\.br|\.ntr\.br|\.odo\.br|\.org\.br|\.ppg\.br|\.pro\.br|\.psc\.br|\.psi\.br|\.rec\.br|\.slg\.br|\.tmp\.br|\.tur\.br|\.tv\.br|\.vet\.br|\.zlg\.br|\.br|\.ab\.ca|\.bc\.ca|\.mb\.ca|\.nb\.ca|\.nf\.ca|\.ns\.ca|\.nt\.ca|\.on\.ca|\.pe\.ca|\.qc\.ca|\.sk\.ca|\.yk\.ca|\.ca|\.cc|\.ac\.cn|\.com\.cn|\.edu\.cn|\.gov\.cn|\.org\.cn|\.bj\.cn|\.sh\.cn|\.tj\.cn|\.cq\.cn|\.he\.cn|\.nm\.cn|\.ln\.cn|\.jl\.cn|\.hl\.cn|\.js\.cn|\.zj\.cn|\.ah\.cn|\.gd\.cn|\.gx\.cn|\.hi\.cn|\.sc\.cn|\.gz\.cn|\.yn\.cn|\.xz\.cn|\.sn\.cn|\.gs\.cn|\.qh\.cn|\.nx\.cn|\.xj\.cn|\.tw\.cn|\.hk\.cn|\.mo\.cn|\.cn|\.cx|\.cz|\.de|\.dk|\.fo|\.com\.ec|\.tm\.fr|\.com\.fr|\.asso\.fr|\.presse\.fr|\.fr|\.gf|\.gs|\.co\.il|\.net\.il|\.ac\.il|\.k12\.il|\.gov\.il|\.muni\.il|\.ac\.in|\.co\.in|\.org\.in|\.ernet\.in|\.gov\.in|\.net\.in|\.res\.in|\.is|\.it|\.ac\.jp|\.co\.jp|\.go\.jp|\.or\.jp|\.ne\.jp|\.ac\.kr|\.co\.kr|\.go\.kr|\.ne\.kr|\.nm\.kr|\.or\.kr|\.li|\.lt|\.lu|\.asso\.mc|\.tm\.mc|\.com\.mm|\.org\.mm|\.net\.mm|\.edu\.mm|\.gov\.mm|\.ms|\.nl|\.no|\.nu|\.pl|\.ro|\.org\.ro|\.store\.ro|\.tm\.ro|\.firm\.ro|\.www\.ro|\.arts\.ro|\.rec\.ro|\.info\.ro|\.nom\.ro|\.nt\.ro|\.se|\.si|\.com\.sg|\.org\.sg|\.net\.sg|\.gov\.sg|\.sk|\.st|\.tf|\.ac\.th|\.co\.th|\.go\.th|\.mi\.th|\.net\.th|\.or\.th|\.tm|\.to|\.com\.tr|\.edu\.tr|\.gov\.tr|\.k12\.tr|\.net\.tr|\.org\.tr|\.com\.tw|\.org\.tw|\.net\.tw|\.ac\.uk|\.uk\.com|\.uk\.net|\.gb\.com|\.gb\.net|\.vg|\.sh|\.kz|\.ch|\.info|\.ua|\.gov|\.name|\.pro|\.ie|\.hk|\.com\.hk|\.org\.hk|\.net\.hk|\.edu\.hk|\.us|\.tk|\.cd|\.by|\.ad|\.lv|\.eu\.lv|\.bz|\.es|\.jp|\.cl|\.ag|\.mobi|\.eu|\.co\.nz|\.org\.nz|\.net\.nz|\.maori\.nz|\.iwi\.nz|\.io|\.la|\.md|\.sc|\.sg|\.vc|\.tw|\.travel|\.my|\.se|\.tv|\.pt|\.com\.pt|\.edu\.pt|\.asia|\.fi|\.com\.ve|\.net\.ve|\.fi|\.org\.ve|\.web\.ve|\.info\.ve|\.co\.ve|\.tel|\.im|\.gr|\.ru|\.net\.ru|\.org\.ru|\.hr|\.com\.hr)$/, '$1'), _0x197907 = _0x59a975[_0x11dec4(0x654)](_0x227cb0[_0x11dec4(0x6ae)](_0x59a975['indexOf'](_0x24615f), _0x24615f[_0x11dec4(0x362)]));
        return _0x24615f + _0x197907;
    };
function NFColor(_0x280fe4, _0x85554c, _0x5a5483, _0x18404c) {
    var _0x17ac26 = _0x52102f, _0x3adc7d = {
            'ZPKZf': '8|4|2|0|15|1|12|5|14|6|7|3|13|10|11|9',
            'gzEyO': function (_0x2e9d76, _0x2b2508) {
                return _0x2e9d76 == _0x2b2508;
            },
            'VJfVg': function (_0x5e7739, _0x5ebdec) {
                return _0x5e7739 + _0x5ebdec;
            },
            'mdPhu': 'rgb(',
            'sWDrq': function (_0x294532, _0x10e02a) {
                return _0x294532 + _0x10e02a;
            },
            'cdovu': function (_0x40c92a, _0x224eea) {
                return _0x40c92a | _0x224eea;
            },
            'Wdgmu': function (_0x529e98, _0x51c65c) {
                return _0x529e98 + _0x51c65c;
            },
            'DWUFz': function (_0x544aca, _0x4e4567) {
                return _0x544aca << _0x4e4567;
            },
            'cXLyV': function (_0xb142a0, _0x4d0006) {
                return _0xb142a0 / _0x4d0006;
            },
            'GthGC': function (_0xffab4c, _0x4ac6eb) {
                return _0xffab4c - _0x4ac6eb;
            },
            'ABOyN': function (_0x40a13d, _0x36adf8) {
                return _0x40a13d > _0x36adf8;
            },
            'GWqPd': function (_0x8b188e, _0x450b09) {
                return _0x8b188e >> _0x450b09;
            },
            'xRBWt': function (_0x316e81, _0xcca4fa) {
                return _0x316e81 + _0xcca4fa;
            },
            'AgwdJ': function (_0x59c3cf, _0x274682) {
                return _0x59c3cf * _0x274682;
            },
            'hRwCd': function (_0x189dd7, _0x200c86) {
                return _0x189dd7 > _0x200c86;
            },
            'eXVRs': function (_0x2a93d8, _0x1635ba) {
                return _0x2a93d8 + _0x1635ba;
            },
            'fpPfq': function (_0x377928, _0x3fd79d) {
                return _0x377928 / _0x3fd79d;
            },
            'mXSRi': function (_0x401e1d, _0x56463b) {
                return _0x401e1d < _0x56463b;
            },
            'ZfzaA': function (_0x3bccdc, _0x152012, _0x52c9b3) {
                return _0x3bccdc(_0x152012, _0x52c9b3);
            },
            'zJGjv': function (_0x128fbc, _0x12b98a) {
                return _0x128fbc - _0x12b98a;
            },
            'zBHOM': function (_0x4fc3f5, _0x42fa0f) {
                return _0x4fc3f5 * _0x42fa0f;
            },
            'uTAzh': function (_0x1000b2, _0x4688ca) {
                return _0x1000b2 % _0x4688ca;
            },
            'ieRmJ': function (_0x3e98f3, _0x61932c) {
                return _0x3e98f3(_0x61932c);
            },
            'XGuKS': function (_0x5316eb, _0x20d40c, _0x5acbf1) {
                return _0x5316eb(_0x20d40c, _0x5acbf1);
            },
            'bkozZ': function (_0x48a17b, _0x5bb2fd) {
                return _0x48a17b * _0x5bb2fd;
            },
            'zGRds': function (_0x2a1b96, _0x153759) {
                return _0x2a1b96 + _0x153759;
            },
            'LBjoM': function (_0x2b7b3e, _0x5a3a17) {
                return _0x2b7b3e * _0x5a3a17;
            },
            'fYIbp': function (_0xc362f3, _0x36022e) {
                return _0xc362f3 * _0x36022e;
            },
            'gLxoB': function (_0x3753db, _0x45cb44) {
                return _0x3753db * _0x45cb44;
            },
            'Rsouj': function (_0x314bea, _0x4f338a) {
                return _0x314bea - _0x4f338a;
            },
            'SSiis': function (_0x4b643d, _0x1b1c68) {
                return _0x4b643d * _0x1b1c68;
            }
        }, _0x15c05f = _0x3adc7d['ZPKZf'][_0x17ac26(0x523)]('|'), _0x1cac01 = 0x0;
    while (!![]) {
        switch (_0x15c05f[_0x1cac01++]) {
        case '0':
            this['b'] = _0x5a5483;
            continue;
        case '1':
            this[_0x17ac26(0x50e)] = function () {
                var _0x171ef4 = _0x17ac26;
                return _0x2e14ce[_0x171ef4(0x39c)](this['a'], 0x1) ? _0x2e14ce['qrbjE'](_0x2e14ce[_0x171ef4(0x62a)](_0x2e14ce[_0x171ef4(0x68a)](_0x2e14ce[_0x171ef4(0x68a)](_0x2e14ce[_0x171ef4(0x3c9)](_0x2e14ce[_0x171ef4(0x547)], this['r']), ','), this['g']) + ',', this['b']), ')') : _0x2e14ce[_0x171ef4(0x3c9)](_0x2e14ce['HvXDW'](_0x2e14ce[_0x171ef4(0x3c9)](_0x2e14ce['rGgHJ'](_0x2e14ce[_0x171ef4(0x206)](_0x2e14ce['nkUaH'](_0x2e14ce['nkUaH'](_0x171ef4(0x6a2) + this['r'], ','), this['g']), ','), this['b']), ','), this['a']), ')');
            };
            continue;
        case '2':
            this['g'] = _0x85554c;
            continue;
        case '3':
            this[_0x17ac26(0x43c)] = function () {
                var _0x7ed9ad = _0x17ac26;
                return _0x2e14ce[_0x7ed9ad(0x6c5)](this[_0x7ed9ad(0x3e6)](), 0x64);
            };
            continue;
        case '4':
            this['r'] = _0x280fe4;
            continue;
        case '5':
            this[_0x17ac26(0x501)] = function () {
                return this['a'] === 0x0;
            };
            continue;
        case '6':
            this[_0x17ac26(0x314)] = function () {
                var _0x58198c = _0x17ac26;
                return _0x2e14ce[_0x58198c(0x36c)](this['saturation'](), 0.2);
            };
            continue;
        case '7':
            this[_0x17ac26(0x3e6)] = function () {
                var _0x41e75c = _0x17ac26;
                return _0x2e14ce['bdpIn'](_0x2e14ce[_0x41e75c(0x1a2)](_0x2e14ce[_0x41e75c(0x1a2)](this['r'] * 0x3, this['b']), _0x2e14ce[_0x41e75c(0x2cb)](this['g'], 0x4)), 0x3);
            };
            continue;
        case '8':
            var _0x2e14ce = {
                'kMXEj': function (_0x54c775, _0x21eb2e) {
                    var _0x4427ac = _0x17ac26;
                    return _0x3adc7d[_0x4427ac(0x50d)](_0x54c775, _0x21eb2e);
                },
                'qrbjE': function (_0x7b1062, _0x44fdb7) {
                    return _0x7b1062 + _0x44fdb7;
                },
                'gwQXw': function (_0x38e7b6, _0x45e01a) {
                    var _0x102a54 = _0x17ac26;
                    return _0x3adc7d[_0x102a54(0x545)](_0x38e7b6, _0x45e01a);
                },
                'HvXDW': function (_0x3a506f, _0x11f4f1) {
                    var _0x3f9bc1 = _0x17ac26;
                    return _0x3adc7d[_0x3f9bc1(0x545)](_0x3a506f, _0x11f4f1);
                },
                'AxGdw': _0x3adc7d[_0x17ac26(0x25b)],
                'rGgHJ': function (_0x81c965, _0x190ec4) {
                    return _0x81c965 + _0x190ec4;
                },
                'nkUaH': function (_0x30194d, _0x5b98df) {
                    var _0x39c887 = _0x17ac26;
                    return _0x3adc7d[_0x39c887(0x698)](_0x30194d, _0x5b98df);
                },
                'Hafys': function (_0x38b7ec, _0x31fde3) {
                    return _0x3adc7d['sWDrq'](_0x38b7ec, _0x31fde3);
                },
                'SbcFA': function (_0x592e0d, _0x4480a6) {
                    var _0x38ed43 = _0x17ac26;
                    return _0x3adc7d[_0x38ed43(0x4b2)](_0x592e0d, _0x4480a6);
                },
                'QMTxQ': function (_0x3ff7ec, _0xbdd84b) {
                    var _0x1faf57 = _0x17ac26;
                    return _0x3adc7d[_0x1faf57(0x1b2)](_0x3ff7ec, _0xbdd84b);
                },
                'mZZwq': function (_0x134d44, _0x44a159) {
                    var _0x13e580 = _0x17ac26;
                    return _0x3adc7d[_0x13e580(0x4ec)](_0x134d44, _0x44a159);
                },
                'qPxed': function (_0x7eaf6d, _0x471af5) {
                    return _0x7eaf6d << _0x471af5;
                },
                'otEnP': function (_0x16a029, _0x32bb1c) {
                    var _0x342f63 = _0x17ac26;
                    return _0x3adc7d[_0x342f63(0x544)](_0x16a029, _0x32bb1c);
                },
                'KwOFT': function (_0x2ad4b2, _0x4b9a3f) {
                    var _0x1a5a0b = _0x17ac26;
                    return _0x3adc7d[_0x1a5a0b(0x589)](_0x2ad4b2, _0x4b9a3f);
                },
                'NDaHr': function (_0x1c698c, _0x14c3c2) {
                    var _0xf5498f = _0x17ac26;
                    return _0x3adc7d[_0xf5498f(0x531)](_0x1c698c, _0x14c3c2);
                },
                'bdpIn': function (_0x30ea77, _0x5e1fa9) {
                    return _0x3adc7d['GWqPd'](_0x30ea77, _0x5e1fa9);
                },
                'iKnbP': function (_0x2d349c, _0x127754) {
                    var _0x1f01aa = _0x17ac26;
                    return _0x3adc7d[_0x1f01aa(0x382)](_0x2d349c, _0x127754);
                },
                'SoEvc': function (_0x373742, _0xe4e616) {
                    var _0x334da0 = _0x17ac26;
                    return _0x3adc7d[_0x334da0(0x2dd)](_0x373742, _0xe4e616);
                },
                'PvCKB': function (_0x5664b2, _0x15eb44) {
                    var _0x4b7e78 = _0x17ac26;
                    return _0x3adc7d[_0x4b7e78(0x490)](_0x5664b2, _0x15eb44);
                },
                'uuVJT': function (_0x4731e8, _0x30962a) {
                    return _0x4731e8 < _0x30962a;
                },
                'UXjRR': function (_0x55735b, _0x38639a) {
                    return _0x55735b > _0x38639a;
                },
                'zSNFW': function (_0x1911c8, _0x5e9888) {
                    return _0x3adc7d['eXVRs'](_0x1911c8, _0x5e9888);
                },
                'zunNP': function (_0x3aecb6, _0x375a33) {
                    return _0x3adc7d['fpPfq'](_0x3aecb6, _0x375a33);
                },
                'uAWZh': function (_0x444564, _0x1e706e) {
                    return _0x444564 - _0x1e706e;
                },
                'sEKuW': function (_0x4b4765, _0x3bd6f9) {
                    var _0x7e8dd5 = _0x17ac26;
                    return _0x3adc7d[_0x7e8dd5(0x239)](_0x4b4765, _0x3bd6f9);
                },
                'RbvOl': function (_0x2b885f, _0x1bfc50) {
                    var _0xab8d89 = _0x17ac26;
                    return _0x3adc7d[_0xab8d89(0x490)](_0x2b885f, _0x1bfc50);
                },
                'Denwx': function (_0x4b0eed, _0x4ad5b5) {
                    var _0xc24213 = _0x17ac26;
                    return _0x3adc7d[_0xc24213(0x403)](_0x4b0eed, _0x4ad5b5);
                },
                'qGBmB': function (_0x4928ea, _0x5a6f79) {
                    return _0x4928ea > _0x5a6f79;
                },
                'xDOhZ': function (_0x4d3306, _0x27b9d0) {
                    return _0x4d3306 * _0x27b9d0;
                },
                'gyEbo': function (_0xe0a638, _0x2e8e9a) {
                    return _0xe0a638 - _0x2e8e9a;
                },
                'RgrjM': function (_0x561e5f, _0x427bac) {
                    return _0x561e5f - _0x427bac;
                },
                'LYGwo': function (_0x5051b0, _0x11ea36, _0x513b29) {
                    var _0xbf1ed2 = _0x17ac26;
                    return _0x3adc7d[_0xbf1ed2(0x54b)](_0x5051b0, _0x11ea36, _0x513b29);
                },
                'eYNPy': function (_0x233b46, _0x187bfd) {
                    var _0x13b278 = _0x17ac26;
                    return _0x3adc7d[_0x13b278(0x163)](_0x233b46, _0x187bfd);
                },
                'iixVW': function (_0xee7c7f, _0x127a4) {
                    return _0xee7c7f * _0x127a4;
                },
                'lPOlD': function (_0x5167aa, _0x31adb8) {
                    return _0x3adc7d['zJGjv'](_0x5167aa, _0x31adb8);
                },
                'FErwy': function (_0x538f7c, _0x5e5069) {
                    return _0x538f7c - _0x5e5069;
                },
                'ykrqz': function (_0x2b9cc7, _0x3e064c) {
                    return _0x3adc7d['zBHOM'](_0x2b9cc7, _0x3e064c);
                },
                'DrZyH': function (_0x5d39d1, _0x478942) {
                    return _0x3adc7d['uTAzh'](_0x5d39d1, _0x478942);
                },
                'hCTyJ': function (_0x1c35d2, _0x1c811b) {
                    var _0x125f87 = _0x17ac26;
                    return _0x3adc7d[_0x125f87(0x2bb)](_0x1c35d2, _0x1c811b);
                },
                'JopZp': function (_0x577573, _0x361db6, _0x29f061) {
                    return _0x3adc7d['XGuKS'](_0x577573, _0x361db6, _0x29f061);
                },
                'NAbPU': function (_0x512d29, _0xe43825, _0x2946d8) {
                    var _0x5a17fe = _0x17ac26;
                    return _0x3adc7d[_0x5a17fe(0x5f3)](_0x512d29, _0xe43825, _0x2946d8);
                },
                'rwjpw': function (_0x350001, _0x32c36e) {
                    var _0x232f85 = _0x17ac26;
                    return _0x3adc7d[_0x232f85(0x448)](_0x350001, _0x32c36e);
                },
                'ZqORg': function (_0x4ead96, _0x56eed3) {
                    var _0x548dc1 = _0x17ac26;
                    return _0x3adc7d[_0x548dc1(0x61c)](_0x4ead96, _0x56eed3);
                },
                'RVvVv': function (_0x443e30, _0x46d1dd) {
                    return _0x3adc7d['bkozZ'](_0x443e30, _0x46d1dd);
                },
                'eITJy': function (_0x37c37e, _0x282c62) {
                    var _0x1164bd = _0x17ac26;
                    return _0x3adc7d[_0x1164bd(0x329)](_0x37c37e, _0x282c62);
                },
                'JgZjL': function (_0xf9341b, _0x1a2768) {
                    return _0x3adc7d['bkozZ'](_0xf9341b, _0x1a2768);
                },
                'hYiER': function (_0xe9ad2f, _0xfd046d) {
                    return _0x3adc7d['bkozZ'](_0xe9ad2f, _0xfd046d);
                },
                'AKPBC': function (_0x34282c, _0x68ec25) {
                    var _0x4dbe75 = _0x17ac26;
                    return _0x3adc7d[_0x4dbe75(0x425)](_0x34282c, _0x68ec25);
                },
                'YdYVh': function (_0x1bde80, _0x2d3283) {
                    var _0x3b3e58 = _0x17ac26;
                    return _0x3adc7d[_0x3b3e58(0x429)](_0x1bde80, _0x2d3283);
                },
                'YplUO': function (_0x3bdb44, _0x2e069d) {
                    var _0x31a7e8 = _0x17ac26;
                    return _0x3adc7d[_0x31a7e8(0x61c)](_0x3bdb44, _0x2e069d);
                },
                'WRRoX': function (_0x474591, _0x28543e) {
                    return _0x3adc7d['fpPfq'](_0x474591, _0x28543e);
                },
                'lZSlB': function (_0x33d684, _0x5aac1f) {
                    return _0x33d684 + _0x5aac1f;
                },
                'ALLJW': function (_0x364aae, _0x1939c9) {
                    var _0x10f09b = _0x17ac26;
                    return _0x3adc7d[_0x10f09b(0x1f4)](_0x364aae, _0x1939c9);
                },
                'CIYps': function (_0x1aeb0e, _0x37047b) {
                    var _0x33b96b = _0x17ac26;
                    return _0x3adc7d[_0x33b96b(0x1f4)](_0x1aeb0e, _0x37047b);
                },
                'VSwZe': function (_0x70d60c, _0x2a717c) {
                    return _0x70d60c + _0x2a717c;
                },
                'bbnew': function (_0x3d8549, _0x3287c6) {
                    return _0x3d8549 - _0x3287c6;
                },
                'GBiYi': function (_0x4eec45, _0x285a21) {
                    var _0x57b4b9 = _0x17ac26;
                    return _0x3adc7d[_0x57b4b9(0x4fd)](_0x4eec45, _0x285a21);
                },
                'IgaAq': function (_0x54fa29, _0x2be845) {
                    return _0x54fa29 * _0x2be845;
                },
                'GAapW': function (_0x36e102, _0x3a8fbb) {
                    var _0x5a3110 = _0x17ac26;
                    return _0x3adc7d[_0x5a3110(0x329)](_0x36e102, _0x3a8fbb);
                },
                'mXgtU': function (_0x20352e, _0x5e0d20) {
                    var _0x46c62a = _0x17ac26;
                    return _0x3adc7d[_0x46c62a(0x391)](_0x20352e, _0x5e0d20);
                },
                'ZCpDg': function (_0x4ecc9f, _0x13c606) {
                    return _0x4ecc9f * _0x13c606;
                }
            };
            continue;
        case '9':
            this[_0x17ac26(0x640)] = function () {
                var _0x4d6431 = _0x17ac26, _0x53da12 = _0x4d6431(0x33c)[_0x4d6431(0x523)]('|'), _0x4d08b9 = 0x0;
                while (!![]) {
                    switch (_0x53da12[_0x4d08b9++]) {
                    case '0':
                        var _0x2e4eb4 = _0x2e14ce[_0x4d6431(0x645)](parseInt, _0x3f0e29[_0x4d6431(0x443)](0x4, 0x2), 0x10);
                        continue;
                    case '1':
                        _0x4115f2[0x4] = _0x2e14ce[_0x4d6431(0x155)](_0x2e14ce['eYNPy'](_0x1feeb9, (0x1 - _0x1feeb9) * _0x15f487), _0x2e14ce[_0x4d6431(0x2cf)](_0x261563, _0xab0383));
                        continue;
                    case '2':
                        var _0x3f0e29 = this['hexString']()[_0x4d6431(0x468)]('#', '');
                        continue;
                    case '3':
                        var _0x1feeb9 = 0.7152;
                        continue;
                    case '4':
                        _0x4115f2[0x5] = _0x2e14ce['lPOlD'](_0x2e14ce[_0x4d6431(0x1e8)](_0xbf4b84, _0x2e14ce[_0x4d6431(0x2cf)](_0xbf4b84, _0x15f487)), _0x2e14ce['ykrqz'](_0x1f1ce2, _0xab0383));
                        continue;
                    case '5':
                        return new NFColor(Math[_0x4d6431(0x422)](_0x3c5051), Math[_0x4d6431(0x422)](_0x2f924c), Math['round'](_0xd09ea3), 0x1);
                    case '6':
                        var _0x59bad4 = _0x2e14ce[_0x4d6431(0x21d)](_0x2e14ce[_0x4d6431(0x340)](_0x2e14ce[_0x4d6431(0x6d8)](parseInt, _0x59bad4) % 0x168, 0x168), 0x168);
                        continue;
                    case '7':
                        var _0xbf4b84 = 0.0722;
                        continue;
                    case '8':
                        var _0x4508b0 = _0x2e14ce[_0x4d6431(0x21b)](parseInt, _0x3f0e29['substr'](0x2, 0x2), 0x10);
                        continue;
                    case '9':
                        var _0x19bf5d = _0x2e14ce[_0x4d6431(0x38d)](parseInt, _0x3f0e29[_0x4d6431(0x443)](0x0, 0x2), 0x10);
                        continue;
                    case '10':
                        var _0xab0383 = Math[_0x4d6431(0x178)](_0x2e14ce[_0x4d6431(0x25c)](_0x2e14ce[_0x4d6431(0x69a)](_0x59bad4, Math['PI']), 0xb4));
                        continue;
                    case '11':
                        _0x4115f2[0x6] = _0x2e14ce[_0x4d6431(0x1e8)](_0x2e14ce['ZqORg'](_0x52b148, _0x2e14ce['RVvVv'](_0x52b148, _0x15f487)), _0x2e14ce[_0x4d6431(0x327)](0x1, _0x52b148) * _0xab0383);
                        continue;
                    case '12':
                        var _0xd09ea3 = this['clamp'](_0x2e14ce[_0x4d6431(0x340)](_0x2e14ce[_0x4d6431(0x395)](_0x2e14ce['JgZjL'](_0x4115f2[0x6], _0x19bf5d), _0x2e14ce[_0x4d6431(0x373)](_0x4115f2[0x7], _0x4508b0)), _0x2e14ce['JgZjL'](_0x4115f2[0x8], _0x2e4eb4)));
                        continue;
                    case '13':
                        var _0x1f1ce2 = 0.283;
                        continue;
                    case '14':
                        _0x4115f2[0x8] = _0x2e14ce[_0x4d6431(0x395)](_0xbf4b84, _0x2e14ce[_0x4d6431(0x373)](_0x2e14ce[_0x4d6431(0x327)](0x1, _0xbf4b84), _0x15f487)) + _0x2e14ce['hYiER'](_0xbf4b84, _0xab0383);
                        continue;
                    case '15':
                        _0x4115f2[0x1] = _0x2e14ce[_0x4d6431(0x327)](_0x1feeb9, _0x2e14ce[_0x4d6431(0x6af)](_0x1feeb9, _0x15f487)) - _0x2e14ce[_0x4d6431(0x4eb)](_0x1feeb9, _0xab0383);
                        continue;
                    case '16':
                        _0x4115f2[0x0] = _0x2e14ce['eITJy'](_0x52b148, _0x2e14ce['YdYVh'](_0x2e14ce[_0x4d6431(0x402)](0x1, _0x52b148), _0x15f487)) - _0x52b148 * _0xab0383;
                        continue;
                    case '17':
                        var _0x15f487 = Math['cos'](_0x2e14ce[_0x4d6431(0x302)](_0x2e14ce[_0x4d6431(0x16e)](_0x59bad4, Math['PI']), 0xb4));
                        continue;
                    case '18':
                        var _0x2f924c = this[_0x4d6431(0x1ed)](_0x2e14ce[_0x4d6431(0x575)](_0x2e14ce[_0x4d6431(0x16e)](_0x4115f2[0x3], _0x19bf5d) + _0x2e14ce[_0x4d6431(0x4a2)](_0x4115f2[0x4], _0x4508b0), _0x4115f2[0x5] * _0x2e4eb4));
                        continue;
                    case '19':
                        var _0x261563 = 0.14;
                        continue;
                    case '20':
                        _0x4115f2[0x7] = _0x2e14ce[_0x4d6431(0x575)](_0x1feeb9 - _0x1feeb9 * _0x15f487, _0x2e14ce[_0x4d6431(0x30b)](_0x1feeb9, _0xab0383));
                        continue;
                    case '21':
                        var _0x4115f2 = [
                            0x1,
                            0x0,
                            0x0,
                            0x0,
                            0x1,
                            0x0,
                            0x0,
                            0x0,
                            0x1
                        ];
                        continue;
                    case '22':
                        _0x4115f2[0x2] = _0x2e14ce[_0x4d6431(0x31e)](_0x2e14ce['YplUO'](_0xbf4b84, _0x2e14ce[_0x4d6431(0x30b)](_0xbf4b84, _0x15f487)), _0x2e14ce['bbnew'](0x1, _0xbf4b84) * _0xab0383);
                        continue;
                    case '23':
                        var _0x59bad4 = 0xb4;
                        continue;
                    case '24':
                        var _0x425985 = 0.143;
                        continue;
                    case '25':
                        _0x4115f2[0x3] = _0x2e14ce['VSwZe'](_0x2e14ce[_0x4d6431(0x3c2)](_0x52b148, _0x2e14ce[_0x4d6431(0x63e)](_0x52b148, _0x15f487)), _0x2e14ce[_0x4d6431(0x63e)](_0x425985, _0xab0383));
                        continue;
                    case '26':
                        var _0x3c5051 = this[_0x4d6431(0x1ed)](_0x2e14ce[_0x4d6431(0x31e)](_0x2e14ce['GAapW'](_0x2e14ce['mXgtU'](_0x4115f2[0x0], _0x19bf5d), _0x4115f2[0x1] * _0x4508b0), _0x2e14ce[_0x4d6431(0x3af)](_0x4115f2[0x2], _0x2e4eb4)));
                        continue;
                    case '27':
                        var _0x52b148 = 0.2126;
                        continue;
                    }
                    break;
                }
            };
            continue;
        case '10':
            this[_0x17ac26(0x452)] = function () {
                var _0x13383b = _0x17ac26;
                return new NFColor(_0x2e14ce[_0x13383b(0x2e0)](0xff, this['r']), _0x2e14ce[_0x13383b(0x2ad)](0xff, this['g']), 0xff - this['b'], this['a']);
            };
            continue;
        case '11':
            this[_0x17ac26(0x1ed)] = function (_0x31aaa9) {
                var _0x458b96 = _0x17ac26;
                return Math['round'](Math['max'](0x0, Math[_0x458b96(0x27b)](0xff, _0x31aaa9)));
            };
            continue;
        case '12':
            this[_0x17ac26(0x318)] = function () {
                var _0x56a1a1 = _0x17ac26;
                return _0x2e14ce[_0x56a1a1(0x3ad)]('#', _0x2e14ce[_0x56a1a1(0x3ad)](_0x2e14ce[_0x56a1a1(0x42f)](0x0, _0x2e14ce['QMTxQ'](_0x2e14ce[_0x56a1a1(0x6c9)](0x1, 0x8), this['r']))[_0x56a1a1(0x534)](0x10)[_0x56a1a1(0x443)](0x1), _0x2e14ce[_0x56a1a1(0x42f)](0x0, _0x2e14ce[_0x56a1a1(0x36f)](_0x2e14ce['qPxed'](0x1, 0x8), this['g']))[_0x56a1a1(0x534)](0x10)[_0x56a1a1(0x443)](0x1)) + _0x2e14ce['SbcFA'](0x0, _0x2e14ce[_0x56a1a1(0x504)](0x1, 0x8) + this['b'])[_0x56a1a1(0x534)](0x10)[_0x56a1a1(0x443)](0x1));
            };
            continue;
        case '13':
            this['shade'] = function (_0x51e025) {
                var _0x39eaad = _0x17ac26, _0x3eca05 = _0x39eaad(0x2f4)['split']('|'), _0x3021ae = 0x0;
                while (!![]) {
                    switch (_0x3eca05[_0x3021ae++]) {
                    case '0':
                        _0x2bd9de = _0x2e14ce['uuVJT'](_0x2bd9de, 0x0) ? 0x0 : _0x2bd9de;
                        continue;
                    case '1':
                        _0x2bd9de = _0x2e14ce[_0x39eaad(0x4a7)](_0x2bd9de, 0xff) ? 0xff : _0x2bd9de;
                        continue;
                    case '2':
                        var _0x2bd9de = _0x2e14ce[_0x39eaad(0x155)](this['g'], _0x2e14ce[_0x39eaad(0x1f2)](_0x2e14ce[_0x39eaad(0x2cb)](_0x2e14ce[_0x39eaad(0x474)](0x100, this['g']), _0x51e025), 0x64));
                        continue;
                    case '3':
                        _0x127697 = _0x2e14ce['sEKuW'](_0x127697, 0x0) ? 0x0 : _0x127697;
                        continue;
                    case '4':
                        _0x2b915e = _0x2e14ce[_0x39eaad(0x355)](_0x2b915e, 0xff) ? 0xff : _0x2b915e;
                        continue;
                    case '5':
                        return new NFColor(Math[_0x39eaad(0x422)](_0x127697), Math[_0x39eaad(0x422)](_0x2bd9de), Math[_0x39eaad(0x422)](_0x2b915e), this['a']);
                    case '6':
                        var _0x2b915e = _0x2e14ce[_0x39eaad(0x155)](this['b'], _0x2e14ce[_0x39eaad(0x25c)]((0x100 - this['b']) * _0x51e025, 0x64));
                        continue;
                    case '7':
                        _0x127697 = _0x2e14ce[_0x39eaad(0x28f)](_0x127697, 0xff) ? 0xff : _0x127697;
                        continue;
                    case '8':
                        var _0x127697 = _0x2e14ce[_0x39eaad(0x155)](this['r'], _0x2e14ce[_0x39eaad(0x25c)](_0x2e14ce[_0x39eaad(0x553)](_0x2e14ce['gyEbo'](0x100, this['r']), _0x51e025), 0x64));
                        continue;
                    case '9':
                        _0x2b915e = _0x2e14ce['sEKuW'](_0x2b915e, 0x0) ? 0x0 : _0x2b915e;
                        continue;
                    }
                    break;
                }
            };
            continue;
        case '14':
            this[_0x17ac26(0x486)] = function () {
                var _0x1b90e5 = _0x17ac26, _0xc622a5 = Math[_0x1b90e5(0x24d)](this['r'], Math['max'](this['g'], this['b'])), _0x83d980 = Math[_0x1b90e5(0x27b)](this['r'], Math[_0x1b90e5(0x27b)](this['g'], this['b']));
                return _0x2e14ce[_0x1b90e5(0x2dc)](_0x2e14ce[_0x1b90e5(0x6a7)](_0xc622a5, _0x83d980), _0xc622a5);
            };
            continue;
        case '15':
            this['a'] = _0x18404c;
            continue;
        }
        break;
    }
}
const NFColorFromRGBString = _0x56f3df => {
        var _0xe3846f = _0x52102f, _0x104952 = {
                'ESWau': _0xe3846f(0x246),
                'ThcsU': function (_0x1fcd70, _0xd215dc) {
                    return _0x1fcd70(_0xd215dc);
                },
                'xeiSA': function (_0x5266bf, _0x43d115) {
                    return _0x5266bf(_0x43d115);
                },
                'ojpYy': function (_0x6d9cc1, _0x15c84c) {
                    return _0x6d9cc1 === _0x15c84c;
                }
            }, _0x2f316a = _0x104952[_0xe3846f(0x175)][_0xe3846f(0x523)]('|'), _0xe54a6e = 0x0;
        while (!![]) {
            switch (_0x2f316a[_0xe54a6e++]) {
            case '0':
                return new NFColor(_0x443d6a, _0x3f1e2a, _0x13a9e3, _0x18628f);
            case '1':
                var _0x3f1e2a = _0x104952[_0xe3846f(0x216)](parseInt, _0x252630[0x1]);
                continue;
            case '2':
                var _0x13a9e3 = _0x104952[_0xe3846f(0x27d)](parseInt, _0x252630[0x2]);
                continue;
            case '3':
                var _0x443d6a = _0x104952[_0xe3846f(0x27d)](parseInt, _0x252630[0x0]);
                continue;
            case '4':
                var _0x252630 = _0x56f3df[_0xe3846f(0x468)](/rgba?\(/, '')[_0xe3846f(0x468)](/\)/, '')['split'](',');
                continue;
            case '5':
                var _0x18628f = _0x104952[_0xe3846f(0x5ba)](_0x252630[0x3], undefined) ? 0x1 : _0x104952[_0xe3846f(0x27d)](parseFloat, _0x252630[0x3]);
                continue;
            case '6':
                if (!_0x56f3df)
                    return null;
                continue;
            }
            break;
        }
    }, NFColorFromHexString = _0x285fef => {
        var _0x261e9f = _0x52102f, _0x596d4e = {
                'yObSP': function (_0x4191d, _0x346e47) {
                    return _0x4191d(_0x346e47);
                },
                'ssznY': function (_0x3e59d8, _0x3a3d18) {
                    return _0x3e59d8 === _0x3a3d18;
                },
                'VDNpC': function (_0x36b2c8, _0x4f8095) {
                    return _0x36b2c8(_0x4f8095);
                }
            }, _0x2680c3 = '1|3|6|5|0|2|4'[_0x261e9f(0x523)]('|'), _0x577922 = 0x0;
        while (!![]) {
            switch (_0x2680c3[_0x577922++]) {
            case '0':
                var _0x47fe4f = _0x596d4e['yObSP'](parseInt, _0x255243[0x2]);
                continue;
            case '1':
                if (!_0x285fef)
                    return null;
                continue;
            case '2':
                var _0x4c6636 = _0x596d4e[_0x261e9f(0x56a)](_0x255243[0x3], undefined) ? 0x1 : _0x596d4e[_0x261e9f(0x41e)](parseFloat, _0x255243[0x3]);
                continue;
            case '3':
                var _0x255243 = NFHexToRgb(_0x285fef);
                continue;
            case '4':
                return new NFColor(_0x2a9745, _0x4507c9, _0x47fe4f, _0x4c6636);
            case '5':
                var _0x4507c9 = _0x596d4e[_0x261e9f(0x607)](parseInt, _0x255243[0x1]);
                continue;
            case '6':
                var _0x2a9745 = _0x596d4e[_0x261e9f(0x607)](parseInt, _0x255243[0x0]);
                continue;
            }
            break;
        }
    }, convertToHex6Digits = _0x2ce3c0 => {
        var _0x1843a3 = _0x52102f, _0x5a3133 = {
                'QjdvK': function (_0x5a88af, _0x58a3f4) {
                    return _0x5a88af == _0x58a3f4;
                },
                'LZNif': function (_0x5c1f67, _0x5e4a66) {
                    return _0x5c1f67 + _0x5e4a66;
                },
                'XlCXh': function (_0x18a24d, _0x527685) {
                    return _0x18a24d != _0x527685;
                },
                'HBCVU': function (_0x2aa2ad, _0x3409d3) {
                    return _0x2aa2ad > _0x3409d3;
                },
                'AAtJf': function (_0x9cf01a, _0x3fb717) {
                    return _0x9cf01a != _0x3fb717;
                },
                'mqklJ': function (_0x4ae41c, _0x5493aa) {
                    return _0x4ae41c + _0x5493aa;
                }
            };
        if (_0x5a3133[_0x1843a3(0x311)](_0x2ce3c0[_0x1843a3(0x2f5)]('#'), 0x0))
            return _0x2ce3c0;
        if (_0x5a3133['HBCVU'](_0x2ce3c0[_0x1843a3(0x362)], 0x4))
            return _0x2ce3c0;
        return _0x2ce3c0 = _0x2ce3c0[_0x1843a3(0x523)]('')['map'](_0x24397f => {
            var _0x4ea2f2 = _0x1843a3;
            if (_0x5a3133['QjdvK'](_0x24397f, '#'))
                return _0x24397f;
            return _0x5a3133[_0x4ea2f2(0x2ca)](_0x24397f, _0x24397f);
        })[_0x1843a3(0x265)](''), _0x5a3133[_0x1843a3(0x255)](_0x2ce3c0[0x0], '#') && (_0x2ce3c0 = _0x5a3133['mqklJ']('#', _0x2ce3c0)), _0x2ce3c0;
    }, NFHexToRgb = _0x1ab783 => {
        var _0x57d9b0 = _0x52102f;
        return _0x1ab783[_0x57d9b0(0x468)](/^#?([a-f\d])([a-f\d])([a-f\d])$/i, (_0x772de8, _0x1f9418, _0x4fe392, _0x4a6ea1) => '#' + _0x1f9418 + _0x1f9418 + _0x4fe392 + _0x4fe392 + _0x4a6ea1 + _0x4a6ea1)[_0x57d9b0(0x654)](0x1)[_0x57d9b0(0x16b)](/.{2}/g)[_0x57d9b0(0x22a)](_0x51f343 => parseInt(_0x51f343, 0x10));
    }, rgbToHex = _0x2ae1ce => {
        var _0x433a2d = _0x52102f, _0x5c53a9 = {
                'cazdS': function (_0x483795, _0x301cd1) {
                    return _0x483795 === _0x301cd1;
                },
                'kvKUO': function (_0x135005, _0x30d5de) {
                    return _0x135005 + _0x30d5de;
                },
                'AnWEm': function (_0xb1d35f, _0x39e60d) {
                    return _0xb1d35f(_0x39e60d);
                },
                'QQmpl': function (_0x4d5202, _0x518ac3) {
                    return _0x4d5202(_0x518ac3);
                },
                'cAFum': function (_0x3ef1bc, _0x1467c7) {
                    return _0x3ef1bc + _0x1467c7;
                }
            }, _0x4edffb = _0x2ae1ce[_0x433a2d(0x468)](/rgba?\(/, '')[_0x433a2d(0x468)](/\)/, '')[_0x433a2d(0x523)](','), _0x529e22 = parseInt(_0x4edffb[0x0]), _0x8d7d7 = _0x5c53a9[_0x433a2d(0x4b9)](parseInt, _0x4edffb[0x1]), _0x1dba92 = _0x5c53a9[_0x433a2d(0x322)](parseInt, _0x4edffb[0x2]);
        return _0x5c53a9[_0x433a2d(0x32a)]('#', [
            _0x529e22,
            _0x8d7d7,
            _0x1dba92
        ][_0x433a2d(0x22a)](_0x508c58 => {
            var _0xacd936 = _0x433a2d, _0x1c7f6c = _0x508c58[_0xacd936(0x534)](0x10);
            return _0x5c53a9[_0xacd936(0x1a0)](_0x1c7f6c[_0xacd936(0x362)], 0x1) ? _0x5c53a9[_0xacd936(0x6be)]('0', _0x1c7f6c) : _0x1c7f6c;
        })['join'](''));
    }, namedColorToHex = _0x1ed9e4 => {
        var _0x2e14a4 = _0x52102f, _0x4d7daf = { 'UKOxP': _0x2e14a4(0x261) }, _0x2ab603 = document[_0x2e14a4(0x4f1)](_0x4d7daf[_0x2e14a4(0x4b0)])[_0x2e14a4(0x303)]('2d');
        return _0x2ab603[_0x2e14a4(0x641)] = _0x1ed9e4, _0x2ab603[_0x2e14a4(0x641)][_0x2e14a4(0x481)]();
    }, BlackColor = () => {
        return new NFColor(0x0, 0x0, 0x0, 0x1);
    }, GrayColor = () => {
        return new NFColor(0xf5, 0xf5, 0xf5, 0x1);
    }, TransparentColor = () => {
        return new NFColor(0x0, 0x0, 0x0, 0x0);
    }, isBlack = _0x3b538a => {
        var _0x48d078 = _0x52102f, _0x250133 = {
                'pEhcP': function (_0x3256d3, _0x160dd7) {
                    return _0x3256d3 == _0x160dd7;
                },
                'DAHkW': function (_0x24b49f, _0x412061) {
                    return _0x24b49f < _0x412061;
                },
                'NPjhw': function (_0x171375, _0x3d995b) {
                    return _0x171375 < _0x3d995b;
                }
            };
        if (_0x3b538a['a'] !== 0x1)
            return ![];
        return _0x250133[_0x48d078(0x46a)](_0x3b538a['r'], 0x0) && _0x250133[_0x48d078(0x46a)](_0x3b538a['g'], 0x0) && _0x250133[_0x48d078(0x46a)](_0x3b538a['b'], 0x0) || _0x3b538a['r'] < 0x19 && _0x250133[_0x48d078(0x4c5)](_0x3b538a['g'], 0x19) && _0x250133[_0x48d078(0x348)](_0x3b538a['b'], 0x19);
    }, getIgnoredSelectors = _0xfad127 => {
        var _0x53cd42 = _0x52102f, _0x187e87 = {
                'TXnRn': _0x53cd42(0x1b7),
                'pJmFa': _0x53cd42(0x5d3),
                'qBbLx': _0x53cd42(0x4a8),
                'cpKKY': _0x53cd42(0x5d9),
                'wtUaM': _0x53cd42(0x656),
                'flnGp': _0x53cd42(0x1f6),
                'igXOT': '.lozad',
                'UJDZe': _0x53cd42(0x24a),
                'GjIkw': _0x53cd42(0x317),
                'fNLpq': _0x53cd42(0x68d),
                'fIMBD': '.br-lazy',
                'XnVQy': _0x53cd42(0x4be),
                'opfWT': _0x53cd42(0x358),
                'TlnIK': 'a[slot=\x22logo\x22]',
                'zeDix': '.blocks-gallery-item\x20figure',
                'pfNoK': _0x53cd42(0x248),
                'JNRiu': _0x53cd42(0x663),
                'txYpA': _0x53cd42(0x521),
                'xrPys': 'a[href*=\x22search_mode=flex_destinations_search\x22]\x20>\x20span',
                'cXwpL': _0x53cd42(0x4fb),
                'AWxAp': _0x53cd42(0x69b),
                'PrJZX': _0x53cd42(0x3a6),
                'yImqy': _0x53cd42(0x539),
                'SHWvu': _0x53cd42(0x1af),
                'shPTo': _0x53cd42(0x2a8),
                'oRDAd': _0x53cd42(0x48c),
                'DWjcV': 'svg.highcharts-root',
                'pHfTG': _0x53cd42(0x57c),
                'QPvaJ': _0x53cd42(0x17e),
                'ixfLS': _0x53cd42(0x3fa),
                'ZsDJG': 'svg.bdl-CollapsibleSidebar-logoIcon',
                'pnjxr': _0x53cd42(0x48a),
                'Rzzyv': '.render-mode-BIGPIPE\x20code',
                'lZtbM': _0x53cd42(0x4d2),
                'AUZHT': _0x53cd42(0x462),
                'KcdXl': _0x53cd42(0x169),
                'ZONdP': 'ytm-custom-control\x20#player-control-overlay',
                'hKjZT': '.refract-container\x20.addition\x20pre.source',
                'KeqmG': _0x53cd42(0x622),
                'nHPHD': _0x53cd42(0x44d),
                'mcIFI': _0x53cd42(0x540),
                'PBTwJ': _0x53cd42(0x56d),
                'oIfhC': _0x53cd42(0x3b5),
                'EDmPz': _0x53cd42(0x5a3),
                'jvUvZ': _0x53cd42(0x511),
                'iwYYA': 'ol\x20div[style^=\x22background-image\x22]',
                'snpRp': _0x53cd42(0x617),
                'tYHwX': '.c7cjWc',
                'tiZfx': _0x53cd42(0x274),
                'PhqmK': _0x53cd42(0x6c8),
                'PSTjz': _0x53cd42(0x2eb),
                'UhvER': _0x53cd42(0x3a4),
                'leBXJ': _0x53cd42(0x563),
                'JrqRv': '#winnav',
                'YMCHK': _0x53cd42(0x386),
                'TjyUj': _0x53cd42(0x36a),
                'VlAaR': _0x53cd42(0x5fa),
                'IzLjH': _0x53cd42(0x1d8),
                'usoCQ': '.MathJax_Preview',
                'vRMwn': '.MJXc-display',
                'NlmlQ': _0x53cd42(0x57b),
                'bzXJM': '.slick-slide',
                'JAjpv': _0x53cd42(0x3db),
                'ulmVu': _0x53cd42(0x508),
                'fWHti': _0x53cd42(0x39a),
                'CyBoi': 'button.input__settings',
                'SXhRA': _0x53cd42(0x666),
                'EUMrd': _0x53cd42(0x2e9),
                'PwNqo': _0x53cd42(0x6a0),
                'AFNVQ': '.header-logo',
                'pNdEB': '.ninetofive-icon',
                'TBTeY': '.onesignal-bell-svg',
                'osaAV': _0x53cd42(0x423),
                'EsANZ': _0x53cd42(0x26e),
                'iRzYk': '.player_container',
                'PyJbL': '#mw-mf-main-menu-button',
                'YuOew': _0x53cd42(0x524),
                'iuNiz': _0x53cd42(0x328),
                'RqLXS': _0x53cd42(0x4c7),
                'YzFor': _0x53cd42(0x18c),
                'wNDas': _0x53cd42(0x3f7),
                'livcG': _0x53cd42(0x5fd),
                'fabHP': _0x53cd42(0x4bb),
                'JIzxK': _0x53cd42(0x4c6),
                'kzqsJ': _0x53cd42(0x55a),
                'piXff': _0x53cd42(0x289),
                'DNhkJ': _0x53cd42(0x4c0),
                'fzaHY': _0x53cd42(0x389),
                'ONIya': _0x53cd42(0x326),
                'LuiLR': 'figure.thumb_new_image',
                'HSHbY': _0x53cd42(0x160),
                'wksKF': _0x53cd42(0x1c0),
                'zjIkB': _0x53cd42(0x578),
                'VnfWZ': _0x53cd42(0x295),
                'jmWYg': _0x53cd42(0x5c7),
                'rCjQa': '.bm-burger-bars',
                'DfxXM': '.img-fluid',
                'EzuZo': 'select',
                'xsevu': _0x53cd42(0x67b),
                'RleFy': '.LinkCard',
                'fPTdW': '.specList\x20label[for]',
                'RvkSh': _0x53cd42(0x299),
                'ZVcTF': _0x53cd42(0x4dc),
                'YXkxB': _0x53cd42(0x37c),
                'pgGAD': _0x53cd42(0x66a),
                'JBsnM': '.thumbnail',
                'KjQLt': _0x53cd42(0x6b4),
                'TmrAz': _0x53cd42(0x502),
                'OhYwl': _0x53cd42(0x1d0),
                'JedVm': _0x53cd42(0x2f1),
                'IoQph': _0x53cd42(0x4fc),
                'lYsMd': _0x53cd42(0x5f8),
                'seRyz': _0x53cd42(0x40a),
                'IIGJk': _0x53cd42(0x428),
                'hNbtM': _0x53cd42(0x245),
                'FzQJg': _0x53cd42(0x2cd),
                'ltvxg': _0x53cd42(0x18d),
                'WIbyE': '.bb-slider',
                'hhTQm': _0x53cd42(0x562),
                'fbjGP': _0x53cd42(0x34b),
                'HclHm': _0x53cd42(0x52e),
                'OAiie': _0x53cd42(0x1c2),
                'tmztt': _0x53cd42(0x3dd),
                'fsNkw': _0x53cd42(0x473),
                'vsBSm': _0x53cd42(0x5c5),
                'kfysz': _0x53cd42(0x53a),
                'FIXsx': _0x53cd42(0x4bf),
                'wuUAh': _0x53cd42(0x623),
                'iUxKT': '.banner__title',
                'EqqnH': _0x53cd42(0x146),
                'hregc': '#register-tab-view\x20.input',
                'PeKgL': _0x53cd42(0x6d0),
                'RFzwL': _0x53cd42(0x18b),
                'cFshy': '.solve-button',
                'hbsMw': _0x53cd42(0x492),
                'UdHCC': '.up-vote',
                'hECtP': _0x53cd42(0x48e),
                'wwTNI': '.icon-questionmark',
                'mMMZE': _0x53cd42(0x6a1),
                'Hihqk': _0x53cd42(0x28d),
                'SKRrS': '.menu-text',
                'RrkQr': '.gradient-header',
                'ioUsz': '.primary-link',
                'hdOAP': _0x53cd42(0x6d6),
                'Nqvru': '.related-products\x20.gallery-item\x20.product-img.orange-color',
                'pSlFY': _0x53cd42(0x582),
                'STlkB': _0x53cd42(0x198),
                'awTug': _0x53cd42(0x3f8),
                'Atxmt': _0x53cd42(0x3ee),
                'uoMdO': _0x53cd42(0x6d2),
                'gEqbJ': _0x53cd42(0x4f2),
                'rrkbU': '.title-mint',
                'bTfMv': _0x53cd42(0x60b),
                'TKUOn': _0x53cd42(0x32d),
                'SBprT': _0x53cd42(0x68b),
                'pofqE': _0x53cd42(0x616),
                'SBHYo': _0x53cd42(0x33e),
                'sydQH': '.view-text',
                'ZKIjv': '.right',
                'Ysqzh': _0x53cd42(0x19b),
                'OoxPl': '.table-no',
                'sjfhL': _0x53cd42(0x421),
                'NbRDO': '.table-partial',
                'yPpeg': _0x53cd42(0x570),
                'nunvn': _0x53cd42(0x406),
                'oTldN': _0x53cd42(0x42e),
                'vSTcF': _0x53cd42(0x313),
                'TuXCO': _0x53cd42(0x3e2),
                'sfUcW': '.button-modulebutton3Gm3c',
                'uLsdP': _0x53cd42(0x5ac),
                'ruhVH': _0x53cd42(0x22b),
                'hwtcI': '.mjx-chtml',
                'erewD': '.amp-fn-content-wrapper\x20p',
                'gzUAG': _0x53cd42(0x6c0),
                'pZkdf': _0x53cd42(0x230),
                'YeIrn': _0x53cd42(0x14d),
                'ZDIzZ': _0x53cd42(0x6ad),
                'fCNpR': '.timeline-filter\x20.download-results-by-year-button',
                'PdCsH': _0x53cd42(0x699),
                'UVZvo': _0x53cd42(0x40e),
                'xdDgy': _0x53cd42(0x2fe),
                'PaICG': '.icon-xbox-game-studios',
                'QQIbZ': _0x53cd42(0x350),
                'FupTd': _0x53cd42(0x3dc),
                'fAafv': _0x53cd42(0x308),
                'LkeWU': _0x53cd42(0x655),
                'vyDkP': '#avo-facets',
                'JRepq': _0x53cd42(0x4e2),
                'deBjf': _0x53cd42(0x572),
                'mgtqb': 'button.toast',
                'JtziD': '.v-dialog__content',
                'JJBmx': _0x53cd42(0x5b8),
                'mtmnF': '.search-modal',
                'xQhxh': _0x53cd42(0x43e),
                'tPJUC': '.sidebar-search\x20>\x20input[type=\x22search\x22]',
                'lLevJ': _0x53cd42(0x47c),
                'YvpRR': _0x53cd42(0x620),
                'ryKCN': _0x53cd42(0x321),
                'YoyzU': _0x53cd42(0x532),
                'YMATo': 'div.nav',
                'vVebt': _0x53cd42(0x6c6),
                'kKKok': _0x53cd42(0x3bc),
                'yZQLu': _0x53cd42(0x30f),
                'EbasB': _0x53cd42(0x61e),
                'lyXNg': _0x53cd42(0x472),
                'XgRAr': '.side-title',
                'JNufU': _0x53cd42(0x3e7),
                'tPPuG': _0x53cd42(0x336),
                'cGrvv': '.buy__mask',
                'cIgIU': _0x53cd42(0x162),
                'jiIdm': _0x53cd42(0x4c1),
                'bgjTA': _0x53cd42(0x1f7),
                'ayIFk': _0x53cd42(0x631),
                'nDrBs': '#chart_final',
                'WVnCw': _0x53cd42(0x306),
                'JjlUW': _0x53cd42(0x63f),
                'hXGdJ': _0x53cd42(0x496),
                'vLYUg': _0x53cd42(0x21c),
                'iEDJo': _0x53cd42(0x555),
                'TnmEB': _0x53cd42(0x1a1),
                'YNjro': _0x53cd42(0x52a),
                'MVBfh': _0x53cd42(0x154),
                'hRhua': _0x53cd42(0x414),
                'nighg': _0x53cd42(0x15d),
                'LEfMV': '.bili-video-card__mask',
                'OkJkn': _0x53cd42(0x441),
                'alofi': _0x53cd42(0x5bf),
                'MXbmB': _0x53cd42(0x222),
                'RjOol': _0x53cd42(0x32e),
                'vWeqx': _0x53cd42(0x647)
            };
        if (!_0xfad127)
            return [];
        var _0x54c70e = {
            'default': [
                '.ProseMirror',
                _0x53cd42(0x1b4),
                _0x53cd42(0x4b3),
                _0x187e87[_0x53cd42(0x4a0)],
                'img[data-src]',
                _0x187e87[_0x53cd42(0x5b6)],
                _0x187e87[_0x53cd42(0x5d5)],
                _0x187e87[_0x53cd42(0x60c)],
                _0x187e87['wtUaM'],
                _0x53cd42(0x36a),
                _0x187e87['flnGp'],
                _0x187e87[_0x53cd42(0x34a)],
                _0x187e87[_0x53cd42(0x3c6)],
                _0x187e87[_0x53cd42(0x5ed)],
                _0x187e87[_0x53cd42(0x1aa)],
                _0x53cd42(0x19d),
                _0x187e87['fIMBD'],
                _0x187e87[_0x53cd42(0x298)],
                _0x187e87[_0x53cd42(0x559)]
            ],
            'm.gsmarena.com': ['.noUi-connect'],
            'appstoreconnect.apple.com': [
                '#salestrends\x20.nav-link',
                _0x187e87[_0x53cd42(0x5e7)]
            ],
            'lux.camera': [_0x187e87[_0x53cd42(0x1b8)]],
            'shortcutsgallery.com': [
                _0x187e87[_0x53cd42(0x61b)],
                _0x187e87['JNRiu'],
                _0x187e87[_0x53cd42(0x243)]
            ],
            'www.airbnb.com': [_0x187e87['xrPys']],
            'apple.com': [
                _0x53cd42(0x6b0),
                _0x187e87['cXwpL'],
                _0x187e87[_0x53cd42(0x41d)]
            ],
            'my.jdownloader.org': [_0x53cd42(0x3c7)],
            'cydia.saurik.com': [
                '.cytyle-flat\x20#output',
                _0x187e87[_0x53cd42(0x2e7)],
                _0x187e87[_0x53cd42(0x189)]
            ],
            'shop.shpresa.al': [
                'span.woocommerce-Price-amount',
                _0x187e87[_0x53cd42(0x1a3)]
            ],
            'www.messenger.com': [
                _0x187e87[_0x53cd42(0x1c9)],
                _0x53cd42(0x5db),
                _0x187e87['oRDAd']
            ],
            'app.box.com': [
                _0x187e87[_0x53cd42(0x1dd)],
                _0x187e87['pHfTG'],
                _0x53cd42(0x2c2),
                'svg.bdl-IconCaretRound',
                _0x187e87['QPvaJ'],
                _0x187e87[_0x53cd42(0x696)],
                _0x187e87[_0x53cd42(0x4c4)]
            ],
            'www.linkedin.com': [
                _0x187e87[_0x53cd42(0x5ec)],
                _0x187e87[_0x53cd42(0x349)],
                _0x187e87['lZtbM']
            ],
            'drive.google.com': [
                _0x53cd42(0x2e4),
                _0x187e87[_0x53cd42(0x25d)],
                _0x187e87[_0x53cd42(0x68f)]
            ],
            'iosgods.com': [_0x53cd42(0x5d1)],
            'm.youtube.com': [_0x187e87[_0x53cd42(0x377)]],
            'bitbucket.org': [_0x187e87['hKjZT']],
            'www.rottentomatoes.com': [
                '.tpSubtitles',
                _0x187e87[_0x53cd42(0x482)],
                _0x187e87[_0x53cd42(0x4d6)]
            ],
            'ebay.com': [
                _0x53cd42(0x53b),
                _0x187e87[_0x53cd42(0x41a)]
            ],
            'google.com': [
                _0x187e87[_0x53cd42(0x26a)],
                _0x187e87[_0x53cd42(0x5ae)],
                _0x187e87['EDmPz'],
                _0x187e87[_0x53cd42(0x356)],
                _0x53cd42(0x1cd),
                'h3.LC20lb',
                '.yuRUbf\x20>\x20a',
                _0x187e87['iwYYA'],
                _0x53cd42(0x549),
                _0x187e87[_0x53cd42(0x5c1)],
                _0x187e87[_0x53cd42(0x4f8)],
                _0x187e87['tiZfx'],
                _0x187e87[_0x53cd42(0x1ec)],
                _0x187e87['PSTjz']
            ],
            'docs.google.com': [
                _0x187e87[_0x53cd42(0x566)],
                _0x187e87[_0x53cd42(0x68f)],
                _0x53cd42(0x37b),
                _0x187e87[_0x53cd42(0x62f)]
            ],
            'play.google.com': [_0x53cd42(0x145)],
            'www.redmondpie.com': [_0x187e87[_0x53cd42(0x2c1)]],
            'www.androidauthority.com': [_0x187e87['YMCHK']],
            'mashtips.com': [
                _0x187e87[_0x53cd42(0x2fa)],
                _0x187e87['VlAaR']
            ],
            'olcayaksoy.keenetic.pro': [
                '.ndm-chart__image-wrapper\x20svg',
                _0x187e87[_0x53cd42(0x629)]
            ],
            'lamar.edu': [
                _0x187e87[_0x53cd42(0x464)],
                _0x53cd42(0x5bb),
                _0x187e87[_0x53cd42(0x23e)]
            ],
            'habr.com': [_0x187e87['NlmlQ']],
            'giaxe.2banh.vn': [
                _0x187e87[_0x53cd42(0x197)],
                _0x187e87[_0x53cd42(0x4b6)],
                _0x187e87[_0x53cd42(0x558)],
                _0x187e87[_0x53cd42(0x157)]
            ],
            'yandex.com': [
                _0x187e87[_0x53cd42(0x221)],
                _0x187e87[_0x53cd42(0x4f9)],
                _0x53cd42(0x1d4),
                _0x187e87[_0x53cd42(0x2bd)],
                _0x187e87[_0x53cd42(0x232)]
            ],
            'yandex.ru': [
                _0x53cd42(0x39a),
                _0x187e87[_0x53cd42(0x4f9)],
                '.actions__button-image',
                _0x187e87[_0x53cd42(0x2bd)],
                _0x187e87['EUMrd']
            ],
            'journals.biologists.com': [_0x187e87['PwNqo']],
            '9to5mac.com': [
                _0x187e87[_0x53cd42(0x1db)],
                _0x187e87[_0x53cd42(0x3aa)]
            ],
            'www.igeeksblog.com': [_0x187e87[_0x53cd42(0x604)]],
            'bwt.cbp.gov': [
                _0x53cd42(0x3ab),
                _0x187e87[_0x53cd42(0x342)]
            ],
            'covid19.mohp.gov.np': [_0x187e87[_0x53cd42(0x46b)]],
            'vimeo.com': [_0x187e87['iRzYk']],
            'www.diffchecker.com': [_0x53cd42(0x590)],
            'wikipedia.org': [
                _0x53cd42(0x47d),
                _0x187e87[_0x53cd42(0x4e9)],
                _0x187e87['YuOew'],
                _0x187e87[_0x53cd42(0x3d2)],
                _0x187e87[_0x53cd42(0x69e)],
                _0x187e87[_0x53cd42(0x2ea)],
                _0x187e87[_0x53cd42(0x39d)],
                _0x187e87[_0x53cd42(0x410)],
                _0x53cd42(0x3b4),
                '.lazy-image-placeholder',
                _0x53cd42(0x570)
            ],
            'fmkorea.com': [
                _0x187e87[_0x53cd42(0x310)],
                _0x187e87[_0x53cd42(0x506)],
                _0x187e87[_0x53cd42(0x3e3)],
                _0x53cd42(0x446)
            ],
            'www.cotopaxi.com': [
                _0x53cd42(0x20b),
                _0x187e87[_0x53cd42(0x3c1)],
                _0x187e87['DNhkJ'],
                _0x187e87[_0x53cd42(0x195)],
                _0x187e87[_0x53cd42(0x235)]
            ],
            'www.hdblog.it': [
                _0x187e87['LuiLR'],
                _0x187e87[_0x53cd42(0x1de)],
                _0x187e87['wksKF'],
                _0x187e87[_0x53cd42(0x186)]
            ],
            'www.hdmotori.it': [
                _0x187e87[_0x53cd42(0x1d2)],
                _0x187e87[_0x53cd42(0x1de)],
                _0x187e87['wksKF'],
                _0x187e87['zjIkB'],
                _0x53cd42(0x415)
            ],
            'fontawesome.com': [_0x187e87['VnfWZ']],
            'www.ynet.co.il': [_0x187e87[_0x53cd42(0x465)]],
            'm.ynet.co.il': [_0x187e87['rCjQa']],
            'apexapr.mu': [
                _0x187e87['DfxXM'],
                _0x187e87[_0x53cd42(0x23f)]
            ],
            'www.liverpool.ac.uk': ['#continue-button'],
            'www.galaxy.mu': [_0x53cd42(0x2d8)],
            'zhihu.com': [
                _0x187e87[_0x53cd42(0x6a4)],
                _0x187e87[_0x53cd42(0x371)]
            ],
            'telegram.org': [_0x53cd42(0x153)],
            'kakaku.com': [_0x187e87['fPTdW']],
            'www.dateks.lv': [_0x187e87[_0x53cd42(0x6d5)]],
            'www.paypal.com': [_0x187e87[_0x53cd42(0x320)]],
            'www.samsungeshop.com.cn': [
                '.icon-contentFixedh5',
                _0x187e87[_0x53cd42(0x58f)]
            ],
            'www.kiiroo.com': [_0x187e87['pgGAD']],
            'm.i-m-all.com': [
                _0x187e87[_0x53cd42(0x432)],
                _0x53cd42(0x290)
            ],
            'www.dynamed.com': [_0x187e87[_0x53cd42(0x5cb)]],
            'calendar.google.com': [
                _0x53cd42(0x177),
                _0x187e87[_0x53cd42(0x416)]
            ],
            'xnxx.com': [
                '.icon',
                _0x187e87[_0x53cd42(0x31b)],
                _0x187e87[_0x53cd42(0x19c)],
                _0x187e87['IoQph']
            ],
            'msearch.shopping.naver.com': [_0x53cd42(0x548)],
            'www.macrumors.com': [
                _0x187e87[_0x53cd42(0x2ba)],
                _0x187e87['seRyz']
            ],
            'www.24h.com.vn': [
                _0x187e87[_0x53cd42(0x2e1)],
                _0x187e87[_0x53cd42(0x31a)]
            ],
            'www.thedailybeast.com': [_0x187e87[_0x53cd42(0x538)]],
            'thuthuatjb.com': [
                _0x187e87[_0x53cd42(0x4c2)],
                _0x53cd42(0x53c)
            ],
            'granatovyjablko.cz': [_0x187e87['WIbyE']],
            'investor.apple.com': [
                _0x53cd42(0x54c),
                '.list--reset',
                _0x53cd42(0x300),
                _0x187e87[_0x53cd42(0x3f0)],
                '.module_container',
                _0x187e87[_0x53cd42(0x5cf)]
            ],
            'finam.ru': [
                _0x187e87['HclHm'],
                '.fhr_mobileIconClose',
                _0x53cd42(0x689),
                _0x187e87['HclHm'],
                _0x53cd42(0x3cb)
            ],
            'wizzair.com': [
                '.content-page__title-bar',
                _0x187e87['OAiie'],
                _0x53cd42(0x6d4),
                _0x53cd42(0x4bf),
                _0x187e87[_0x53cd42(0x35d)],
                _0x187e87[_0x53cd42(0x693)],
                _0x187e87[_0x53cd42(0x5f6)],
                _0x187e87['kfysz'],
                '.accordion-item__header',
                _0x187e87[_0x53cd42(0x624)],
                _0x187e87[_0x53cd42(0x3d3)],
                '.rf-search-tools__title',
                _0x187e87[_0x53cd42(0x64e)]
            ],
            'weather.com': [_0x187e87[_0x53cd42(0x66f)]],
            'www.kvakil.me': [
                _0x53cd42(0x635),
                _0x187e87['hregc']
            ],
            'appstoreconnect.apple.com': [_0x187e87[_0x53cd42(0x418)]],
            'conquest.mathusee.com': [_0x187e87[_0x53cd42(0x5b9)]],
            'developer.apple.com': [
                _0x187e87[_0x53cd42(0x447)],
                _0x187e87['hbsMw'],
                _0x187e87[_0x53cd42(0x2a6)],
                _0x187e87['hECtP'],
                _0x187e87['wwTNI'],
                _0x187e87[_0x53cd42(0x20e)]
            ],
            'amazon.com': [
                _0x53cd42(0x5d4),
                _0x187e87['Hihqk']
            ],
            'www.ingrooves.com': [
                _0x53cd42(0x556),
                _0x187e87[_0x53cd42(0x46e)],
                _0x187e87[_0x53cd42(0x456)]
            ],
            'www.sony.de': [
                _0x187e87[_0x53cd42(0x37a)],
                _0x187e87[_0x53cd42(0x6ac)],
                _0x187e87[_0x53cd42(0x275)],
                _0x53cd42(0x24c)
            ],
            'apnews.com': [
                _0x53cd42(0x365),
                _0x187e87[_0x53cd42(0x5af)],
                _0x53cd42(0x4e8),
                _0x187e87[_0x53cd42(0x4bc)]
            ],
            'www.elcorteingles.es': [_0x187e87['awTug']],
            'www.br.de': [_0x187e87[_0x53cd42(0x339)]],
            'www.twisto.cz': [
                _0x187e87[_0x53cd42(0x5c6)],
                _0x53cd42(0x308),
                _0x187e87['gEqbJ']
            ],
            '365.bank': [
                _0x187e87[_0x53cd42(0x5a1)],
                _0x187e87['bTfMv'],
                _0x53cd42(0x4ee),
                _0x187e87[_0x53cd42(0x1b3)]
            ],
            'www.toyota.com': [_0x187e87[_0x53cd42(0x4b4)]],
            'm.ilbe.com': [_0x187e87[_0x53cd42(0x64a)]],
            'm.albamon.com': [
                _0x187e87['SBHYo'],
                _0x187e87[_0x53cd42(0x458)]
            ],
            'www.mobily.com.sa': [
                _0x187e87['ZKIjv'],
                _0x187e87[_0x53cd42(0x2f6)]
            ],
            'en.m.wikipedia.org': [
                _0x53cd42(0x5f1),
                _0x187e87[_0x53cd42(0x681)],
                _0x187e87[_0x53cd42(0x257)],
                _0x187e87['NbRDO'],
                _0x187e87[_0x53cd42(0x1ae)]
            ],
            'www.alsscan.com': [_0x187e87['nunvn']],
            'www.trendevice.com': [
                _0x187e87[_0x53cd42(0x4a6)],
                _0x187e87[_0x53cd42(0x233)],
                _0x187e87[_0x53cd42(0x2bc)]
            ],
            'www.thread.com': [
                _0x187e87[_0x53cd42(0x5e0)],
                _0x187e87['uLsdP'],
                _0x187e87[_0x53cd42(0x587)]
            ],
            'math.nakaken88.com': [
                _0x187e87['hwtcI'],
                _0x53cd42(0x583)
            ],
            'variety.com': [_0x187e87[_0x53cd42(0x332)]],
            'pubmed.ncbi.nlm.nih.gov': [
                _0x187e87[_0x53cd42(0x6d3)],
                _0x53cd42(0x542),
                _0x187e87['pZkdf'],
                _0x187e87[_0x53cd42(0x170)],
                _0x187e87[_0x53cd42(0x28b)],
                _0x187e87[_0x53cd42(0x4ad)]
            ],
            'www.city.hiroshima.lg.jp': [_0x187e87[_0x53cd42(0x5f7)]],
            'minecraft.net': [
                _0x53cd42(0x2ed),
                _0x187e87[_0x53cd42(0x68e)],
                _0x187e87[_0x53cd42(0x2d7)],
                _0x187e87['PaICG']
            ],
            'powerlanguage.co.uk': [_0x187e87[_0x53cd42(0x23d)]],
            'neverinstall.com': [
                _0x187e87['FupTd'],
                _0x187e87[_0x53cd42(0x576)]
            ],
            'cegepgranby.omnivox.ca': [_0x187e87[_0x53cd42(0x3fe)]],
            'www.avocadostore.de': [
                _0x187e87[_0x53cd42(0x39f)],
                _0x187e87[_0x53cd42(0x388)]
            ],
            'www.media.hiroshima-u.ac.jp': [_0x187e87['deBjf']],
            'www.mimeophotos.com': [_0x53cd42(0x688)],
            'www.geeksforgeeks.org': [_0x187e87[_0x53cd42(0x30c)]],
            'www.bnext.com.tw': [_0x187e87['JtziD']],
            'www.cnrtl.fr': [_0x187e87[_0x53cd42(0x200)]],
            'www.frandroid.com': [_0x187e87['mtmnF']],
            'issuein.org': [_0x187e87[_0x53cd42(0x506)]],
            'greasyfork.org': [
                _0x187e87['xQhxh'],
                _0x187e87[_0x53cd42(0x284)]
            ],
            'www.desmos.com': [_0x53cd42(0x58b)],
            'discord.com': [
                _0x187e87['lLevJ'],
                _0x187e87['YvpRR']
            ],
            'www.therakyatpost.com': [_0x187e87[_0x53cd42(0x16d)]],
            'm.bboom.naver.com': [
                _0x187e87[_0x53cd42(0x612)],
                _0x187e87[_0x53cd42(0x47a)],
                _0x187e87[_0x53cd42(0x453)],
                _0x53cd42(0x567),
                _0x187e87[_0x53cd42(0x4fa)]
            ],
            'm.map.naver.com': [
                _0x187e87[_0x53cd42(0x2a0)],
                _0x187e87[_0x53cd42(0x53d)]
            ],
            'm.uncyclopedia.kr': [
                _0x53cd42(0x2f2),
                _0x187e87[_0x53cd42(0x347)]
            ],
            'news.kbs.co.kr': [_0x53cd42(0x254)],
            'thesweetsetup.com': [_0x187e87[_0x53cd42(0x2b0)]],
            'm.cafe.naver.com': [_0x187e87[_0x53cd42(0x16a)]],
            'winxp.vercel.app': [_0x187e87['tPPuG']],
            'developer.salesforce.com': [_0x187e87[_0x53cd42(0x431)]],
            'www.quadlockcase.com': [_0x187e87[_0x53cd42(0x398)]],
            'www.startech.com': [_0x187e87['cIgIU']],
            'www.pixelmator.com': [_0x187e87[_0x53cd42(0x237)]],
            'www.maildesigner365.com': [_0x187e87['bgjTA']],
            'www.mql5.com': [_0x187e87[_0x53cd42(0x22c)]],
            'www.thinkybits.com': [
                _0x187e87[_0x53cd42(0x183)],
                _0x187e87['WVnCw']
            ],
            'www.letsgojp.com': [_0x53cd42(0x161)],
            'map.kakao.com': [_0x187e87[_0x53cd42(0x27a)]],
            'www.merkur.de': [_0x187e87[_0x53cd42(0x4ea)]],
            'www.24hamburg.de': [
                _0x53cd42(0x496),
                '.id-HeaderDoubleGum-actions'
            ],
            'beta.character.ai': [_0x187e87['vLYUg']],
            'newsensations.com': [_0x187e87[_0x53cd42(0x49f)]],
            'tesla.com': [
                _0x187e87[_0x53cd42(0x3c0)],
                _0x187e87[_0x53cd42(0x50b)],
                '.filter-INTERIOR'
            ],
            'hyperx.com': [
                _0x53cd42(0x5de),
                _0x187e87[_0x53cd42(0x596)]
            ],
            'jsonformatter.curiousconcept.com': [
                _0x187e87['hRhua'],
                _0x53cd42(0x4a9)
            ],
            'ingame.de': [_0x187e87[_0x53cd42(0x240)]],
            'search.bilibili.com': [_0x187e87[_0x53cd42(0x29f)]],
            'www.bilibili.com': [_0x187e87[_0x53cd42(0x29f)]],
            'mygamatoto.com': [_0x187e87['OkJkn']],
            'cloud.timeedit.net': [_0x187e87[_0x53cd42(0x52d)]],
            'openweb.jac.yahoosandbox.com': [_0x187e87[_0x53cd42(0x695)]],
            'www.axess.mu': [_0x187e87[_0x53cd42(0x331)]],
            'sony.at': [_0x53cd42(0x273)]
        };
        const _0x5c5bce = _0x54c70e[_0x53cd42(0x1c5)];
        let _0x5d7284 = _0x5c5bce[_0x53cd42(0x5cc)](_0x54c70e[_0xfad127] ? _0x54c70e[_0xfad127] : []), _0x181432 = getMainDomain(_0xfad127);
        _0x5d7284 = _0x5d7284[_0x53cd42(0x5cc)](_0x54c70e[_0x181432] ? _0x54c70e[_0x181432] : []);
        let _0x3b87ba = [
            _0x187e87[_0x53cd42(0x3b8)],
            _0x53cd42(0x672),
            _0x53cd42(0x5f5)
        ];
        for (domain of _0x3b87ba) {
            if (_0x181432['startsWith'](domain)) {
                let _0x26a0d7 = _0xfad127[_0x53cd42(0x654)](0x0, _0xfad127[_0x53cd42(0x2f5)](_0x181432));
                _0x181432 = domain + _0x53cd42(0x3be);
                if (_0x54c70e[_0x181432])
                    _0x5d7284 = _0x5d7284[_0x53cd42(0x5cc)](_0x54c70e[_0x181432]);
                let _0x3b97f1 = _0x26a0d7 + _0x181432;
                if (_0x54c70e[_0x3b97f1])
                    _0x5d7284 = _0x5d7284[_0x53cd42(0x5cc)](_0x54c70e[_0x3b97f1]);
            }
        }
        return [...new Set(_0x5d7284)];
    }, getCustomCss = _0xa13be => {
        var _0x4c9bf1 = _0x52102f, _0x218e30 = {
                'Vzymq': function (_0x26db00, _0x21c916) {
                    return _0x26db00(_0x21c916);
                },
                'HvnFf': _0x4c9bf1(0x647),
                'GrNQN': _0x4c9bf1(0x5f5),
                'uUZfq': function (_0x23da34, _0x2644f8) {
                    return _0x23da34 + _0x2644f8;
                },
                'bjenQ': _0x4c9bf1(0x1c5)
            };
        let _0xad2bd5 = {
                'google.com': _0x4c9bf1(0x5bc),
                'mudfish.net': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navbar-default\x20.navbar-toggle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'hyperx.com': _0x4c9bf1(0x470),
                'meduza.io': _0x4c9bf1(0x18e),
                'm.bboom.naver.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bundle_sc\x20.u_hc,\x20.dsc\x20.u_hc{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'dev.quranwbw.com': _0x4c9bf1(0x25f),
                'www.kakaopay.com': _0x4c9bf1(0x344),
                'm.map.kakao.com': _0x4c9bf1(0x574),
                'map.kakao.com': _0x4c9bf1(0x49d),
                'dekang.en.made-in-china.com': _0x4c9bf1(0x665),
                'www.boxofficemojo.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mojo-group-label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.mql5.com': _0x4c9bf1(0x628),
                'indominusbyte.github.io': _0x4c9bf1(0x4da),
                'tesla.com': _0x4c9bf1(0x407),
                'www.tilannehuone.fi': _0x4c9bf1(0x48d),
                'my.contabo.com': _0x4c9bf1(0x41b),
                'contabo-status.com': _0x4c9bf1(0x2b1),
                'mnews.sbs.co.kr': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.w_header\x20.b_menu\x20strong,\x20.w_header\x20.w_aside\x20.b_close\x20strong,\x20.b_home\x20strong,\x20\x20.b_scrap\x20strong,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.b_live\x20strong,\x20.w_header\x20.w_aside\x20.w_quick\x20a.b_schedule\x20strong:before,\x20.w_header\x20.w_aside\x20.w_quick\x20a\x20strong:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'd.comenity.net': _0x4c9bf1(0x52b),
                'cloud.timeedit.net': _0x4c9bf1(0x1a4),
                'mygamatoto.com': _0x4c9bf1(0x14e),
                'thesweetsetup.com': _0x4c9bf1(0x52c),
                'app.giftistar.net': _0x4c9bf1(0x65d),
                'www.desmos.com': _0x4c9bf1(0x33a),
                'www.manualslib.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pdf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'news.kbs.co.kr': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.quick-menu-swiper:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb-btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'userbenchmark.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.headergrad,\x20.select2-container\x20.select2-choice\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn-default-3d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pgbg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(44,\x20111,\x2026)\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'substack.com': _0x4c9bf1(0x3a7),
                'www.starfielddb.com': _0x4c9bf1(0x471),
                'deepl.com': _0x4c9bf1(0x343),
                'www.merkur.de': _0x4c9bf1(0x63b),
                'lakinkonieczny.wordpress.com': _0x4c9bf1(0x1e4),
                'www.24hamburg.de': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.id-MainNavigation-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.precisionnutrition.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pn-page--front:last-of-type,\x20.pn-page--front:first-of-type\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.thinkybits.com': _0x4c9bf1(0x244),
                'www.barrons.com': _0x4c9bf1(0x176),
                'm.genk.vn': _0x4c9bf1(0x367),
                'jsonformatter.curiousconcept.com': _0x4c9bf1(0x510),
                'attiora.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.invest\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'tronscan.org': _0x4c9bf1(0x619),
                'web.moneylover.me': _0x4c9bf1(0x598),
                'www.cowellsgc.co.uk': _0x4c9bf1(0x5e4),
                'instapundit.com': _0x4c9bf1(0x440),
                'www.ikea.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20body\x20#onetrust-consent-sdk\x20#onetrust-banner-sdk\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-ratings-bar,\x20.pip-product-information-section\x20.pip-chunky-header__icon,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-click-and-collect__icon,\x20.pip-stockcheck__icon,\x20.pip-btn__label,\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[aria-label=\x22Save\x20to\x20shopping\x20list\x22]\x20>\x20span\x20>\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-product-information-section\x20.pip-chunky-header__title,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-product-information-section\x20.pip-average-rating__reviews,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pip-header-section__title--big\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'tekno.10terbaik.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'issuein.org': _0x4c9bf1(0x517),
                'www.cnrtl.fr': _0x4c9bf1(0x683),
                'greasyfork.org': _0x4c9bf1(0x31f),
                'www.thomann.de': _0x4c9bf1(0x434),
                'brmgroups.com': _0x4c9bf1(0x543),
                'rnfirebase.io': _0x4c9bf1(0x309),
                'forgetfulbc.blogspot.com': _0x4c9bf1(0x4db),
                'techno.yandex.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yalm\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'fleshtest.com': _0x4c9bf1(0x167),
                'www.bnext.com.tw': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.v-application\x20.grey.lighten-5,\x20.theme--light.v-light,\x20.theme--light.v-card,\x20.theme--light.v-sheet{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.v-btn__content,\x20.theme--light.v-list-item:not(.v-list-item--active):not(.v-list-item--disabled),\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme--light.v-card,\x20.v-application\x20.black--text,\x20.v-application\x20.grey--text.text--darken-3,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme--light.v-card\x20.v-card__subtitle,\x20.theme--light.v-card>.v-card__text{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MyIcon\x20i[data-v-2e1cc9c9]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mimeophotos.com': _0x4c9bf1(0x659),
                'www.geeksforgeeks.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ql-img-inline-formula,\x20button.toast\x20*,\x20.toast:after,\x20.toast:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'huggingface.co': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.overview-card-wrapper,\x20.bg-white,\x20.bg-gradient-to-t,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20[multiple],\x20[type=date],\x20[type=datetime-local],\x20[type=email],\x20[type=month],\x20[type=number],\x20[type=password],\x20[type=search],\x20[type=tel],\x20[type=text],\x20[type=time],\x20[type=url],\x20[type=week],\x20select,\x20textarea\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tag\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tab-alternate.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightblue\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-gray-50\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-black,\x20.text-gray-800,\x20.prose.prose-doc\x20h3,\x20.prose.prose-doc\x20h1,\x20.tab-alternate\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.prose\x20:where(code):not(:where([class~=not-prose]\x20*)),\x0a\x20\x20\x20\x20\x20\x20\x20\x20.prose\x20:where(a):not(:where([class~=not-prose]\x20*)),\x20.prose.prose-doc\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#4876d9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.theverge.com': _0x4c9bf1(0x408),
                'neverinstall.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.eSfmjG,\x20.FSTEV,\x20.eRZbqB,\x20.card-header\x20>\x20div,\x20div[class^=\x22UserAppStats__StatTitleSection\x22]\x20>\x20div,\x20div[class^=\x22UserAppStats__Stat-\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22AppTile__ComingSoonText-\x22],\x20div[class^=\x22Profile__PhoneText\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22NewUserAccount__AccountMenu-\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[class^=\x22Header__LogoImage-\x22],\x20a[class^=\x22footerLinks_logo\x22]\x20img{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'help.disneyplus.com': _0x4c9bf1(0x3b7),
                'minecraft.net': _0x4c9bf1(0x45e),
                'is.fi': _0x4c9bf1(0x636),
                'variety.com': _0x4c9bf1(0x678),
                'investor.costco.com': _0x4c9bf1(0x2c9),
                'stevejobsarchive.com': _0x4c9bf1(0x14f),
                'math.nakaken88.com': _0x4c9bf1(0x26b),
                'm.todaysppc.com': _0x4c9bf1(0x54e),
                'www.itworld.co.kr': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-overlay-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-b,\x20.ui-overlay-b\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-panel-position-right.ui-panel-display-reveal,\x20.ui-panel-position-right.ui-panel-open,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-panel-position-left.ui-panel-display-reveal,\x20.ui-panel-position-left.ui-panel-open\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.hotge.co.kr': _0x4c9bf1(0x44e),
                'www.dailywire.com': _0x4c9bf1(0x438),
                'www.thread.com': _0x4c9bf1(0x585),
                'www.trendevice.com': _0x4c9bf1(0x193),
                'www.skyjos.cn': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jqm-navmenu-link,\x20.jqm-navmenu-panel\x20.ui-btn:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jqm-navmenu-panel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.samsungcard.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.t_menu_onw\x20.pre_page,\x20#gnb_mobile\x20.t_menu_onw\x20.t_search\x20.btn_search,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.all_menu,\x20body.oneapp\x20#gnb_mobile\x20.menu_nav.menu_nav_onw\x20.menu_close,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20#gnb_mobile\x20.menu_nav.menu_nav_onw.menu_new_ver\x20.menu_search,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#gnb_mobile\x20.t_menu_onw\x20.search_chatbot\x20.search_sec_in\x20.btn_mirror,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.layer_cardComplete_wrap\x20.layer_cardComplete.v220208\x20.layer_close{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20.gnb_banner_wrap\x20.type_link.chatbot_wrap,\x20#footer.footer_onw\x20.awards:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.hub.zum.com': _0x4c9bf1(0x581),
                'www.3gpp.org': _0x4c9bf1(0x1c8),
                'www.quadlockcase.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.buy__dropdown>ul.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x205px\x20solid\x20#2f2a2a\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20ul.active\x20.buy__variant{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.zum.com': _0x4c9bf1(0x3a1),
                'm.cafe.naver.com': _0x4c9bf1(0x234),
                'm.blog.naver.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.floating_menu,\x20.lst_t17.tablet_aside,\x20.Ndrawer_profile,\x20.Ndrawer_menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Ndrawer_scroll_wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Ndrawer_menu\x20.Nmenu_item,\x20.Ndrawer_profile_menu\x20.Nmenu_item_link\x20.Nmenu_item_text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lst_t17\x20.lst_w\x20.paginate\x20.btn_prev\x20i:before,\x20.lst_t17\x20.lst_w\x20.paginate\x20.btn_next\x20i:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'm.auction.co.kr': _0x4c9bf1(0x278),
                '4pda.to': _0x4c9bf1(0x20f),
                'ilbe.com': _0x4c9bf1(0x4d3),
                'twisto.cz': _0x4c9bf1(0x5a4),
                'www1.nyc.gov': _0x4c9bf1(0x1d3),
                'seapunks.de': _0x4c9bf1(0x305),
                'www.toyota.com': _0x4c9bf1(0x1a6),
                'm.albamon.com': _0x4c9bf1(0x1b0),
                'apnews.com': _0x4c9bf1(0x40d),
                'support.apple.com': _0x4c9bf1(0x351),
                'portalmns.mu': _0x4c9bf1(0x35b),
                'answers.opencv.org': _0x4c9bf1(0x67d),
                'docs.opencv.org': _0x4c9bf1(0x17a),
                'm.youtube.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.engagement-panel-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.kvakil.me': _0x4c9bf1(0x5d0),
                'www.python.org': _0x4c9bf1(0x199),
                'www.oxfordlearnersdictionaries.com': _0x4c9bf1(0x218),
                'weather.com': _0x4c9bf1(0x357),
                'education.github.com': _0x4c9bf1(0x38c),
                'wizzair.com': _0x4c9bf1(0x172),
                'finam.ru': _0x4c9bf1(0x4aa),
                'pytorch.org': _0x4c9bf1(0x1f9),
                'investor.apple.com': _0x4c9bf1(0x41f),
                'thuthuatjb.com': _0x4c9bf1(0x57a),
                'www.thedailybeast.com': _0x4c9bf1(0x312),
                'swapcash.mu': _0x4c9bf1(0x1d1),
                'calendar.google.com': _0x4c9bf1(0x209),
                'tenforums.com': _0x4c9bf1(0x485),
                'bimmerforums.com': _0x4c9bf1(0x21a),
                'udemy.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22Udemy\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'xnxx.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content-thumbs,\x20#header\x20.topbar,\x20#header\x20#site-nav,\x20#video-content-metadata,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.video-page\x20#video-content-metadata\x20.tabs\x20.tab,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.x-thread\x20.thread-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.free-plate,\x20.gold-plate,\x20#header\x20#site-nav\x20ul,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.x-thread\x20.thread-node,.x-thread\x20.thread-node-btn,\x20.x-thread\x20.thread-node-btn\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.icon1\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20li\x20a.gold-plate\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'rapidgator.net': _0x4c9bf1(0x483),
                'map.naver.com': _0x4c9bf1(0x1e7),
                'm.map.naver.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.oa_rd,\x20.search_error_wrap\x20.bx_atmp\x20.msg_atcmp\x20.spr_ico_msg2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'naver.com': _0x4c9bf1(0x597),
                'www.dynamed.com': _0x4c9bf1(0x69c),
                'clipdiary.com': _0x4c9bf1(0x334),
                'nitroflare.com': _0x4c9bf1(0x227),
                'm.i-m-all.com': _0x4c9bf1(0x56b),
                'apexapr.mu': _0x4c9bf1(0x5ee),
                'kakaku.com': _0x4c9bf1(0x44b),
                'm.ynet.co.il': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ver1.ver2\x20.ArticleHeaderApp\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22ynet-logo\x22],\x20.main-logo-icon-image{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[data-text=\x22true\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bm-burger-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bm-burger-bars\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.ynet.co.il': _0x4c9bf1(0x220),
                'www.hdblog.it': _0x4c9bf1(0x1bc),
                'www.hdmotori.it': _0x4c9bf1(0x196),
                'www.cotopaxi.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.coto_slide-button.prev:after,\x20.coto_slide-button.next:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ctpx-testimonials\x20.slick-slider\x20.slick-arrow.slick-prev:before,\x20.ctpx-testimonials\x20.slick-slider\x20.slick-arrow.slick-next:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sub-nav-arrow,\x20.coto_short-stack\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.stars\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.main-nav,\x20.ui-autocomplete,\x20.nav-dropdown\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'routinehub.co': _0x4c9bf1(0x66d),
                'www.legifrance.gouv.fr': _0x4c9bf1(0x337),
                'pubmed.ncbi.nlm.nih.gov': _0x4c9bf1(0x652),
                'www.ncbi.nlm.nih.gov': _0x4c9bf1(0x5bd),
                'covid19.mohp.gov.np': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ant-typography\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'yandex.com': _0x4c9bf1(0x21f),
                'translate.yandex.com': _0x4c9bf1(0x2b5),
                'iphone-mania.jp': _0x4c9bf1(0x679),
                'www.engadget.com': _0x4c9bf1(0x212),
                'unsplash.com': _0x4c9bf1(0x285),
                'www.nfe.fazenda.gov.br': _0x4c9bf1(0x6c2),
                'vnexpress.net': _0x4c9bf1(0x19f),
                'lamar.edu': _0x4c9bf1(0x3cf),
                'www.24h.com.vn': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.gryTbL,\x20.gryTbR{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.mg-leftanhright,\x20.bx4Tbg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.bxDoMrNwsTwo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#566a32\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'docs.google.com': _0x4c9bf1(0x671),
                'iosninja.io': _0x4c9bf1(0x379),
                'ekstrabladet.dk': _0x4c9bf1(0x595),
                'tinhte.vn': _0x4c9bf1(0x491),
                'm.gsmarena.com': _0x4c9bf1(0x2a2),
                'books.google.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22button\x22]\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[href*=\x22/intl/en/about/products?\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'passwords.google.com': _0x4c9bf1(0x63c),
                'apps.apple.com': _0x4c9bf1(0x48b),
                'apple.com': _0x4c9bf1(0x372),
                'producthunt.com': _0x4c9bf1(0x4d8),
                'github.com': _0x4c9bf1(0x4d5),
                'box.com': _0x4c9bf1(0x667),
                'translate.google.com': '\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.RvYhPd::before,\x20.P6w8m.BDJ8fb:not(.Jj6Lae),\x20.QcsUad.BDJ8fb:not(.Jj6Lae)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.VIiyi,\x20div[data-language-code]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.X4DQ0::after,\x20.AzKM4,\x20.DLAnyc,\x20.NBY4Kb{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.ita-kd-icon-button\x20.ita-icon-1\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[soy-server-key]\x20ul[role=\x22listbox\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz[jsshadow]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-auto-open-search]\x20div[jsaction*=\x22keydown:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-auto-open-search]\x20input{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-language-code]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jfk-button-standard\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#clp-btn\x20.jfk-button-img,\x20a[title=\x22Google\x20apps\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ita-kd-img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.jfk-button-standard.jfk-button-checked,\x20.jfk-button-standard.jfk-button-clear-outline.jfk-button-checked,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KjuTac\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'cjasn.asnjournals.org': _0x4c9bf1(0x1da),
                'www.hollywoodreporter.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20p.larva,\x20p.amp-wp-excerpt\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.a-overlay--r-t0@mobile-max:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.openstreetmap.org': _0x4c9bf1(0x2a3),
                'm-grafolio.naver.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.group_lnb\x20li:last-child\x20a:after,\x20.tabScroll:before,\x20.tabScroll:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tit_category,\x20.tit_artwork\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'opensource.apple.com': _0x4c9bf1(0x535),
                'mediaspace.mu': _0x4c9bf1(0x4cf),
                'kiiroo.com': _0x4c9bf1(0x552),
                'www.samsungeshop.com.cn': _0x4c9bf1(0x519),
                'www4.septa.org': _0x4c9bf1(0x1bf),
                'nj.us': _0x4c9bf1(0x1e2),
                'discuss.eroscripts.com': _0x4c9bf1(0x1fd),
                'cegepgranby.omnivox.ca': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'bugs.chromium.org': _0x4c9bf1(0x580),
                'mra.mu': _0x4c9bf1(0x526),
                'analytics.google.com': _0x4c9bf1(0x3bb),
                'www.whiteelephantrestaurant.com': _0x4c9bf1(0x3a8),
                'www.airbnb.com': _0x4c9bf1(0x6db),
                'news.google.com': _0x4c9bf1(0x14a),
                'zingnews.vn': _0x4c9bf1(0x1ce),
                'shortcutsgallery.com': _0x4c9bf1(0x499),
                'idmsa.apple.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cnsmr-app-image[src^=\x22https://appstoreconnect\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.icloud.com': _0x4c9bf1(0x650),
                'cnn.com': _0x4c9bf1(0x4e7),
                'appstoreconnect.apple.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo\x20.cnsmr-app-image,\x20#appstore\x20.icon___3r8jH,\x20.itc-logo-alt{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.login-type-asc.login-page\x20#pageWrapper,\x20body.login-type-asc.login-page\x20#footer::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appstore\x20.sticky-header___1_Y3q:before,\x20#appstore\x20.section-container___GYtsI\x20.sticky-header___O648q:before,\x20.isdumPw,\x20.footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#sub-nav\x20._2b7H8wl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#testflight\x20.sticky-header___1_Y3q:before,\x20#testflight\x20.section-container___GYtsI\x20.sticky-header___O648q:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.messageList\x20li.selected\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#salestrends\x20.nav-link:hover{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#46a9ff\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'instagram.com': _0x4c9bf1(0x2d3),
                'messenger.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sp_OVYTba5GJUO_2x,\x20i[data-visualcompletion=\x22css-img\x22],\x20div[aria-label=\x22Settings,\x20help\x20and\x20more\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-visualcompletion]\x20svg[height=\x2224\x22],\x20a[aria-label=\x22New\x20Message\x22]\x20svg,\x20a[aria-label=\x22New\x20message\x22]\x20svg,\x20div[aria-label=\x22Create\x20New\x20Room\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menuitem\x22]\x20svg[height=\x2224\x22],\x20a[role=\x22menuitem\x22]\x20svg[height=\x2224\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[role=\x22presentation\x22]\x20svg[height=\x2224\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.qbubdy2e\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mbcradio.tv': _0x4c9bf1(0x697),
                'my.jdownloader.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#loginContainer\x20#main,\x20#gwtContent,\x20.contextMenu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.contextMenu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.rowSelected\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'psyche.co': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[type=\x22idea\x22]::before,\x20div[type=\x22guide\x22]::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
                'getpocket.com': _0x4c9bf1(0x21e),
                'console.firebase.google.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fire-appbar\x20.app-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fire-stacked-card::before\x20,\x20fire-stacked-card::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'travis-ci.com': _0x4c9bf1(0x37f),
                'drive.google.com': _0x4c9bf1(0x59e),
                'nytimes.com': _0x4c9bf1(0x57f),
                'cnbc.com': _0x4c9bf1(0x564),
                'www.iclarified.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#menu_logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'heroku.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#overview-page\x20.app-overview-metrics\x20timeseries-chart::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'chariz.com': _0x4c9bf1(0x29a),
                'disqus.com': _0x4c9bf1(0x455),
                'www.iphonedev.wiki': _0x4c9bf1(0x530),
                'www.iphonedevwiki.net': _0x4c9bf1(0x530),
                'theiphonewiki.com': _0x4c9bf1(0x530),
                'iphoneincanada.ca': _0x4c9bf1(0x3a0),
                'trello.com': _0x4c9bf1(0x626),
                'repo.packix.com': _0x4c9bf1(0x16f),
                'developer.packix.com': _0x4c9bf1(0x5ff),
                'codeproject.com': _0x4c9bf1(0x445),
                'webkit.org': _0x4c9bf1(0x451),
                'medium.com': _0x4c9bf1(0x2b9),
                'defimedia.info': _0x4c9bf1(0x3c3),
                'behance.net': _0x4c9bf1(0x436),
                'linkedin.com': _0x4c9bf1(0x6cb),
                'v2ex.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.item_title,\x20.item_hot_topic_title,\x20.normal.button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#DigitalOcean,\x20#LogoMobile,\x20#Logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'play.google.com': _0x4c9bf1(0x338),
                'pinterest.com': '\x20.VaseCarousel__buttonRight\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
                'finance.yahoo.com': _0x4c9bf1(0x668),
                'yahoo.com': _0x4c9bf1(0x1e3),
                'm.yahoo.co.jp': _0x4c9bf1(0x3e8),
                'uncyclopedia.kr': _0x4c9bf1(0x249),
                'lifehacker.com': _0x4c9bf1(0x4cd),
                'imore.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.not-front\x20div.header-top-inner2{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#ffd600\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
                'formula1.com': _0x4c9bf1(0x23a),
                'booking.com': _0x4c9bf1(0x2ce),
                'www.reddit.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appleid-signin-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Sso__appleIdContainer:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20::placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.CommentTree__tree.m-listing-below:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'appleid.apple.com': _0x4c9bf1(0x529),
                'forbes.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.et-promoblock\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mail.google.com': _0x4c9bf1(0x1ad),
                'paypal.com': _0x4c9bf1(0x65a),
                'internetaccount.myt.mu': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#loignPanel\x20{background:\x20theme_sub_color\x20!important;}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20table.loginarea\x20input[type=\x22submit\x22],\x20table.loginarea\x20input[type=\x22submit\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'bountify.co': _0x4c9bf1(0x401),
                'androidauthority.com': _0x4c9bf1(0x5ca),
                'dtf.ru': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comments__item__children\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left-color:\x20rgb(70,\x2063,\x2063)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment__space--highlighted::before,\x20.comment__space--new::before,\x20.comment__space--pinned::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-more--root--11,\x20.ui-button--11{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#282626\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment__children>.comment:not(.comment--level-last):last-child,\x20.comment__space--pinned::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar__footer[data-v-48f6e1e3]:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                '444.hu': _0x4c9bf1(0x15c),
                'www.ddlvalley.me': _0x4c9bf1(0x40b),
                'bing.com': _0x4c9bf1(0x31d),
                'macrumors.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#canvas-navigation,\x20#canvas-sidebar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'iosgods.com': _0x4c9bf1(0x35c),
                'imdb.com': _0x4c9bf1(0x4e5),
                'www.bbc.co.uk': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.isite-content\x20td.has-label:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'ebay.com': _0x4c9bf1(0x484),
                'base64decode.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20div.wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.header\x20div.sisters\x20a.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ad_left\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20main\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20main[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'urldecoder.org': _0x4c9bf1(0x1fe),
                'base64encode.org': _0x4c9bf1(0x1fe),
                'wikipedia.org': _0x4c9bf1(0x208),
                'context.reverso.net': _0x4c9bf1(0x1ff),
                'rskey.org': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#contentarea,\x20#contentarea2,\x20ul.menu\x20li\x20a:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'fmkorea.com': _0x4c9bf1(0x53f),
                'redmondpie.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li\x20a.top_link\x20span,\x20#winnav\x20li\x20a.top_link,\x20#winnav\x20li.top\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(128,\x20153,\x20165)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul.sub\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul.sub\x20li\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(128,\x20153,\x20165)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#body2,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top:\x204px\x20solid\x20theme_color;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li.top\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li\x20ul.sub\x20li\x20a.fly\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#winnav\x20li:hover\x20ul\x20li:hover\x20ul\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.leftalignLogo,\x20.footer\x20h4\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(32%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#SubscribeBoxOption\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(56%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'www.lefigaro.fr': _0x4c9bf1(0x301),
                'blog.google': _0x4c9bf1(0x3f4),
                'colorhexa.com': _0x4c9bf1(0x1c4),
                'geometricsoftware.se': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.styles_childContainer__3G9RO\x20>\x20div{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'developer.apple.com': _0x4c9bf1(0x46f),
                'iphonetweak.fr': _0x4c9bf1(0x51c),
                'iphonehacks.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.textwidget\x20li\x20>\x20a{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-blue,\x20#the-footer,\x20#sidebar\x20.widget\x20h4,\x20.footer-widget\x20.widget\x20h4,\x20#sidebar\x20h3,\x20.footer-widget\x20h3,\x20#main-wrapper\x20table.gsc-search-box{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#031928\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'bwt.cbp.gov': _0x4c9bf1(0x179),
                'mozilla.org': _0x4c9bf1(0x38e),
                'dailymail.co.uk': _0x4c9bf1(0x497),
                'gsmarena.com': _0x4c9bf1(0x500),
                'bt.dk': _0x4c9bf1(0x187),
                'solohdnet46.net': _0x4c9bf1(0x4f4),
                'www.definitions.net': _0x4c9bf1(0x33f),
                'lux.camera': _0x4c9bf1(0x226),
                'sukre.myqnapcloud.com:8180': _0x4c9bf1(0x4f0),
                'telegra.ph': _0x4c9bf1(0x34e),
                'telegram.com': _0x4c9bf1(0x3cc),
                'appgallery.huawei.com': _0x4c9bf1(0x503),
                'logentries.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20[ng-react-component]\x20.btn--tertiary\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'javrave.club': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20#cactus-body-container>.cactus-sidebar-control.sb-ct-medium.sb-ct-small>.cactus-container:not(.ct-default):before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20.cactus-sidebar-control.sb-ct-small\x20.cactus-container:not(.ct-default)\x20.main-content-col:before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'javraveclub.com': _0x4c9bf1(0x2f8),
                'developer.wordpress.org': _0x4c9bf1(0x34f),
                'amazon.com': _0x4c9bf1(0x315),
                'baidu.com': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-item[data-a-63b685b3],\x20.c-navs-scroll-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-container,\x20.c-row,\x20#head_wrapper,\x20.wrapper_new\x20#head,\x20#head,\x20.head_wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20.se-page-hd\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-item[data-a-63b685b3]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-text-box-gray,\x20.darkmode\x20.c-text-box-gray,\x20.defaultmode\x20.c-text-box-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20wheat\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fy-dictwisenew-icon__3tlXQ,.call:after,\x20.voice:after,\x20.callicon-wrap\x20.baiduapp-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-tags-container\x20.c-tags-scroll-right-mask[data-a-63b685b3]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'mail.ru': '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pl_p7:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
                'cydia.saurik.com': _0x4c9bf1(0x215),
                'default': _0x4c9bf1(0x571)
            }, _0x2bc2fa = _0x218e30[_0x4c9bf1(0x376)](getMainDomain, _0xa13be), _0x1f70c7 = [
                _0x218e30[_0x4c9bf1(0x3d0)],
                _0x4c9bf1(0x672),
                _0x218e30[_0x4c9bf1(0x62d)]
            ];
        for (domain of _0x1f70c7) {
            if (_0x2bc2fa[_0x4c9bf1(0x6b6)](domain)) {
                let _0x4c91ae = _0xa13be[_0x4c9bf1(0x654)](0x0, _0xa13be[_0x4c9bf1(0x2f5)](_0x2bc2fa));
                _0x2bc2fa = domain + _0x4c9bf1(0x3be), _0xa13be = _0x218e30[_0x4c9bf1(0x507)](_0x4c91ae, _0x2bc2fa);
            }
        }
        console['log'](_0x4c9bf1(0x3b3) + _0x2bc2fa + _0x4c9bf1(0x39e) + _0xa13be);
        let _0x829d5d = _0xad2bd5[_0x2bc2fa] || '';
        if (!_0x829d5d[_0x4c9bf1(0x362)])
            _0x829d5d = _0xad2bd5[_0x4c9bf1(0x64b) + _0x2bc2fa] || '';
        let _0x50341f = _0xad2bd5[_0xa13be] || '';
        return _0x4c9bf1(0x38b) + _0xad2bd5[_0x218e30[_0x4c9bf1(0x632)]] + _0x4c9bf1(0x1bd) + _0x2bc2fa + _0x4c9bf1(0x43d) + _0x829d5d + '\x20\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20' + _0x2bc2fa + _0x4c9bf1(0x40f) + _0xa13be + _0x4c9bf1(0x1ea) + _0x50341f + _0x4c9bf1(0x2fb) + _0xa13be + _0x4c9bf1(0x296);
    };
var NITEFALL_CUSTOM_CSS_ID = _0x52102f(0x615), NITEFALL_START_WORKAROUND_CSS_ID = _0x52102f(0x3d9), currentTheme = _0x52102f(0x51d), hasProcessedPage = ![], mutationObserver, ignoredElements = [
        'VIDEO',
        _0x52102f(0x258),
        _0x52102f(0x375),
        _0x52102f(0x2df),
        _0x52102f(0x374),
        'H',
        _0x52102f(0x272),
        _0x52102f(0x294),
        'BR',
        'MATH'
    ];
let ignoredBackgroundSelectors = getIgnoredSelectors(document[_0x52102f(0x269)][_0x52102f(0x378)]);
function _0x12c6() {
    var _0x134460 = [
        'mTVFE',
        'td\x20a',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html,\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20cite\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20bom{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x2014px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x2014px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-track\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#303030\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-track-piece\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#3e4346\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x2050px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#6e6e6e\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x202px\x20solid\x20#3e4346\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x2025px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-thumb:hover{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#818080\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-button:decrement,\x0a\x20\x20\x20\x20\x20\x20\x20\x20::-webkit-scrollbar-button:increment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x200px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input::-webkit-credentials-auto-fill-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20input::-webkit-credentials-auto-fill-button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20*[nitefall_imageType=\x22svg\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20\x20Note\x20that\x20svg\x20imageType\x20will\x20only\x20be\x20set\x20on\x20dark\x20svgs\x20with\x20single\x20color\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20force\x20svg\x20to\x20be\x20light\x20gray\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20https://stackoverflow.com/a/53336754\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20use\x20this\x20codepen\x20to\x20convert\x20svg\x20to\x20desired\x20color\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20https://codepen.io/sosuke/pen/Pjoqqp\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(64%)\x20sepia(0%)\x20saturate(12%)\x20hue-rotate(140deg)\x20brightness(86%)\x20contrast(84%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#gMenu_outer',
        'palevioletred',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.img_logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'lZSlB',
        'fAafv',
        'Oofjv',
        '.model-image',
        'XaGGt',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mobile-header-components\x20.nav-icon:before,\x20.mobile-header-components\x20.nav-icon:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mobile-header-components\x20.nav-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.Vue-Toastification__container',
        '.file-list-icon\x20svg.item-icon',
        'invertPdf',
        'chiEQ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#storyline-menu-title\x20>\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20mr-description\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header_fixed\x20.menu_category\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'a[class^=\x22Component-ios-\x22]',
        '.MathJax_Preview',
        'wBtdv',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button-modulebutton3Gm3c.button-modulevariantLight1f21J\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.age_and_budget_ranges-modulebuttonDescription18jdo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.appearance_selector-modulethumbnail2lNyP.appearance_selector-moduleactiveL8SRl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'nNfdJ',
        'ruhVH',
        'Veqoi',
        'GthGC',
        'oIiEU',
        '.dcg-mq-cursor',
        'YxRAt',
        'blue',
        'oHRCV',
        'YXkxB',
        '.cm-line',
        'Vdave',
        'oYJiO',
        'wrDZO',
        'DbwhG',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-ekstrabladet\x20.dre-item--skin-yellow\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#b7b707\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'MVBfh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb_header_area__1B3hK,\x20._3FXlRFu_o6,\x0a\x20\x20\x20\x20\x20\x20\x20\x20._header_header_REoTl,\x20.co_header_fix,\x20.header_header__3Owj1\x20,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_header\x20.g_header_area{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20._1-E6pu5hXf\x20._2484Ldw4O8\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c1a90d\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchInput_search_wrap__21YH1\x20.searchInput_input_area__3LdQZ:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_search\x20.g_input_area:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g_lnb:before,\x20.g_btn_service:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb_header_area__1B3hK\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.nav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comp_promotion\x20.cp_channel_event\x20.cp_channel::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comp_promotion\x20.cp_event_area\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap.id_search\x20.comp_container.type_square_card\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.shm_ico_npay,\x20.shm_ico_notify,\x20.shm_ico_qrcheckin,\x20.sch_ico_aside,\x20.ah_close,\x20.ah_link_theme,\x20#MM_SEARCH_BACK,\x20.HeaderGnbLeft\x20.icon-logo-naver-cafe,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn_back\x20.icon_back,\x20.footer_list\x20.footer_logo,\x20.header\x20.lang\x20.lang_select::after,\x20.header\x20.lang\x20.lang_select::before,\x20.icon_pw,\x20.icon_id\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HeaderTabList\x20.tab_link[aria-selected=true]:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HeaderTabList\x20.tab_menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.close-btn-container,\x20.report_income_by_category_3,\x20.amount-expense\x20\x20i,\x20span.item-navigation,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn-jump-today,\x20.icon-search,\x20\x20.search-border\x20i\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search-border{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20rgba(250,\x20250,\x20250,\x200.2)\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'investor.apple.com',
        'bisque',
        'mediumorchid',
        '.com.vn',
        'JPaAM',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KL4NAf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.aabwZd\x20.WYuW0e,\x20.aabwZd\x20.N7iPof,\x20.a-t-cb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-bottom-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.s55KNe:not(.KBj6Qd)\x20.GZwC2b\x20.jGNTYb,\x20.aabwZd:not(.KBj6Qd)\x20.GZwC2b,\x20.a-t-J-ha\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.L202Xe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.RwLyCe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz\x20span[aria-label=\x22Owned\x20by\x20me\x22],\x20c-wiz\x20span[aria-label^=\x22Last\x20modified\x22],\x20c-wiz\x20span[aria-label^=\x22Size:\x22]\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menu\x22]::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[title=\x22Options\x22]\x20span[nitefall_imagetype=\x22png\x22],\x20div[aria-label=\x22Remove\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[aria-label=\x22Shared\x22]\x20svg{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Connect\x20more\x20apps\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'lightsalmon',
        'gBhsn',
        'rrkbU',
        'npcQP',
        'a.fl\x20span',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.footer__inner{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#414141\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'blanchedalmond',
        'stringify',
        '\x0a\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20#app-container.vasquette:not(.app-imagery-mode):not(.app-globe-mode)\x20.widget-scene-canvas,\x20.gm-style\x20img[role=\x22presentation\x22]:not([src*=\x22v=\x22]),\x0a\x20\x20\x20\x20.wm-map__leaflet,\x20.leaflet-bottom,\x20.leaflet-popup-content-wrapper{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20#scene\x20img[decoding=\x22async\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.map-centered\x20.map-pane\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.wm-marker-label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(255,\x20143,\x20131)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20/*\x20bing\x20maps\x20*/\x0a\x20\x20\x20\x20div.ms-composite\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.leaflet-tile,\x20.leaflet-tile-loaded\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20.leaflet-popup-pane\x20.leaflet-popup,\x20.leaflet-popup-pane\x20.leaflet-popup-tip-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20',
        'JCvfT',
        'fill',
        'moccasin',
        'darkslategrey',
        '.appearance_selector-modulethumbnail2lNyP',
        'OJTwN',
        'oIfhC',
        'pSlFY',
        'GzYQk',
        'ofjZS',
        'ifSdK',
        'LxbQz',
        'uriYD',
        'insertRule',
        'pJmFa',
        'gif',
        '.tlf_cdefinition',
        'RFzwL',
        'ojpYy',
        'span[id^=\x22MathJax-Element\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ab_button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20form[action=\x22/search\x22]\x20:first-child\x20>\x20div[jsmodel]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[style^=\x27background-image:\x20url(\x22data:image/png;base64,iVBORw0KGgoAAAANSUh\x27]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.HOslld,\x20.mnr-c:not(:empty),\x20.MDLhlf{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x200\x200\x200\x201px\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbib_b::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml-searchbox-left-side-button-inner,\x20.ml-searchbox-right-side-button\x20.ml-icon-search{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[jsaction=\x22pane.homescreen.start\x22]\x20.noprint[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[id^=\x22section-directions-trip-travel-mode\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22gridcell\x22]\x20.suggest-icon-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mapsLiteJsControlsSettings__ml-settings-scroll\x20.ml-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mapsLiteJsControlsSettings__ml-settings-google-logo,\x20.ml-settings-drawer-region-section-google-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20..mapsLiteJsStart__feedback{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml-icon.ml-icon-chevron-up,\x20.ml-searchbox-button\x20.ml-icon-hamburger{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20google\x20becoming\x20theme_color\x20after\x20closing\x20image\x20in\x20search*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20body.srp\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*gradient\x20on\x20google\x20search*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.P1Ycoe\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20-webkit-linear-gradient(0deg,transparent,transparent)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.KSfJec\x20.aXBZVd\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.FjdPod\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.YIMUJb,\x20.YsGUOb,\x20.ZseVEf,\x20.XCKyNd,\x20.i8Msie{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.w8qArf\x20.fl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cG5GOd{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.fl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#8d87d6\x20!important\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yuRUbf\x20>\x20a[data-ved]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#8d87d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[data-ved]:visited,\x20a.fl:visited\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#cd82f2\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.iI6nue\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.NOiGgb\x20.sb-unsaved\x20svg,\x20.Rqu0ae\x20.cJC1zb-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20material\x20textfield\x20bottom\x20border\x20on\x20google\x20forms\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20.quantumWizTextinputPaperinputUnderline\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amFhOb,\x20.fes0he,\x20.fHujJ{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.XMHySb.MUxGbd.lyLwlc.lEBKkf,\x20div.MUxGbd.lNMe4.ZhSjR.aLF0Z\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20hr.BUybKe\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20opacity:\x200.2\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.ml-promotion.ml-promotion-on-screen.ml-pushup\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.highres\x20.searchbox-searchbutton::before,\x20img.searchbox-icon,.KY3DLe-settings-LgbsSe-icon,\x20.Liguzb-AHe6Kc\x20.Liguzb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbox-focus\x20.sbib_b::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.section-cardbox\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22listitem\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a\x20div[role=\x22heading\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20contrast(40%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-index]\x20a[href^=\x22https://www.youtube.com\x22]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sbhl\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20svg[aria-label=\x22Google\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pWEaFf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20c-wiz\x20a\x20>\x20svg[fill=\x22none\x22],\x20a[href^=\x22https://accounts.google.com/ServiceLogin?\x22]\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Navigation\x20drawer\x22],\x20header\x20div[role=\x22menu\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-iso]:before,\x20div[data-iso]:after,\x20div[data-iso]\x20div[role=\x22button\x22]:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-left-radius:\x200px\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-top-right-radius:\x200px\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#rp_13\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mnr-c:not(:empty){\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20div[style*=\x22background-color:\x20rgb(255,\x20255,\x20255);\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-hveid]\x20div[style*=\x22background-color:\x20rgb(255,\x20255,\x20255);\x22]\x20img[src^=\x22data:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20g-tray-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.zZnjCf,\x20.ccEnac,\x20.TkL5bb,.htyage\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.PxxJne,\x20.AHyjFe,\x20.NrF3hd,\x20.xVyTdb,\x20.wzUQBf,\x20.Q8lakc,\x20.pxFzCf,\x20.ZB3Ebc\x20.ZAGvjd,\x20.FEFWbc,.RCcRmb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ZB3Ebc\x20.ZAGvjd{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color\x20:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ml2Uge\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ncbi-alerts\x20.ncbi-alert__shutdown-outer,\x20.pmc-labs-ad-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'aeVyU',
        '.bookingDiv',
        'nodeName',
        'snpRp',
        'has',
        'darkgrey',
        'hZxKc',
        '.accordion-item__body__container',
        'uoMdO',
        '.shareIcon1280',
        'LuMPI',
        'lightcoral',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.kTWCIu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.AYowm\x20a,\x20.AYowm\x20button,\x20.hRBoHo,\x20.OZghr,\x20.gExOig\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'KjQLt',
        'concat',
        'active',
        'stroke',
        'fbjGP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#program-listing\x20tr:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#register-tab-view\x20.input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'a.focus-logo',
        'lightblue',
        'img[data-srcs]',
        '*[class^=\x22style__overlay__\x22]',
        'qBbLx',
        'flat',
        'trial-expired-banner',
        'CjAXL',
        'img[data-lazy-src]',
        'cyan',
        'div[data-testid=\x22messenger_hotlike_svg\x22]',
        'NyiTo',
        'crimson',
        '.swiper-slide',
        'AWUZT',
        'sfUcW',
        'JQKyO',
        'nitefall_processed',
        'darkMaps',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ivory',
        'KGKLK',
        'TlnIK',
        'PbBqT',
        'StBDZ',
        'eOOJL',
        'RvpFA',
        'pnjxr',
        'GjIkw',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-apexresponsivemenublock\x20#menu-responsive\x20>\x20li\x20.second-level\x20li\x20a:nth-child(1)\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-usertrigger\x20.field\x20div\x20img,\x20header\x20#block-userloggedtrigger\x20.field\x20div\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20#block-cart\x20.cart--cart-block\x20.cart-block--summary\x20.cart-block--summary__icon\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.com.au',
        'replaceAll',
        '.table-yes',
        'pGQZF',
        'XGuKS',
        'applewebdata://',
        'yandex.',
        'vsBSm',
        'PdCsH',
        '#FeaturedRoundupCountdown',
        'mlhoY',
        '.entry-thumb',
        'getAttribute',
        'UrMiN',
        '.mwe-math-fallback-image-inline',
        'removing\x20dark\x20css',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.site-navbar\x20.navbar-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.site-navbar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.panel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.05)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'head',
        'background-color',
        'oBHpr',
        '.com.ve',
        'TBTeY',
        'sheet',
        'bottom',
        'VDNpC',
        'CdRhU',
        'set',
        'QDGiy',
        '.btn-mint',
        'cpKKY',
        'WTGOZ',
        'disableTemporarily',
        'insertBefore',
        'message',
        '.pdfViewer,\x20embed[type=\x22application/pdf\x22]\x20{\x20filter:\x20invert(90%);}',
        'YoyzU',
        'aIDYt',
        'mediumslateblue',
        'nitefall-custom-css',
        '.pagination\x20.btn__num.on',
        'g-img',
        'forEach',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tron-light\x20.tron-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ydAph',
        'pfNoK',
        'zJGjv',
        '5|4|1|0|2|3',
        '._formSearch',
        '\x20!important',
        'div[class^=\x22listItem-\x22]\x20svg',
        'lCFwW',
        '.star-display',
        'div[data-sf-element=\x22Accordion_Title\x22]',
        'FIXsx',
        'ricOI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-banner.mod-warning\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20textarea.mod-list-name:disabled,\x20textarea.mod-card-back-title:disabled{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20-webkit-text-fill-color:\x20#6fa3fa\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.list-card\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'MlLLP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card__title-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card:hover\x20.product-card__wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-card:hover\x20.product-card__description:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'IzLjH',
        'qrbjE',
        'UaFgH',
        'sienna',
        'GrNQN',
        'LwfGC',
        'leBXJ',
        'keys',
        '.product-card__title',
        'bjenQ',
        'seashell',
        'DKlHI',
        '#program-listing-body\x20tr',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-ticker-10,\x20.vignette-breaking-news\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c8b400\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vignette-breaking-news\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c8b400\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#cd2129\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section-header\x20.r-fade:after,\x20.section-header\x20.x-fade:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'string',
        'teal',
        'rETld',
        'loading',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.id-MainNavigation-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.g81fxb.ROuVee,\x20.g81fxb.sxlEM{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'cssRules',
        'IgaAq',
        '.bus_layer',
        'hueRotate',
        'fillStyle',
        'dark',
        'AdpKd',
        'nfWDc',
        'LYGwo',
        'AulDZ',
        'google.',
        'RbWkY',
        'call',
        'pofqE',
        'www.',
        'mediumblue',
        'XBtMf',
        'iUxKT',
        'sEarP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.main-pane,\x20.cw-pane-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.banner-view\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#8a7500\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cw-spinner-view,\x20.notes-spinner-view\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notes-note-editor-view-controller\x20canvas\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.9)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fmip-background-grid\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cornsilk',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ncbi-alerts\x20.ncbi-alert__shutdown-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.article-page\x20.article-details>.heading\x20.journal-actions\x20.journal-actions-trigger,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.article-page\x20.article-details>.keywords-section\x20.keyword-actions\x20.keyword-actions-trigger{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.static-filters\x20.side-timeline-filter\x20.inner-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.static-filters\x20.side-timeline-filter\x20.toggle-button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search-form\x20.search-input\x20.clear-btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.com.br',
        'substring',
        '.container-roles',
        '.lazyload',
        'FlSwa',
        'deepskyblue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.scroll-y,\x20.container,\x20#background-content,\x20ion-title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_modal-dismiss_x-trigger:before,\x20.vx_modal-dismiss_x:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pp-header:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.highlightInstallmentPanel,\x20.highlightTransactionPanel\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_globalFooter\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fiDetailArea-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.isSelected_ltr:after,\x20.isSelected_rtl:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left:\x201.5em\x20solid\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.interstitial-entryLink\x20img{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vx_foreground-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid=\x22header_sub\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cornflowerblue',
        'contains',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.top-btn-main-wrapper,\x20.category-wrapper,\x20.title-wrapper,\x20.scroll-x-wrapper,\x20.footer-tab-wrapper,\x20.desc-wrapper\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-wrapper,\x20.list-header-wrapper,\x20.product-view-price-item-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'MyQDJ',
        'tomato',
        '11992BURDYS',
        'UjxoP',
        '.JPG',
        'ul#top-menu',
        'lightgray',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.m-header\x20.m-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sr-com-place\x20.com-place-one\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.images-viewer-content2__button',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.item-menu\x20svg:not(.menu-item-arrow),\x20.BulkAddToCollectionsFlyout-addToCollectionsButtonIcon,\x20.files-page\x20.icon-ellipsis,\x20.itemList-OneClickShareButton\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ItemListActions\x20.btn:not(.btn-primary):not(.create-dropdown-menu-toggle-button)\x20.btn-content{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row:not(.is-selected).hover-styles,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row:not(.is-selected):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Body.is-deja-blue\x20.table.has-hover-styles\x20.table-body\x20.table-row.is-selected,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-item:not([aria-disabled]):focus,\x20.menu-item:not([aria-disabled]):hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-wrapper,\x20#UH-0-UH-0-MobileHeader\x20>\x20div,\x20#UH-0-UH-0-TabletHeader\x20>\x20div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#closebtn\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ztTMu',
        '.slide__image',
        'AUQTR',
        'springgreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ethad-container,\x20.dropdown-content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22RoutineHub\x20logo\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ZHHQs',
        'EqqnH',
        'lightgreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#docs-editor\x20#waffle-grid-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.kix-paginateddocumentplugin\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#kix-current-user-cursor-caret\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(50%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#t-formula-bar-input\x20.cell-input,\x20.cell-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.docs-grille-gm3\x20#docs-chrome:not(.docs-hub-chrome),\x20.docs-grille-gm3\x20#docs-header:not(.docs-hub-appbar)\x20.docs-titlebar-buttons\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.docs-grille-gm3\x20.waffle-name-box-container\x20.waffle-name-box\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'amazon.',
        'peachpuff',
        'error',
        'kqRVe',
        'wngPw',
        '.JPEG',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amp-fn-content,\x20.amp-fn-content-wrapper\x20p\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.amp-wp-title-bar\x20.hamburger\x20span,\x20.a-icon-comments-black:before,\x20.lrv-u-cursor-pointer:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#contents\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post\x20h3,\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ulCommentWidget\x20iframe,\x20.menu-btn\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'BLYGK',
        '.RichContent-cover--mobile',
        'lOTWm',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.question-page\x20.post-update-info,\x20.box,\x20#ground,\x20#header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'SsPNw',
        'AFPOt',
        'textColor',
        'OoxPl',
        'limegreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tlf_cdefinition\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20black\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.8)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'enabled',
        'color',
        'OWbri',
        '14005107QTDBtq',
        '.hero-image.blankets',
        '.svg-sign',
        'gwQXw',
        '.vis-stacked-nav',
        'DgZgz',
        '.ezlazyloaded',
        'UVZvo',
        'KcdXl',
        'NiPPh',
        'trim',
        'yellow',
        'fsNkw',
        'AclAz',
        'MXbmB',
        'ixfLS',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section-3,\x20.view-replay-term-page\x20.attachment-after\x20.view-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'sWDrq',
        '#top_search',
        'rwjpw',
        '.dotnav',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.App_cookieConsent:before,\x20div[data-testid=\x22appbar\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'createTreeWalker',
        'RqLXS',
        'borderColor',
        'img.journal-logo',
        '.search-form\x20.submit-button',
        'rgba(',
        'getElementById',
        'xsevu',
        'VFOjI',
        'theme_sub_color',
        'KwOFT',
        '\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*when\x20pdf\x20is\x20loading\x20in\x20safari*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#annotationContainer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20',
        'palegoldenrod',
        '<svg',
        'name',
        'hdOAP',
        '.static-filters\x20.side-timeline-filter\x20.toggle-button',
        'mBvIh',
        'hYiER',
        'img.picture-image',
        'media',
        'error\x20extracting\x20svg\x20colors\x20',
        'brDia',
        'div[data-testid=\x22primary-nav\x22]',
        'MNNWX',
        'startsWith',
        'border-color',
        'aquamarine',
        'MwJRS',
        '[fill]',
        'darkslategray',
        'height',
        'sZLEb',
        'kvKUO',
        'visitedWebsites',
        '.article-page\x20.article-details>.heading\x20.journal-actions\x20.journal-actions-trigger',
        'zRvjy',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#divCentral\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ulzpQ',
        'setProperty',
        'PvCKB',
        '.sc_option\x20.sc_view',
        'kuaXC',
        '.Dv4WMb',
        'mZZwq',
        'width',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.toggle__label::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.show-more-less-html__markup::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#app-boot-bg-loader,\x20.loading-bg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pv-profile-sticky-header__container,\x20.artdeco-card{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.feed-follows-module-recommendation__description\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.banner__image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.page-header,\x20nav.fixed\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'mfRcx',
        'jIseM',
        'shade',
        'StWAP',
        'p[color=\x22labelPlaceholder\x22]',
        'meta[name=\x27supported-color-schemes\x27]',
        '.footer__social',
        'gzUAG',
        '.content-page__navigation__group__header',
        'RvkSh',
        '.table-center\x20.box',
        'midnightblue',
        'hCTyJ',
        'dImtW',
        'matches',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid*=\x22structured-search-input-field-split-dates-\x22]:hover::after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-testid=\x22structured-search-input-field-guests-button\x22]:hover::after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20label[for=\x22bigsearch-query-detached-query\x22]:hover::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'NQXRl',
        '.wXUyZd',
        'svg[set=\x22weather\x22]',
        'DymHD',
        'darksalmon',
        'Dtbgn',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22tablist\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'KXSKM',
        'chartreuse',
        '.static-filters\x20.side-timeline-filter\x20.inner-wrap',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ant-select-dropdown-menu-item\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ant-select-dropdown-menu-item-active:not(.ant-select-dropdown-menu-item-disabled)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#4b819a\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.AnimatedWordmark_image__EdH1l\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#__next\x20div[style^=\x22background-color:\x20rgb(2\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAcCAYAAAB2+A+pAAAMamlDQ1BJQ0MgUHJvZmlsZQAASImVVwdYU8kWnluSkJDQAhGQEnoTpFcpIbQIAlIFGyEJJJQYE4KKHREVXLuIYkVXRRRdCyCLitjLotj7YkFBWRd1URSVNyEBXfeV753vmzv/PXPmPyUzuTMAaPZyJZIcVAuAXHGeNC48mDkuJZVJagckYAS0gQ1AuTyZhBUbGwWgDPZ/l/e3AKLorzsquP45/l9Fhy+Q8QBAJkCczpfxciFuAgDfyJNI8wAgKvQW0/IkCjwPYl0pDBDiNQqcqcS7FThdiRsHbBLi2BBfBUCNyuVKMwHQeAD1zHxeJuTR+Ayxs5gvEgOgOQLiAJ6Qy4dYEfuI3NwpClwOsS20l0AM4wHe6d9xZv6NP32In8vNHMLKvAZELUQkk+RwZ/yfpfnfkpsjH/RhDRtVKI2IU+QPa3gne0qkAlMh7hKnR8coag1xr4ivrDsAKEUoj0hU2qNGPBkb1g8wIHbmc0MiITaCOEycEx2l0qdniMI4EMPVgk4X5XESINaHeLFAFhqvstkqnRKn8oXWZkjZLJX+PFc64Ffh65E8O5Gl4n8rFHBU/JhGgTAhGWIKxJb5oqRoiDUgdpJlx0eqbEYVCNnRgzZSeZwifkuI4wTi8GAlP5afIQ2LU9mX5MoG88W2CkWcaBU+mCdMiFDWBzvN4w7ED3PBrgrErMRBHoFsXNRgLnxBSKgyd6xDIE6MV/H0SvKC45RzcYokJ1Zlj5sLcsIVenOI3WX58aq5eFIeXJxKfjxDkheboIwTL8jijo5VxoOvAFGADUIAE8hhSwdTQBYQtXTVdcE35UgY4AIpyAQC4KjSDM5IHhgRw2c8KAB/QCQAsqF5wQOjApAP9V+GtMqnI8gYGM0fmJENnkOcCyJBDnyXD8wSD3lLAs+gRvQP71zYeDDeHNgU4/9eP6j9pmFBTZRKIx/0yNQctCSGEkOIEcQwoh1uiAfgfngUfAbB5op74z6DeXyzJzwntBKeEG4S2gh3J4sKpT9EOQa0Qf4wVS3Sv68Fbg05PfBg3B+yQ2acgRsCR9wd+mHhgdCzB9SyVXErqsL8gftvGXz3a6jsyM5klDyMHES2/XGmhr2GxxCLotbf10cZa/pQvdlDIz/6Z39XfT7sI3+0xBZjh7Bz2EnsAtaI1QEmdgKrxy5jxxR4aHU9G1hdg97iBuLJhjyif/jjqnwqKilzrnbudP6sHMsTTM9TbDz2FMkMqShTmMdkwa+DgMkR85xGMF2dXV0AUHxrlH9f7xgD3xCEcfGbrvAhAP4p/f39jd90UXD/Hu6A27/rm86mGgDacQDOL+TJpflKHa54EOC/hCbcaQbABFgAW5iPK/AEfiAIhILRIAYkgBQwCVZZCNe5FEwDs8B8UAxKwQqwFmwAW8B2sBvsAwdBHWgEJ8FZcAlcBTfBfbh62sEr0A3egz4EQUgIDaEjBogpYoU4IK6INxKAhCJRSBySgqQhmYgYkSOzkAVIKbIK2YBsQ6qQX5CjyEnkAtKK3EUeI53IW+QTiqFUVBc1Rq3Rkag3ykIj0QR0IpqJTkUL0CJ0GVqOVqJ70Vr0JHoJvYm2oa/QHgxg6hgDM8McMW+MjcVgqVgGJsXmYCVYGVaJ1WAN8He+jrVhXdhHnIjTcSbuCFdwBJ6I8/Cp+Bx8Kb4B343X4qfx6/hjvBv/SqARjAgOBF8ChzCOkEmYRigmlBF2Eo4QzsC91E54TyQSGUQbohfciynELOJM4lLiJuJ+YhOxlfiU2EMikQxIDiR/UgyJS8ojFZPWk/aSTpCukdpJvWrqaqZqrmphaqlqYrVCtTK1PWrH1a6pvVDrI2uRrci+5BgynzyDvJy8g9xAvkJuJ/dRtCk2FH9KAiWLMp9STqmhnKE8oLxTV1c3V/dRH6suUp+nXq5+QP28+mP1j1Qdqj2VTZ1AlVOXUXdRm6h3qe9oNJo1LYiWSsujLaNV0U7RHtF6NegaThocDb7GXI0KjVqNaxqvNcmaVposzUmaBZplmoc0r2h2aZG1rLXYWlytOVoVWke1bmv1aNO1XbRjtHO1l2rv0b6g3aFD0rHWCdXh6xTpbNc5pfOUjtEt6Gw6j76AvoN+ht6uS9S10eXoZumW6u7TbdHt1tPRc9dL0puuV6F3TK+NgTGsGRxGDmM54yDjFuPTMONhrGGCYUuG1Qy7NuyD/nD9IH2Bfon+fv2b+p8MmAahBtkGKw3qDB4a4ob2hmMNpxluNjxj2DVcd7jfcN7wkuEHh98zQo3sjeKMZhptN7ps1GNsYhxuLDFeb3zKuMuEYRJkkmWyxuS4Sacp3TTAVGS6xvSE6UumHpPFzGGWM08zu82MzCLM5GbbzFrM+sxtzBPNC833mz+0oFh4W2RYrLFotui2NLUcYznLstrynhXZyttKaLXO6pzVB2sb62TrRdZ11h02+jYcmwKbapsHtjTbQNuptpW2N+yIdt522Xab7K7ao/Ye9kL7CvsrDqiDp4PIYZND6wjCCJ8R4hGVI247Uh1ZjvmO1Y6PnRhOUU6FTnVOr0dajkwduXLkuZFfnT2cc5x3ON930XEZ7VLo0uDy1tXeleda4XrDjeYW5jbXrd7tjbuDu8B9s/sdD7rHGI9FHs0eXzy9PKWeNZ6dXpZeaV4bvW5763rHei/1Pu9D8An2mevT6PPR19M3z/eg759+jn7Zfnv8OkbZjBKM2jHqqb+5P9d/m39bADMgLWBrQFugWSA3sDLwSZBFED9oZ9ALlh0ri7WX9TrYOVgafCT4A9uXPZvdFIKFhIeUhLSE6oQmhm4IfRRmHpYZVh3WHe4RPjO8KYIQERmxMuI2x5jD41Rxukd7jZ49+nQkNTI+ckPkkyj7KGlUwxh0zOgxq8c8iLaKFkfXxYAYTszqmIexNrFTY38dSxwbO7Zi7PM4l7hZcefi6fGT4/fEv08ITliecD/RNlGe2JykmTQhqSrpQ3JI8qrktnEjx80edynFMEWUUp9KSk1K3ZnaMz50/Nrx7RM8JhRPuDXRZuL0iRcmGU7KmXRssuZk7uRDaYS05LQ9aZ+5MdxKbk86J31jejePzVvHe8UP4q/hdwr8BasELzL8M1ZldGT6Z67O7BQGCsuEXSK2aIPoTVZE1pasD9kx2buy+3OSc/bnquWm5R4V64izxaenmEyZPqVV4iAplrRN9Z26dmq3NFK6U4bIJsrq83Thof6y3Fa+UP44PyC/Ir93WtK0Q9O1p4unX55hP2PJjBcFYQU/z8Rn8mY2zzKbNX/W49ms2dvmIHPS5zTPtZhbNLd9Xvi83fMp87Pn/1boXLiq8K8FyQsaioyL5hU9XRi+sLpYo1hafHuR36Iti/HFosUtS9yWrF/ytYRfcrHUubSs9PNS3tKLP7n8VP5T/7KMZS3LPZdvXkFcIV5xa2Xgyt2rtFcVrHq6eszq2jXMNSVr/lo7ee2FMveyLeso6+Tr2sqjyuvXW65fsf7zBuGGmxXBFfs3Gm1csvHDJv6ma5uDNtdsMd5SuuXTVtHWO9vCt9VWWleWbSduz9/+fEfSjnM/e/9ctdNwZ+nOL7vEu9p2x+0+XeVVVbXHaM/yarRaXt25d8Leq/tC9tXXONZs28/YX3oAHJAfePlL2i+3DkYebD7kfajmsNXhjUfoR0pqkdoZtd11wrq2+pT61qOjjzY3+DUc+dXp112NZo0Vx/SOLT9OOV50vP9EwYmeJklT18nMk0+bJzffPzXu1I3TY0+3nIk8c/5s2NlT51jnTpz3P994wffC0YveF+sueV6qvexx+chvHr8dafFsqb3idaX+qs/VhtZRrcevBV47eT3k+tkbnBuXbkbfbL2VeOvO7Qm32+7w73Tczbn75l7+vb778x4QHpQ81HpY9sjoUeXvdr/vb/NsO/Y45PHlJ/FP7j/lPX31TPbsc3vRc9rzshemL6o6XDsaO8M6r74c/7L9leRVX1fxH9p/bHxt+/rwn0F/Xu4e193+Rvqm/+3Sdwbvdv3l/ldzT2zPo/e57/s+lPQa9O7+6P3x3KfkTy/6pn0mfS7/Yvel4Wvk1wf9uf39Eq6UO3AUwGBDMzIAeLsLnhNSAKDDextlvPIuOCCI8v46gMB/wsr74oB4AlADO8Uxnt0EwAHYrOdBbviuOMInBAHUzW2oqUSW4eaq5KLCmxCht7//nTEApAYAvkj7+/s29fd/2QGDvQtA01TlHVQhRHhn2BqiQHdXj7cFP4jyfvpdjj/2QBGBO/ix/xdr2JBCn5K+oQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAB6gAwAEAAAAAQAAABwAAAAAQVNDSUkAAABTY3JlZW5zaG90lZEjdgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+Mjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MzA8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpVc2VyQ29tbWVudD5TY3JlZW5zaG90PC9leGlmOlVzZXJDb21tZW50PgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPVlWugAAABxpRE9UAAAAAgAAAAAAAAAOAAAAKAAAAA4AAAAOAAAAXG8GN68AAAAoSURBVEgNYhQREfnPMACAcdRieoX6aFDTK6QZRoN6NKhpFgIjL3EBAAAA//9GJ+eOAAAAJklEQVRjFBER+c8wAIBx1GJ6hfpoUNMrpBlGg3o0qGkWAiMvcQEAfkgikcMCBaEAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x20*[nitefall_imageType=\x22png\x22],\x20img[src$=\x22.png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20hue-rotate(180deg)\x20invert(100%)\x20!important;\x0a\x20\x20\x20\x20}',
        'chrome',
        'yellowgreen',
        '.tl_main_logo',
        '.swiper-wrapper',
        'zSNFW',
        'avFJs',
        'wtUaM',
        'uVbuw',
        'jZsKr',
        'otPHd',
        'fuchsia',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ember4,\x20.legacy\x20.subhead::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.legacy\x20.ad-highlight\x20a,\x20.legacy\x20.highlight,\x20.kr21osz-str-1__wrapper:any-link,\x20#ember12\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#c7c700\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hj\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20--highlight-color:\x20#c7c700\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.legacy\x20.item\x20.highlight.highlight--black\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-right:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.id-HeaderWhiteWidow',
        'getElementsByTagName',
        'BlnPs',
        '.thumb',
        '#drawer-close',
        '.product-image-gallery\x20.mt-2',
        'eXVRs',
        'parentNode',
        'qMYJF',
        'script[src*=\x22eBay.app\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-master\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bg-white,\x20.form-select,\x20.form-input,\x20bg-gray-100:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.form-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'YUylH',
        '.kix-zoomdocumentplugin-outer',
        'JNufU',
        'match',
        '3425826ilIcBt',
        'ryKCN',
        'YdYVh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.package-header\x20.name{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'YeIrn',
        'IYgDS',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__title,\x20.rf-search-tools__title,\x20.banner__title\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20p,\x20li,\x20strong,\x20span,a,\x20h3,\x20.accordion-item__header\x20button,\x20ul,\x20font,\x20h1,button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__navigation__group.accordion-item--opened\x20.content-page__navigation__group__header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#817fdf\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-page__search\x20input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cookie-policy,\x20.sticky-newsletter-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.faq-page-header__title__main\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20nav.mobile-navigation,\x20.navigation-dropdown,\x20.language-switcher,\x20.content-page__container\x20.accordion-item__body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-test=\x22flight-search-locations\x22],\x20.flight-search__panel__header,\x20.flight-search__panel,\x20.rf-input--location,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar,\x20.box,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.accordion-item__body__container\x20.content__note,\x20.body--campaign-page\x20.campaign__white-box\x20.content__note,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.career__content--continuous\x20.content__note,\x20.career__content\x20.content__note,\x20.content-page__content\x20.content__note\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.language-switcher__item--active,\x20.language-switcher__item:active,\x20.language-switcher__item:focus,\x20.language-switcher__item:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#712153\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'YgvsE',
        'childNodes',
        'ESWau',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sticky-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hDkVhy,\x20.hdtNVh,\x20.jsxbNi\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'div[data-eventid]',
        'sin',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navbar-default[_ngcontent-c0],\x20.well[_ngcontent-c2],\x20.panel-default[_ngcontent-c2]\x20>\x20.panel-heading[_ngcontent-c2]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sm-dox,\x20.navpath\x20ul,\x20.tabs,\x20.tabs2,\x20.tabs3,\x20.tablist\x20li,\x20div.header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tablist\x20a:hover,\x20.memproto,\x20dl.reflist\x20dt,\x20.memtitle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'hjKuA',
        'lLEog',
        'AxfLz',
        'svg.bdl-CollapsibleSidebar-menuItemIcon',
        'text',
        'darkgoldenrod',
        '1129150ShjGxV',
        'uNdni',
        'nDrBs',
        'PGRdZ',
        'UFJED',
        'zjIkB',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking,\x20.theme-bt\x20.dre-item__header--skin-custom-live,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-live,\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-updates,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-just-now,\x20.theme-bt\x20.dre-item--skin-breaking\x20.dre-item__header--skin-just-now-text\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#c7a505\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cSpZU',
        'yImqy',
        'PXAjV',
        '.pt-btn',
        '.mw-ui-icon',
        '.all-over-thumb-link',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20mark\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#917a11\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'beige',
        'CKopo',
        'href',
        'lightpink',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrapper_attributo\x20.elenco_scelte\x20input:not(:checked)\x20+\x20label\x20.wrapper_valore,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.valori_wrapper\x20input:not(:checked)\x20+\x20.valore_attributo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'XQlJG',
        'fzaHY',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.newlist_normal\x20.title_newlist_normal\x20.comment-gray\x20i.fa.fa-comment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAABYklEQVQokd2SMUvDUBDH/4nP60FpDR0eqFnEzdXNbyC4+Qn8Lo4Ogs5OfgDd3DqIjopQLE4ORiJFQ0yipO+ZRK5NhwqFipsHB493d7/7v3vnpGl6FATBnjGmifmtIqKe7/unTr/fDzqdzjIRuVLuuu5clDzPP6IoCpUxZpWZf9F8bMzcNMasz9dutjl/BeAfABQRFXmeu8zs/AyWZTmz0BhTEFEsi3QQBMGGMWbL87wlz/OmEuM4Fq8AFPXVO4BXIop83792qqqSJVgBcBiG4U5RFE673Z4UW2Z+1FpfAXgAEAG4BPAM4EtEKgBDAE8AbhuNxnaWZUqkJ0lSMvO91nofQBdAKisMwE7NQJZBSABeiGhorVVJkmTM3NNanwC4APBZ54kv1PkCGwHkIN5VSt1Ya9darda51voMwF0dW6yVyq9NQCObzMDUsN3BYLCptT4G8FYXSkzeKy4AUTBWAQy/Ac4mjxRGs3sdAAAAAElFTkSuQmCC\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'bzXJM',
        '.sailthru-overlay-close',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.python-navigation\x20.super-navigation,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.donate-button:hover,\x20.header-banner\x20.button:hover,\x20.header-banner\x20a.button:hover,\x20.user-profile-controls\x20div.section\x20span:hover,\x20a.delete:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20form.deletion-form\x20button[type=\x22submit\x22]:hover,\x20.search-button:hover,\x20#dive-into-python\x20.flex-control-paging\x20a:hover,\x20.text\x20form\x20button:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit]:hover,\x20.sidebar-widget\x20form\x20button:hover,\x20.sidebar-widget\x20form\x20input[type=submit]:hover,\x20input[type=submit]:hover,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=reset]:hover,\x20button:hover,\x20.button:hover,\x20.donate-button:focus,\x20.header-banner\x20.button:focus,\x20.header-banner\x20a.button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.user-profile-controls\x20div.section\x20span:focus,\x20a.delete:focus,\x20form.deletion-form\x20button[type=\x22submit\x22]:focus,\x20.search-button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#dive-into-python\x20.flex-control-paging\x20a:focus,\x20.text\x20form\x20button:focus,\x20.text\x20form\x20input[type=submit]:focus,\x20.sidebar-widget\x20form\x20button:focus,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar-widget\x20form\x20input[type=submit]:focus,\x20input[type=submit]:focus,\x20input[type=reset]:focus,\x20button:focus,\x20.button:focus,\x20.donate-button:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-banner\x20.button:active,\x20.header-banner\x20a.button:active,\x20.user-profile-controls\x20div.section\x20span:active,\x20a.delete:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20form.deletion-form\x20button[type=\x22submit\x22]:active,\x20.search-button:active,\x20#dive-into-python\x20.flex-control-paging\x20a:active,\x20.text\x20form\x20button:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit]:active,\x20.sidebar-widget\x20form\x20button:active,\x20.sidebar-widget\x20form\x20input[type=submit]:active,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=submit]:active,\x20input[type=reset]:active,\x20button:active,\x20.button:active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.psf-widget\x20.button,\x20.python-needs-you-widget\x20.button,\x20.donate-button,\x20.header-banner\x20.button,\x20.header-banner\x20a.button,\x20.user-profile-controls\x20div.section\x20span,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.delete,\x20form.deletion-form\x20button[type=\x22submit\x22],\x20button[type=submit],\x20.search-button,\x20#dive-into-python\x20.flex-control-paging\x20a,\x20.text\x20form\x20button,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text\x20form\x20input[type=submit],\x20.sidebar-widget\x20form\x20button,\x20.sidebar-widget\x20form\x20input[type=submit],\x20input[type=submit],\x20input[type=reset],\x20button,\x20a.button,\x20.button,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.python-navigation\x20.subnav,\x20.jobs-navigation\x20.subnav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'black',
        '.forget_pass',
        'JedVm',
        'img[decoding=\x22async\x22]',
        'sCiof',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.top-header,\x20.inner-section-video:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.section_nav_v2\x20.next-nav,\x20.wrap-main-nav.sticky\x20.main-nav\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cazdS',
        '.tds-modal-backdrop',
        'iKnbP',
        'SHWvu',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bookingDiv\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20black\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vhQWL',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#tcom-header\x20.main-navigation-bar\x20nav\x20li:first-child\x20svg,\x20.tcom-footer-logo\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vis\x20.vis-stacked-nav\x20.line\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgba(39,47,54,0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'postMessage',
        'tqyJR',
        'darkgray',
        'fNLpq',
        'img[src^=\x22data:image/svg+xml\x22]',
        '.com.cn',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22toolbar\x22]\x20>\x20div[command]\x20div[nitefall_imageType=\x22png\x22],\x20td[role=\x22gridcell\x22]\x20div[nitefall_imageType=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[data-hovercard-id]\x20div[nitefall_imageType=\x22png\x22],\x20td\x20div[command]\x20div[nitefall_imageType=\x22png\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22More\x20options\x22]\x20div[nitefall_imageType=\x22png\x22],\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label^=\x22Discard\x20draft\x22]\x20div[nitefall_imageType=\x22png\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span\x20>\x20img[src=\x22images/cleardot.gif\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[role=\x22link\x22]::before,\x20div[aria-label=\x22Not\x20starred\x22]\x20span::before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[role=\x22menuitemcheckbox\x22]\x20div[nitefall_imageType=\x22png\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20span[aria-label=\x22Pop\x20out\x20reply\x22],\x20div[aria-label=\x22Type\x20of\x20response\x22]::after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20td\x20div[style*=\x22clip:\x20rect\x22]::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Download\x20all\x20attachments\x22]\x20div[nitefall_imageType=\x22png\x22],\x20div[aria-label=\x22Add\x20all\x20to\x20Drive\x22]\x20div[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Remove\x20attachment\x22],\x20div[aria-label=\x22Show\x20trimmed\x20content\x22]\x20img,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Type\x20of\x20response\x22]\x20img,\x20button[data-overlay-action=\x22spelldismiss\x22]\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Show\x20details\x22]\x20img\x20,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Reply\x22]\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label=\x22Formatting\x20options\x22]\x20div[nitefall_imagetype=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20transform:\x20translateZ(0);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#mutbt,\x20#tltbt,\x20#cv__cntbt\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#pr_\x20,\x20#preftopbar{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.Fb,\x20.ph\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22prmenu+179\x22],\x20div[data-control-type=\x22prusemod+182\x22],\x20div[data-control-type=\x22prusevacmod+188\x22],\x20div[data-control-type=\x22tlasprev+82\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22prmenu+179\x22]\x20>\x20div,\x20div[data-control-type=\x22tlasprev+82\x22]\x20>\x20div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22toggleaccountscallout+20\x22],\x20div[data-control-type=\x22cmclose+107\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.nl.fl,\x20#mutbb{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAABYCAIAAAC79grhAAAAOklEQVR4AWOAAQ8PXyYgxczPL8z0//9/EBsN/weKk8sHmwfkw9lQPslsgmZjssE0PnEYnxS/EOLDMACvzUZ13+DWTQAAAABJRU5ErkJggg==)\x20repeat-x\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div[data-control-type=\x22bti+2\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-image:\x20url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAAA8CAYAAACdIW+JAAAFHklEQVR42u2c72tbVRjHm+b3zzaNbdOk6dL8aGuwTcVEWyldsBRbWgRlkDnfrMYpEzH4CybSRa1WRYS1cz/KHJOCKKsb4htxoAiWDqG4d3s16X8x2N7E57k+J9x1jSS5uScv7nPhC82999ybfj+55znnueectnK53IbSaTsC+g10F1Q2sHZBG6DZqk7pBOJ50A2Dm19Nf4DyMkCcEjcNhUK7S0tLp/f29ubgHocNqtzKysrJxcXFNfDjlgrIJ3qCOC1ulMlkNuG6T4IeBQ2CBgyqQ6Ak6DHQU9PT0xcOhNFEEJUnYWpqao0AhEABkA/kNajwf/eDukFh9AWejg9VMPLNBHFMXBiIfwnXi4MeoS/iYVXkpR9mNJvNnlHFjKaAeEJAGB0dvUzVUBdD+F/hExINBAK75N0zWkE4Qd/gxYaHh6/CdWIMoWYF0un0RwTivFYQZ/FCQ0NDP8E1humxYwg1VlPQonwa/TOZTHe0gHhPVEmlUgmbpz0MoT5tb2+HyMN7jYKYFBByudwpKB+k1gEbXJ86Kq2nBkFsYuGRkZFvqUmGENysuuXRAuIzLBiJRG5QcO5kQxtXoyDyomA+n3+J+goeNlQuiA5Vf2Gd4oKXzZQPQukJJhKJLTg/QhBcLG2qF0RRFFhdXT1MPUM2UjKIcXHyxMREiZJXbjZRPogN6j1vUjaVq6QWgFByIcFg8E9K5mF/wclqnmoB8Zw4aX5+/gQl81xsnlwQNtAveEIqlboAx3spLrB5kkEoTdVYLHZN1VRl4ySDOCkOFovFWUxMgRwsfVQNREIcGB8f/5RSGE42TD6I87gzHo9/D/v6KC6wYZJBKENh8D3qzs7OCMUFO0tfPQCChgKKURhFSmE42Cj5IK5T7/kSvfJ0skmSQcBWwD+i0ejPcKCf4gKbJBuE1WrNqN4zTNMJNpYcqasms9frvYgfAMoVNqeFIPC9c3d391WCcZYNag0IE1ZHMzMzlZaTzWb7APZZWfprfz8CYbiSyeS74oDT6TzCRskHgWrHTlx/f/+aODgwMBBjsySDoJHhGC/8wWBQGUBmNpsvwmcLSz9Vzb4ipfX19XhnZ6cyB85isXzBhrUGBMYLRzabrQwmg5bUm2yaZBAEA+OFG3rbJXGi2+2eZeMkg1DFC19fX98GjeH/MZVKddF+VpNU0ygOotbV29v7HX5sb2//ms1rDQiMF7ZCofC4KAAwPmYDJYNQwXCOjY0VVMH7BJsoGYQqeHugg/e5KOhyubK0n6VBdY8GJ4Id0Nm7QlXUZTayBSBEZw9njvb09GwRjDU2szUgHsrUAoz32VDJIFQwHsjUms3mF2g/qw4lEgm7pum9B2VqHQ7HITa3Ptnt9iTVKv80POF9f6YWB6exufUJALxOP+JLmpaAEJlaEbxxSQg2uHbB9jvNP5nXCkLJ1M7NzT2rGp9zhk2u6Wl4h96E3lSG1WhdJojihWtycvJFFYyv2OzqgsbNUeHV4ODgK0oWttyEhbNEzzudTr+mgoEDmrvaeNu/vS08girpHM3CMjVtKTnRksrlckcDgcCvdLO/QMdpBpKRN1xc7FX1yp+RSOQcjTE2N31xRWpJeZeXl7PhcPgHXlr0Yfl8vr8zmcxbtLaVVbflRsXbPZxfAU/HG36//ya0Du4b2XyPx3MbfphbCwsLL5f/W/nST+kik64L8BIMB1HHGydAQwZVkqZGh8kPV6U6krASsmjaWgiIWOHRiPKQ+Xbyw3SQX/8Cb42i2awperkAAAAASUVORK5CYII=)\x208\x208\x2010\x2024\x20fill\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20form[role=\x22search\x22]\x20>\x20div[nitefall_imagetype=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'yPpeg',
        '.attachment-woocommerce_thumbnail',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.aside-btn,\x20.mypage-btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'oynnR',
        'Wdgmu',
        'TKUOn',
        '.listing-top.with-feature\x20a.overlay',
        'navy',
        'push',
        'img[data-srcset]',
        'zeDix',
        'cSqrA',
        'HoSma',
        'zSEar',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.title-bar\x20.logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.comment-gray\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.newlist_normal\x20.title_newlist_normal\x20.comment-gray\x20i.fa.fa-comment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAABYklEQVQokd2SMUvDUBDH/4nP60FpDR0eqFnEzdXNbyC4+Qn8Lo4Ogs5OfgDd3DqIjopQLE4ORiJFQ0yipO+ZRK5NhwqFipsHB493d7/7v3vnpGl6FATBnjGmifmtIqKe7/unTr/fDzqdzjIRuVLuuu5clDzPP6IoCpUxZpWZf9F8bMzcNMasz9dutjl/BeAfABQRFXmeu8zs/AyWZTmz0BhTEFEsi3QQBMGGMWbL87wlz/OmEuM4Fq8AFPXVO4BXIop83792qqqSJVgBcBiG4U5RFE673Z4UW2Z+1FpfAXgAEAG4BPAM4EtEKgBDAE8AbhuNxnaWZUqkJ0lSMvO91nofQBdAKisMwE7NQJZBSABeiGhorVVJkmTM3NNanwC4APBZ54kv1PkCGwHkIN5VSt1Ya9darda51voMwF0dW6yVyq9NQCObzMDUsN3BYLCptT4G8FYXSkzeKy4AUTBWAQy/Ac4mjxRGs3sdAAAAAElFTkSuQmCC\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tel_item\x20.detail_tel_item\x20.buttons_container\x20.btn:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20all\x20host\x20======================*/\x0a\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20',
        'USxFW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mobileBtns\x20li,\x20#mobileBtnsBot\x20li,\x20.button_last,\x20.calendar_img,\x20#septa_main_content\x20ul.subnav\x20li.normal\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button_beg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#septa_left_navigation\x20form#septa_location_destination_planner\x20p.septa_trip_planner_apps\x20.planner_button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.comment-gray',
        'className',
        '.accordion-item__header',
        'darkturquoise',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article,\x20#header{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'default',
        'GRVsv',
        'wMwQF',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-c,\x20.ui-overlay-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'shPTo',
        '-width',
        'kIXLE',
        'mhHxK',
        'a.fl\x20em',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#wCategory\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page-home\x20.section{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'div',
        '#mobile-menu',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#menu-menu,\x20.nice-select\x20.list,\x20.nice-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20.main-nav,\x20.main-nav.dark_style\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'LuiLR',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#nyc-main-header\x20.toggle-search,\x20#nyc-main-header\x20.header-top\x20.toggle-mobile-side-nav,\x20#nyc-main-header\x20.header-top\x20.toggle-main-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.actions__button-image',
        'NJjUF',
        'parent',
        'SOUrY',
        '.ndm-chart__image-anchor\x20svg',
        'lp-rich-link',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-widget\x20h3.ui-accordion-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'AFNVQ',
        'nitefall_dark_maps',
        'DWjcV',
        'HSHbY',
        'royalblue',
        'TRoeo',
        'grey',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[alt=\x22top\x22],\x20img[alt=\x22footer\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.buttons,.buttons2,\x20\x20.navigation\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[rel^=\x22dropmenu\x22]\x20>\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.caas-readmore-collapse:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fp-ph-block:after,\x20.fp-ph-block:before,\x20.fp-pholder:after,\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.caas-card-loader:before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#content,\x20#wrapper,\x20#nav-post,\x20#container,\x20#sidebar,\x20#footer-bott,\x20#footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkMode',
        'darkviolet',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20control-layer-group\x20>\x20*,\x20control-measure-group\x20>\x20*,\x20control-export-group\x20>\x20*{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20control-layer-group\x20>\x20*\x20>\x20button,\x20control-measure-group\x20>\x20*\x20>\x20button,\x20control-export-group\x20>\x20*\x20>\x20button,\x20.btn_location,\x20.btn_zoom_in,\x20.btn_zoom_out{\x0a\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn_share\x20>\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.oa_rd,\x20.search_error_wrap\x20.bx_atmp\x20.msg_atcmp\x20.spr_ico_msg2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'FErwy',
        'deeppink',
        '\x20======================*/\x0a\x20\x20\x20\x20',
        'JxPYh',
        'PhqmK',
        'clamp',
        'TkPQQ',
        ':after',
        'mediumseagreen',
        'IFRAME',
        'zunNP',
        'silver',
        'gLxoB',
        'snow',
        'img[loading=\x22auto\x22]',
        '.column-bg-overlay-wrap',
        'dMPLH',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cookie-banner-wrapper.is-visible,\x20.mobile-main-menu-links-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'Uamft',
        'Sgtfi',
        '.com.fr',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.select-kit-body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-panel\x20.widget-link:hover,\x20.menu-panel\x20.widget-link:focus,\x20.menu-panel\x20.categories-link:hover,\x20.menu-panel\x20.categories-link:focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20main[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#examples-content\x20.example\x20.trg\x20.text-nikkud\x20em,\x20#examples-content\x20.example\x20.trg\x20.text\x20em\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#858500\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'JJBmx',
        'RRtZv',
        'qCyBC',
        'BONfn',
        'bJfiz',
        'includes',
        'nkUaH',
        'steelblue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mw-wiki-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.25)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mw-parser-output\x20.tmbox\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color\x20:\x20rgb(68,\x2050,\x2023)\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[title=\x22Check\x20mark\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.vector-menu-tabs\x20li,\x20.vector-menu-tabs\x20a,\x20.vector-menu-tabs\x20li\x20a,\x20#mw-page-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lang-list-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outline:\x201.6rem\x20solid\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[src^=\x22/static/images/mobile/copyright/wikipedia-wordmark-en.svg\x22],\x20.mw-ui-icon-mf-expand:before,\x20.indicator.mw-ui-icon-flush-left::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mwe-math-fallback-image-display,\x20.mwe-math-fallback-image-inline{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color\x20:\x20transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table-yes,\x20.table-no,\x20.table-maybe,\x20.table-partial\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.lazy-image-placeholder{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.infobox_v3\x20caption,\x20.infobox_v3\x20.bloc\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#4895f9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.infobox_v3\x20.entete\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#4895f9\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20td\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#3366cc\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[aria-label^=\x22Today\x22]\x20span[jsslot]\x20>\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20li[role=\x22listitem\x22]\x20span[jsslot],\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selectedid=\x22browse_calendars\x22]\x20div[role=\x22presentation\x22],\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selected-date]\x20>\x20div\x20>\x20span{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-selectedid=\x22browse_calendars\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'none',
        '.photo_block',
        'slateblue',
        'meta[name=\x27color-scheme\x27]',
        'mMMZE',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post_header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#0051bb\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pagecurrent\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#a26135\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.anonce_body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#937b0f\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.post-block.spoil.open\x20>\x20.block-body:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20outline:\x20solid\x205px\x20#theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'light',
        '7490vrGNFe',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-spot-im-shadow-host^=\x22conversation\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.31);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'styleSheets',
        'qczrf',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20fieldset>a>div>div>select,\x20fieldset>a[href]>div>div\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20url(\x27data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAANCAYAAACQN/8FAAAAUElEQVQoz2NggIKysrI6EGbAB6CK/kNxHT6FLUgKQbiaaorb0RRXUK4YKCENxG+RFD4BYiFsim6jKVKhnSIWID6CVxGSYhWoAtyK0BTjVAQA7b9/uRuNojcAAAAASUVORK5CYII=\x27)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ThcsU',
        'textContent',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchfield_input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#dictionarySelector\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(122,\x20111,\x209)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'mSilh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-dialog.ui-overlay-d,\x20.ui-btn-up-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-c\x20,\x20.ui-bar-b,\x20.ui-btn-up-c,\x20.ui-body-e,\x20.ui-dialog.ui-overlay-e,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-d,\x20.ui-btn-down-d{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.postbitlegacy\x20.postfoot\x20a.newreply,\x20.postbit\x20.postfoot\x20a.newreply\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notices\x20li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#866e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.navtabs\x20li.selected\x20a.navtab\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'JopZp',
        '.character-slide-image',
        'DrZyH',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#onetrust-consent-sdk\x20#onetrust-banner-sdk\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header-nav-lacroix\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[id^=\x22reader.external-link.num\x22]\x20em{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mini-suggest__popup_old-style_yes.mini-suggest__popup::after,\x20.promo-popup__content,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-user__registration-button.button2[class]::before,\x20.check-button_theme_normal:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.radio-button_view_classic.radio-button_theme_normal\x20.radio-button__radio:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button2_view_classic.button2_theme_normal:before,\x20.button2_theme_default::before,\x20.header3__clear\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-header__logo\x20.logo.logo_name_yslogo-en-86x35,\x20.logo-wrapper__logo_name_ys-en,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__logo\x20svg,.m-svg\x20.logo__image_bg,\x20.yandex-search__logo,\x20a.logo{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.7)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.serp-footer__link:before,\x20.region-change__link:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.competitors__link:first-child::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.actions__button_action_refresh\x20.actions__button-image,\x20.actions__button_action_audio\x20.actions__button-image{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transaprent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.submit\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#cba306\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.advanced-search\x20.input__clear[class],\x20.mini-suggest_expanding_yes.mini-suggest_expanded::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20[class].header3__input:-webkit-autofill,[class].header3__input::-webkit-textfield-decoration-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.i-ua_js_no\x20[class].header3__input,\x20.header3__layout\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__layout,\x20.Theme_color_yandex-default\x20.Button2_view_raised:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.images-viewer-tabs\x20.images-viewer-tabs__tabs-menu\x20.images-viewer-tabs__tab.tabs-menu__tab:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mini-suggest_expanding_yes.mini-suggest_expanded\x20.mini-suggest__input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__service_current::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header3__input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.9)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.directblock_native\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.yandex-search__form::after,\x20.yandex-search__form::after,\x20.yandex-search__form::before{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-left-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20button.more\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[aria-label=\x22Page\x20Logo\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[data-text=\x22true\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'fWHti',
        'div[data-spot-im-module-default-area=\x22conversation\x22]',
        'aTBaF',
        'HpYwL',
        'getPropertyValue',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.blocks-gallery-item\x20figure{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:white\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table2\x20th\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'PVdcl',
        'yWMnF',
        'map',
        '.form_select_button-moduleformSelectButton39w9m',
        'ayIFk',
        'from',
        'EEYyy',
        'important',
        '.search-form\x20.search-input\x20.clear-btn.active',
        '<svg\x20xmlns=\x22',
        'EUMrd',
        'vSTcF',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fix\x20.gnb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header.section.fix\x20.hd_cafe_v2\x20h1,\x20.header.section.fix\x20h1,\x20.header.section.fix\x20h1\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20h1\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_search:after,\x20.header.section.fix\x20.gnb\x20a.gnb_search:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_ham:after,\x20.header.section.fix\x20.gnb\x20a.gnb_ham:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb\x20a.gnb_home:after,\x20.header.section.fix\x20.gnb\x20a.gnb_home:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20header\x20.btn_list\x20.btn_cafe\x20a:before,\x20.side_menu\x20header\x20.btn_list\x20.btn_write\x20a:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20header\x20.btn_list\x20.btn_news\x20a:before,\x20.side_menu\x20header\x20.btn_list\x20.btn_talk\x20a:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20.menu_first\x20.all:before,\x20.side_menu\x20.menu_first\x20.popular:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.side_menu\x20.menu_first\x20.popular_member:before,\x20.side_menu\x20.menu_first\x20.cafe_tag:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ONIya',
        'dodgerblue',
        'jiIdm',
        'peru',
        'mXSRi',
        'header.page-header\x20.page-header-image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20z-index:\x20auto\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'ccABq',
        'stopColor',
        'QQIbZ',
        'vRMwn',
        'EzuZo',
        'nighg',
        '_0xd79f86_0xdaeae5_0x1fe767\x20>\x20_0xd35a0e',
        'zvJfA',
        'txYpA',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20text[fill=\x22#222222\x22],\x20text[fill=\x22#000000\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#icon_search',
        '6|4|3|1|2|5|0',
        'FBAtc',
        '.et_mobile_menu',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mw-page-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#searchInput\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mw-ui-icon-wikimedia-menu-base20:before,\x20.mw-ui-background-icon-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.lazy',
        'indigo',
        '.pagination-bullets',
        'max',
        'JqALC',
        'backgroundColor',
        'tHOnh',
        'nitefall_image_dim_style',
        '.png',
        '4|2|3|1|0',
        '.gnb-btn',
        'AAtJf',
        'tEDMA',
        'sjfhL',
        'SCRIPT',
        'IJEBU',
        'tagName',
        'mdPhu',
        'Denwx',
        'AUZHT',
        'border-',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bismillah\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'QdUXs',
        'canvas',
        'lightgoldenrodyellow',
        'ghostwhite',
        'iAYwd',
        'join',
        'shadowRoot',
        'FoAuk',
        'linear-gradient',
        'location',
        'PBTwJ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.header,\x20#footer-menu,\x20.drawer__title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.searchform__submit,\x20#toc_container\x20.toc_title:before,\x20.ez-toc-title-container:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cat-name,\x20.pre_tag\x20>\x20span,\x20.pagination\x20.current,\x20.post-page-numbers.current,\x20#submit,\x20.withtag_list\x20>\x20span,\x20.main-bc-before\x20li:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'remove',
        '880aYCNgP',
        '.ant-card-body',
        'IbQMJ',
        'DGRVq',
        'LIQrJ',
        'SVG',
        '.GlobalHeader__Bg',
        '.ZMqA2d',
        'Nqvru',
        '.com.tr',
        '.com.tw',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mheader_wrap\x20.btn_cart:after,\x20.mheader_wrap\x20.btn_my:after,\x20.mheader_wrap\x20.btn_menu:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.box__homemain-app-install-banner\x20.button__close\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'kxhYU',
        'JjlUW',
        'min',
        'querySelectorAll',
        'xeiSA',
        '*[nitefall_imageType],\x20img\x20{transform:\x20translateZ(0);\x20filter:\x20brightness(',
        'log',
        'www.finam.ru',
        'orchid',
        'ggRNd',
        'wGgpI',
        'tPJUC',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20._3S3n_:after,\x20._1nF12:before,\x20.i4HRi:after,\x20.tk1IQ:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20form\x20div[role=\x22listbox\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20summary\x20div\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'documentElement',
        'TiAnN',
        'bCGYu',
        '.ctpx-box-bg\x20>\x20span',
        'nextSibling',
        'ZDIzZ',
        'orangered',
        '*[class^=\x22Overlay__overlay__\x22]',
        'zoCvr',
        'qGBmB',
        '.paginate',
        'GLwBd',
        'hUIyf',
        'theme',
        'PATH',
        'svg',
        '\x20======================*/\x0a\x0a\x20\x20\x20\x20',
        'yilIL',
        'XnVQy',
        '.gal\x20.img',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product-icon[nitefall_imagetype=\x22svg\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkcyan',
        'KXGwx',
        'SHOW_ELEMENT',
        'hasAttribute',
        'LEfMV',
        'yZQLu',
        'nitefallHashCode',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20button[data-toggle=\x22dropdown\x22],\x20.dropdown-menu,\x20input[type=email]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20input[type=text],\x20select,\x20textarea\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-menu\x20i,\x20.dropdown-menu\x20.selected\x20i.check-mark:after,\x20.framed.phonefinder-slider-highlight\x20label.label:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-menu\x20.selected\x20i:after,\x20.dropdown-menu\x20i:after,\x20.framed\x20label.label:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.8)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header.clearfix\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'qbXGf',
        'uQduw',
        'UdHCC',
        'MMJDH',
        'svg[data-visualcompletion=\x22ignore-dynamic\x22]',
        'jpg',
        'SCwCL',
        'sRjit',
        'Lqfee',
        'RgrjM',
        'VFMzU',
        'darkgreen',
        'XgRAr',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'luYLy',
        'prototype',
        'data-eski-please-include-in-mobile-version',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.button_icon:after,\x20.sprite_icon:after,\x20.button_tab:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'pedQF',
        'referrer',
        'cIeBW',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a\x20svg[width=\x2225\x22],\x20a\x20svg[width=\x2229\x22],\x20svg[aria-label=\x22responses\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'lYsMd',
        'ieRmJ',
        'TuXCO',
        'SXhRA',
        'lkUTd',
        'khaki',
        'xGzpg',
        'JrqRv',
        'a[class^=\x22CollapsibleSidebarMenuItem__StyledLink\x22]\x20svg',
        'orange',
        'cWxQn',
        '1|4|3|0|2',
        'ant-select-dropdown-menu-item',
        'licenseNumber',
        'image/svg+xml',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header-wrap,\x20#page\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'LZNif',
        'SoEvc',
        'firebrick',
        '#bottom_ribbon_modal_wrapper',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20form#form_search_location.js-searchbox_redesign.searchbox_redesign.searchbox_redesign--iphone.searchForm.searchbox_fullwidth.placeholder_clear.b-no-tap-highlight{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        'iixVW',
        'resolve',
        'querySelector',
        'exports',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.JyscU{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20._8-yf5,\x20img[alt=\x22Instagram\x22],\x20.glyphsSpriteFriend_Follow\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[aria-label=\x22Audio\x20is\x20playing\x22],\x20svg[aria-label=\x22Audo\x20is\x20muted.\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[aria-label=\x22Tags\x22],\x20svg[aria-label=\x22Video\x20has\x20no\x20audio.\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[fill=\x22#ed4956\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'YJiwW',
        'hwzIf',
        'data:image',
        'xdDgy',
        '.galaxy-container',
        'removeAttribute',
        'mediumpurple',
        'AnDjS',
        'otEnP',
        'AgwdJ',
        '-color',
        'CANVAS',
        'gyEbo',
        'IIGJk',
        'nTckI',
        'goldenrod',
        'div[aria-label=\x22Loading\x22]',
        'nyBfl',
        'innerHTML',
        'PrJZX',
        'GtoXm',
        '.voice-search-button',
        'YzFor',
        '.JvtkOe',
        'magenta',
        '.mc-logo',
        'honeydew',
        'qELPn',
        'nitefall_imageType',
        '.fastforward-right',
        '#mw-mf-main-menu-button',
        'mediumturquoise',
        '8|2|6|3|0|9|7|1|4|5',
        'indexOf',
        'Ysqzh',
        'VTagT',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20#cactus-body-container>.cactus-sidebar-control.sb-ct-medium.sb-ct-small>.cactus-container:not(.ct-default):before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cactus-sidebar:before,\x20#body-wrap:not(.cactus-box)\x20.cactus-sidebar-control.sb-ct-medium\x20.main-content-col:after,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#body-wrap:not(.cactus-box)\x20.cactus-sidebar-control.sb-ct-small\x20.cactus-container:not(.ct-default)\x20.main-content-col:before,\x20.cactus-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'pPMTX',
        'TjyUj',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20end\x20of\x20css\x20for\x20',
        'bqgDw',
        'TjZaU',
        '.icon-esrb',
        'oefgZ',
        '.module-item',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.fig-media__container,\x20.fig-lazy\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#fh\x20.fh-top{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'WRRoX',
        'getContext',
        '0|2|3|4|1',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}',
        '#chart_beta',
        'lurkD',
        '.intercom-lightweight-app-launcher-icon',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.css-40ap13:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20button\x20>\x20svg,\x20li\x20a[href*=\x22github.com\x22]\x20>\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'sandybrown',
        'CIYps',
        'mgtqb',
        'blueviolet',
        'invertPng',
        'header\x20.Ngnb',
        'fabHP',
        'XlCXh',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20._3TL8d,\x20.NavMain,\x20.ButtonBurger\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ButtonBurger__line\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SidePanel__dot\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.valori_wrapper\x20.valore_attributo',
        'isColorful',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20span.nav-logo-base\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.1)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'test',
        'img[data-ezsrc]',
        'hexString',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(218,\x2062,\x2082);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20position:\x20absolute;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20top:\x200px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20z-index:\x201000001;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20width:\x20100%;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-align:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-weight:\x20bold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x202px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-family:\x20Helvetica,Arial,sans-serif;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20line-height:\x2017px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-size:\x20',
        'hNbtM',
        'OhYwl',
        'addListener',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#maps_sb,\x20#id_hbfo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MicrosoftMap\x20.taskBarPopout\x20.menuLinkIcon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'VSwZe',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.home-search\x20>\x20input[type=\x22search\x22],\x20.sidebar-search\x20>\x20input[type=\x22search\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ZVcTF',
        '.thb-borders',
        'QQmpl',
        ')\x20!important;\x20}',
        'xcGRl',
        'LIiev',
        '.coto_short-stack',
        'ZqORg',
        '#ca-watch',
        'zGRds',
        'cAFum',
        'lime',
        'cfrMQ',
        '.title-dark-sea-blue',
        '.full-link',
        'jLxTa',
        'VRxgA',
        'RjOol',
        'erewD',
        'LpoPz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.well,\x20.panel-default>.panel-heading\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'url',
        'html',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.logo-rf\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[href*=\x22/intl/en/about/products?\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a[aria-label=\x22Settings\x22]\x20div[nitefall_imageType=\x22png\x22],\x20button[title=\x22Help\x22]\x20span[nitefall_imageType=\x22png\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20img.gb_tc\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.25)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'Atxmt',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dcg-graph-inner\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'IaoWB',
        '2|23|9|8|0|6|21|27|3|7|24|19|13|17|10|16|15|22|25|1|4|11|20|14|26|18|12|5',
        'uIMud',
        '.swiper-pagination',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.category-header\x20hgroup,\x20#content-body>div>section,\x20#content-body>section,\x20#content-aside\x20.tagline,\x20.cblocks\x20.cblock,\x20#ctree,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content-main\x20hr.sec.alt-langs:after,\x20#content-main\x20.alt-langs-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'eYNPy',
        'qtERi',
        'osaAV',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.TextInput-module--textarea--oUXvH:disabled\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.4)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dl_header:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.k_head\x20.tit_pay\x20.ico_logo,\x20.k_head\x20.btn_menu,\x20a.btn_close\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.com.pt',
        'DvTUy',
        'lyXNg',
        'NPjhw',
        'Rzzyv',
        'igXOT',
        '.PageSECFilings\x20.pane--banner',
        'dimgray',
        'top',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tl_article.tl_article_edit\x20[data-placeholder].empty:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tl_article.tl_article_edit\x20[data-label]:after,\x20.tl_article.tl_article_edit.title_focused\x20[data-label].empty:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.single-handbook\x20#page{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'game-tile',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#accs_survey_offer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#936d0b\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container.psp\x20#main\x20#more-results-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container.psp\x20#more-results-button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.featured\x20.top-results.dt-thumbnail\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'aBMtM',
        'VtGWG',
        'gainsboro',
        'RbvOl',
        'jvUvZ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir]\x20.gradients--sunnyDay--17X6W,\x20.appWrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir]\x20.ExpandableMenu--ExpandableMenu--2HGl7.ExpandableMenu--open--2oMlM>.ExpandableMenu--inner--39JQs,\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22ExpandableMenu--inner\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20svg[data-testid=\x22DonutChart\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.image-lazy-loaded',
        'cnRlh',
        'right',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mastbody_l,\x20.mastbody_c,\x20.mastfoot_c,\x20.mastbody_r,\x20.masthead_c,\x20.masthead_r,\x20.masthead_l\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cTopicOverview__preview:after,\x20.ortem-content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'tmztt',
        'salmon',
        'auto',
        'body\x20*:not(img)',
        'colorScheme',
        'length',
        '(prefers-color-scheme:\x20dark)',
        'nitefall_image_invert_pdf',
        '.hamburger',
        '10zftBrO',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.news\x20.li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'gold',
        'EaAKM',
        'img[loading=\x22lazy\x22]',
        'nSXgg',
        'NDaHr',
        'oBLVR',
        'mrNqJ',
        'QMTxQ',
        'nWAVG',
        'RleFy',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[role=\x22button\x22\x20]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20figure.chapternav-icon\x20,\x20figure[class^=\x22image-compare-icon-\x22],\x20div[class^=\x22iphone-\x22]\x20figure[class^=\x22image-icon-\x22],\x20div[class^=\x22ipad-\x22]\x20figure[class^=\x22image-\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ribbon-blue-to-default\x20.ribbon-content-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20animation:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.as-imagegrid-img-cont\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.promo-copy-wrapper\x20>\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.apple-one\x20.promo-copy-wrapper\x20>\x20h2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.light-available{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'JgZjL',
        'STYLE',
        'NOSCRIPT',
        'Vzymq',
        'ZONdP',
        'host',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ioUsz',
        '.kix-page-paginated',
        '.icon-contentFixedh5s',
        'ZAAgM',
        'violet',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.repo-gh\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20code[class*=language-],\x20pre[class*=language-]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'sXBNB',
        'yIbzG',
        'xRBWt',
        'src',
        ':before',
        'navajowhite',
        '#__next\x20.jwQWkK',
        'Pczhk',
        'JRepq',
        '.ctpx-box-content',
        'saddlebrown',
        '\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20all\x20host\x20======================*/\x0a\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pack-header-image\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'NAbPU',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20h4#draft,\x20h4#non-standard\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:transparent\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.notecard.draft,\x20.notecard.experimental,\x20.notecard.secure,\x20.notecard.warning{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:#b19e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:#b19e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.copy-icon,\x20.search-button{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bc-platforms\x20.bc-platform-desktop:before,\x20.bc-platforms\x20.bc-platform-mobile:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bc-browsers\x20.bc-head-txt-label:before,\x20.ic-footnote:before,\x20a.external:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20ul.main-menu\x20.top-level-entry:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'xmlns',
        'FZPfk',
        'SSiis',
        'whitesmoke',
        'JtJGw',
        'mistyrose',
        'eITJy',
        'OAAIh',
        'lightslategrey',
        'cGrvv',
        'testing-dark-mode',
        'div[class^=\x22informers__icon\x22',
        'style',
        'kMXEj',
        'wNDas',
        '\x20derived\x20from:\x20',
        'vyDkP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.onesignal-bell-svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more\x20.btn-aside,\x20.wrap\x20header\x20.area-bottom\x20.header-more:before,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more:after,\x20.wrap\x20header\x20.area-bottom\x20.header-more:before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.wrap\x20header\x20.area-bottom\x20.header-more\x20.btn-aside\x20.name{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'MsYeI',
        'Npkgc',
        '#waffle-grid-container',
        'endsWith',
        '.cytyle-flat\x20#controls',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.use-theme-bg\x20.post\x20.page-title,\x20.use-theme-bg\x20.post\x20.page-title\x20a,\x20.use-theme-bg\x20.post\x20.subtitle,\x20.use-theme-bg\x20.post\x20h1,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.use-theme-bg\x20.post\x20h1\x20a,\x20.use-theme-bg\x20.post\x20h1.title\x20a,\x20.use-theme-bg\x20.post\x20h2,\x20.use-theme-bg\x20.post\x20h2\x20a,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.use-theme-bg\x20.post\x20h3,\x20.use-theme-bg\x20.post\x20h3\x20a,\x20.use-theme-bg\x20.post\x20h4,\x20.use-theme-bg\x20.post\x20h4\x20a,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.use-theme-bg\x20.post\x20h5,\x20.use-theme-bg\x20.post\x20h5\x20a,\x20.use-theme-bg\x20.post\x20h6,\x20.use-theme-bg\x20.post\x20h6\x20a,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.use-theme-bg\x20.post\x20p,\x20.use-theme-bg\x20.post\x20p\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20*#dm\x20*.dmBody\x20div.u_1942127116\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20*#dm\x20*.dmBody\x20*.u_1942127116:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20transparent\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#layout-drawer-hamburger\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkseagreen',
        'pNdEB',
        '.btn[_ngcontent-c2]\x20.caret[_ngcontent-c2]',
        'Your\x20Nitefall\x20trial\x20has\x20expired.\x20Please\x20purchase\x20premium\x20from\x20Nitefall\x20main\x20app\x20to\x20use\x20on\x20it\x20on\x20an\x20unlimited\x20number\x20of\x20websites.',
        'Hafys',
        'browser',
        'ZCpDg',
        'DIV',
        'Ppovy',
        'ATcLJ',
        'finding\x20custom\x20css\x20for\x20',
        '.mwe-math-element',
        'div.tile',
        'Vpuyt',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[ng-repeat=\x22container\x20in\x20containers\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'vWeqx',
        'azure',
        'wTtvG',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20suggest-table\x20.table-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ga-mobile-events-page\x20suggest-table\x20.table-suggest-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ga-viz-table\x20.ga-viz-table-default-background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.iframed\x20.realtime-card.md-scionTheme-theme\x20.ga-data-table\x20.ga-viz-table-row-background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20rgb(0,\x2087,\x20227)\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20g\x20text,\x20.ga-data-table\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20fill:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.dsc\x20.u_hc',
        'doc',
        'com',
        'LPdAM',
        'TnmEB',
        'piXff',
        'GBiYi',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#block-taxonomymainmenu,\x20.page-node-type-news\x20article.news.full\x20footer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cULDd',
        'undefined',
        'UJDZe',
        '#dropDownMenuButton\x20.moreButton',
        'PZbJB',
        'HvXDW',
        'wnPGt',
        '.finfin-header-logo-name',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a[data-t-l]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnt_m_dl::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'addEventListener',
        ';\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20white\x20left\x20gradient\x20when\x20page\x20is\x20loading\x20on\x20google.\x20apply\x20it\x20in\x20custom\x20css\x20is\x20too\x20late,\x20so\x20we\x20apply\x20it\x20here*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.cG5GOd,\x20.P1Ycoe{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#sDeBje\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*github\x20raw\x20content\x20is\x20not\x20triggering\x20on\x20DOM\x20content\x20loaded,\x20so\x20we\x20use\x20this\x20as\x20workaround\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body\x20>\x20pre\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20h2,\x20h3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'HvnFf',
        'BNcLk',
        'iuNiz',
        'wuUAh',
        'wwCbn',
        'rules',
        'mryIv',
        'amd',
        'antiquewhite',
        'nitefall_start_workaround',
        'nitefall',
        '.slick-active',
        'div[class^=\x22NewUserAccount__AccountMenu-\x22]',
        '.content-page__navigation__group',
        'KtGRH',
        'png',
        'slice',
        'cadetblue',
        '.bx-custom-pager',
        'kzqsJ',
        'ugpuz',
        'matchMedia',
        'luminance',
        'header\x20.gnb',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Header__icon--notification,\x20.Header__icon--menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'xorjE',
        'qoBmF',
        'IEBdF',
        'toLowerCase',
        'PDiTN',
        'div[class^=\x22StyledComponents__DisabledOverlay-\x22',
        'ymXJP',
        'hhTQm',
        'wcLnH',
        'DWcrR',
        'darkorange',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.uni-navigation--desktop\x20.uni-main-menu__submenu-wrapper:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'catch',
        'bgColors',
        '.mwe-math-fallback-image-display',
        '#interaction_fog',
        '9309756vhahaI',
        'svg.bdl-IconPlusRound',
        'RcXZc',
        'com.some.email.app',
        '3jAxUwO',
        'LkeWU',
        'chocolate',
        'aqua',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.background-layer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'YplUO',
        'fpPfq',
        '33556pyrcDS',
        'red',
        '.page-links',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tds-form-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#coral_thread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(100%)\x20hue-rotate(180deg)\x20brightness(150%)\x20contrast(90%)\x20sepia(25%)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'monokai',
        '.timer',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#middle,\x20.sb\x20h3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bot\x20.genre\x20a,\x20.meta,\x20.bot\x20.show\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#search\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgb(82\x2080\x2080)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'background',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ot-sdk-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.icon-mojang-studios',
        '\x20======================*/\x0a\x20\x20\x20\x20\x0a\x0a\x20\x20\x20\x20/*\x20====================\x20css\x20for\x20',
        'livcG',
        'userAgent',
        'Umwae',
        'abs',
        '.CodeMirror',
        '.toggleside',
        'TmrAz',
        'purple',
        'PeKgL',
        'currentNode',
        'mcIFI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-widget-content\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'VFnKB',
        'AWxAp',
        'yObSP',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.dropdown-wrap\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#secGroupings,\x20#SecYearSelect,\x20span[role=\x22columnheader\x22],\x20#_ctrl0_ctl66_lblMailingListsText,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#_ctrl0_ctl66_chkLists\x20td\x20label,\x20#_ctrl0_ctl66_lblEmailAddressText,\x20.module_options-select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.module_input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'http://www.w3.org/2000/svg',
        '.table-maybe',
        'round',
        '.highcharts-root',
        'YThnE',
        'LBjoM',
        'mMeiN',
        'xfHMT',
        '.hmNwsSpe1',
        'fYIbp',
        'theme-color',
        'data',
        'ADTVd',
        'tELsY',
        '.wrapper_attributo\x20.elenco_scelte\x20label\x20.wrapper_valore',
        'SbcFA',
        'yyvPy',
        'tPPuG',
        'JBsnM',
        'apple-mail-implicit-dark-support',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20mix-blend-mode:\x20normal\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'darkolivegreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20span[class^=\x22OutlinedDropdownButton-valueIcon\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.FilterBar-control-1iu.FilterBar-next-zE-::before,\x20.FilterBar-filterWrap-Cys::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.PrimaryNav-link-3IW,\x20.PrimaryNav-logoWrap-564,\x20.PrimaryNav-iconWrap-1F1{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'appendChild',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[data-spot-im-shadow-host*=\x22conversation\x20conversation-survey\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(92%)\x20hue-rotate(180deg)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ocPmf',
        'BbivA',
        'thistle',
        'isLight',
        '\x20======================*/\x0a\x20\x20\x20\x20\x0a',
        '.home-search\x20>\x20input[type=\x22search\x22]',
        'olive',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.ant-select-dropdown-menu-item',
        'DZitr',
        'substr',
        'darkmagenta',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20pre,\x20.pre-lang\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#2e2e00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'li.clear\x20>\x20a[nitefall_imagetype=\x22gif\x22]',
        'cFshy',
        'zBHOM',
        'observe',
        'theme_color',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20label[style^=\x22color:\x20rgb(51,\x2051,\x2051)\x22],\x20#searchBySpecBox\x20.specBoxTTL\x20#specTTL\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.3)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#specBox\x20.specList,\x20.h1bg,\x20#menu\x20.keysearch_v2,\x20#menuNojs\x20.keysearch_v2\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#searchBySpecBox\x20.specBoxTTL\x20,\x20#itemList\x20.switch\x20li.detailOn,\x20#main\x20.h3Area,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#rankCate\x20.rcBoxTop,\x20#rankCate\x20.rcBoxBtm,\x20#historyBox,\x20#corporation\x20.corpTrendsearch\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#revSort,\x20.digestBox.newVer\x20.digestCtn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#corporation\x20.corpFeature\x20p\x20a,\x20#corporation\x20.corpPr\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#corporation\x20.corpShop\x20p\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20#menu\x20.menuArea,\x20#main\x20.boxSearchBtm,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.contType001\x20.contTtlIn,\x20.pullDownTtl,\x20.p-main_linkList_item,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20ul.sort\x20li\x20a,\x20ul.sort\x20li\x20span,\x20.p-plan_price_btn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.p-main_linkList,\x20.p-tab_item.is-active,\x20.submitBtnGray\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.breadcrumbs\x20ul,\x20.submitBtn4,\x20footer\x20.logoutBtn\x20a,\x20ul.linkBtns.with2Btn\x20li,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20ul.linkBtns\x20li,\x20.favSetTtl1,\x20.favChkLabelToggle,\x20.favStatusLabel,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.favMailLabel,\x20.favFolderBtn,\x20.moreElBtn\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.pricePrAreaSmallSize\x20.prBox,\x20ul.tabs\x20li.active,\x20.pricemail\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20.homebtnbnr,\x20#specToggle\x20.hType3Toggle\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#itemList\x20.switch\x20li.normalOff,\x20#itemList\x20.switch\x20li.simpleOff,\x20#itmArea\x20#itmBoxMax\x20.itmBoxBottom,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#itmArea\x20#itmBoxMax\x20.itmBoxIn,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-PTPay,\x20#listingPr\x20div,\x20#module\x20.rankingBox180,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mainRight\x20#module\x20.module-enq,\x20#pkuplist\x20#mainRight\x20.module-enq,\x20#pkuplist-top\x20.module-enq,\x20#bbs\x20.module-enq,\x20#review\x20.module-enq,\x20.review\x20.module-enq,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#module\x20.moduleBox01,\x20#module\x20.chosataiBox,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#interior\x20#menu\x20.menuAreaMain\x20h2,\x20.contType001,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-plan_search_select_in,\x20.p-plan_search_multiple,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tabbtnList\x20li,\x20.variationList\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.creditCard\x20.viewBtn,\x20#main\x20.h3Area:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pageNavigation\x20li\x20a,\x20.pageNavigation\x20li\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.p-PTFee_select_btn,\x20.p-PTPay_option_btn{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.historyContents\x20.historyItem\x20.historyInner,\x20#linkList,\x20.historyContents\x20.tabMenu,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.historyContents\x20.tabMenu\x20li,\x20.p-tab\x20ul\x20li\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.topicReplyNumLink\x20span.btn\x20.submitBtnGray\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.tabbtnList\x20li.active,\x20ul.tabs\x20li.active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#463f08\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.hdrWrpFixed,\x20.kakakuHdrWrp{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.makerComment\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#bea20a\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'IcXXZ',
        '.audience-review__default-image',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.listLinkDate\x20ul\x20li\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bt7\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sword\x20span.input,\x20.comments\x20.form\x20span.textarea\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gsc-search-box-tools\x20.gsc-search-box\x20.gsc-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'jUwlu',
        '.jpeg',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.diff\x20table.inline\x20tbody.mod\x20td.r,\x20.diff\x20table.inline\x20tbody.add\x20td.r\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20#004a00\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.diff\x20table.trac-diff\x20td\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'invert',
        'vVebt',
        'lawngreen',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button[data-action^=\x22auth:\x22]{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'RrkQr',
        'woUAA',
        'sydQH',
        'bLWsY',
        'gray',
        'forestgreen',
        'sXhOP',
        'xsJAL',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.promo-area\x20.bg-wool-light\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'OyoAy',
        'skyblue',
        'mlYCo',
        '.ndfHFb-c4YZDc-j7LFlb',
        'JUMqo',
        'usoCQ',
        'jmWYg',
        'paleturquoise',
        'xAtrz',
        'replace',
        'sAbVF',
        'pEhcP',
        'EsANZ',
        'oNgEn',
        '.PNG',
        'SKRrS',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#ac-globalnav\x20.ac-gn-link-apple-developer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.knockout-image,\x20.product-card__thumbnail-container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20mix-blend-mode:\x20unset\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.site-wrapper\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20body\x20.site\x20.site-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '#mw-mf-page-left\x20li\x20>\x20a',
        '.faq-page-header__title',
        'uAWZh',
        'slategrey',
        'YUzOJ',
        'rkRPQ',
        'HXcHm',
        'removeProperty',
        'YMATo',
        'QKETv',
        'div[class^=\x22avatar-\x22]\x20svg',
        '#searchIcon',
        'nodeType',
        'JeOfB',
        'pink',
        'toUpperCase',
        'KeqmG',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.table-download,\x20.overall\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20auction\x20page\x20on\x20ebay*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pc_template\x20>\x20.pastore_top_background\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pnl\x20.msg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#0062ab\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.c-std,\x20.c-std-bb\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#glbfooter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read,tr.msg-unread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read:hover,tr.msg-unread:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-read\x20.m-cur\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20tr.msg-unread\x20.m-cur\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn-ter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20box-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20#glbfooter{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sticky-header,\x20.m-items-header\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-d,\x20.ui-dialog.ui-overlay-d,\x20.ui-btn-up-d\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-c\x20,\x20.ui-bar-b,\x20.ui-btn-up-c,\x20.ui-body-e,\x20.ui-dialog.ui-overlay-e,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-bar-d,\x20.ui-btn-down-d{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'saturation',
        'HVkbU',
        'classList',
        'NjEpP',
        '#app-boot-bg-loader',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20picture.we-artwork{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'form[method=\x22POST\x22]\x20svg[width=\x2220px\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20table.halytyslista\x20tr.halytys\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.copy-to-clipboard-button',
        'nextNode',
        'hRwCd',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.burger-menu\x20.burger,\x20.search-icon\x20>\x20svg,\x20.menu-icon\x20svg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.down-vote',
        'outerHTML',
        'imageBrightness',
        'aliceblue',
        '#id-MainNavigation',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#page-container\x20.page-header\x20.nav-primary\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'uXvuq',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.et_mobile_menu{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.menu-item\x20>\x20a\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ZWTbx',
        'removeEventListener',
        'rgb',
        '\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.localinfomap,\x20.LocalInfo:before,\x20.LocalInfo:after,\x20.ThemePoiControlView\x20h3,\x20.ThemePoiControlView\x20.poi_item\x20span,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MapTypeControl,\x20.MapTypeControl\x20.ACTIVE,\x20.Tool\x20.tit_tool,\x20.tit_login,\x20.ThemePoiControlView\x20.Wrap\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.viewbuttons\x20.rv,\x20.viewbuttons\x20.lv-accessibility,\x20.MapControlView\x20.accessLocation,\x20.MapControlView\x20.tools,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.MapControlView\x20.tools\x20a,\x20.viewbuttons\x20.lv\x20.list_map_setting\x20i,\x20.MapControlView\x20.extension,\x20.MapControlView\x20.add_place\x20.link_new,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.FlagWrap\x20.Flag,\x20.Flag\x20a,\x20.Flag-drag\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'PbmXo',
        'iEDJo',
        'TXnRn',
        'vYbvu',
        'ALLJW',
        'darkkhaki',
        'HJjYk',
        'FIINM',
        'oTldN',
        'UXjRR',
        'img[data-lazy-srcset]',
        '.has-addons',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20/*\x20this\x20is\x20a\x20full\x20page\x20css\x20because\x20this\x20website\x20uses\x20eski\x20mobi\x20which\x20replaces\x20the\x20whole\x20document\x20html\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20@media\x20(prefers-color-scheme:\x20dark)\x20{\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20html,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22background-color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20html,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-reader\x20*:not([class*=\x27sr-pivot\x27])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h1:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h2:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h3:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h4:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h5:not([style*=\x22color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20h6:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20cite:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(232,\x20255,\x20228)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(59,\x2075,\x2088)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):hover,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(55,\x2079,\x20101)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:not([style*=\x22background-color:\x22]):focus,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20[role=\x22button\x22]:focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgb(53,\x2080,\x20105)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(230,\x20255,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(218,\x20247,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):active,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20a:not([style*=\x22color:\x22]):focus\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgb(206,\x20240,\x20255)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20:not([style*=\x22border-color:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20::before,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20rgb(145,\x20165,\x20172)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20div:empty,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-reader\x20*,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.sr-backdrop\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(28,\x2031,\x2033,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input::placeholder,\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea::placeholder\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgba(255,\x20249,\x20212,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input:not([style*=\x22background-image:\x22]),\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20textarea:not([style*=\x22background-image:\x22])\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.ibutton\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20rgba(28,\x2031,\x2033,\x200.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'meta',
        'indianred',
        'fCNpR',
        'WQlJi',
        'url(',
        'UKOxP',
        '5360718bsgceM',
        'cdovu',
        '.listing-top.with-feature\x20figure\x20.listing-large',
        'SBprT',
        'AkQiq',
        'JAjpv',
        'closest',
        'setAttribute',
        'AnWEm',
        'PPanl',
        'a.read_more',
        'STlkB',
        'then',
        'img[data-breeze]',
        '.accordion-item',
        'a[id^=\x22powered_by_pixlee\x22',
        'aside.js-modal',
        'ltvxg',
        'add',
        'ZsDJG',
        'DAHkW',
        'a.hx',
        '.mw-ui-icon-wikimedia-language-base20',
        '13px',
        'com.apple.email.maild',
        'lightgrey',
        'readyState',
        'XQOvM',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div.jw-reset.jw-button-container{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'qjQOm',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20header\x20.stuck,\x20header\x20.container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.owl-item>.product\x20.add-to-cart-wrap\x20.button::before,\x20.owl-item>.product\x20.added_to_cart::before,\x20li.product\x20.add-to-cart-wrap\x20.button::before,\x20li.product\x20.added_to_cart::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'function',
        'lAUHT',
        '.terminatorlet',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#container,\x20.board-body\x20.title-line\x20>\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'wwNZU',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bubble-action\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#0366d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.reponav-item\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20rgba(255,255,255,0.75)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.text-white\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#fff\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20strong.list-item-title\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#0366d6\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.list-item\x20.byline\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20#586069\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20.user-following-container\x20.btn\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(-180deg,\x20theme_sub_color\x200%,\x20theme_sub_color\x2090%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.btn.btn-outline.border-gray-dark.width-full.f6.mt-3\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(-180deg,\x20theme_sub_color\x200%,\x20theme_sub_color\x2090%);\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SelectMenu-modal,\x20.dropdown-menu\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'nHPHD',
        '.nitefall_processed',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20div[class^=\x22styles_item_\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.svg',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.codehilite\x20.hll,\x20.highlight\x20.hll\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20rgba(248,\x20255,\x200,\x200.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.date-outer\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.cw_tile__contacts-contactSearch',
        'white',
        'content',
        'seagreen',
        'SyKEd',
        '.GIF',
        '.ecs-facet-wrapper',
        'kunzH',
        'uioHG',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.pagecontent\x20#content-2-wide{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'contentWindow',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.cd__headline-text,\x20.container__headline\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20.Header__burgerIcon,\x20.Header__burgerIcon::before,\x20.Header__burgerIcon::after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.SocialBar__icon{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.header-logo',
        'PyJbL',
        'hXGdJ',
        'AKPBC',
        'DWUFz',
        'lightseagreen',
        '.bg-mint',
        'JFmBJ',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.field\x20.text-input\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#nasName\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:none\x20\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20#appLinks\x20div,\x20#mappLinks\x20div,\x20#tools-frame\x20.field\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'createElement',
        '.homepage-hero',
        'iTHkl',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header,\x20#header\x20div.frame,\x20#content_section\x20div.frame,\x20#footer_section,\x20#footer_section\x20div.frame,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content_section,\x20span.upperframe,\x20span.lowerframe,\x20.button_submit,\x20.button_reset,\x20span.upperframe\x20span,\x20span.lowerframe\x20span\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'UMYwh',
        'kNRjd',
        'Cdtrn',
        'tYHwX',
        'CyBoi',
        'kKKok',
        '.ac-gn-menuicon',
        '.fastforward-left',
        'Rsouj',
        'textColors',
        'lBUtI',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.sidebar\x20.section-heading,\x20#specs-list\x20p,\x20#specs-list\x20table,\x20.user-thread\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.review-header::after,\x20.specs-photo-main:after{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'isTransparent',
        'label[role=\x22checkbox\x22]',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20img[src^=\x22data:image/svg+xml\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'qPxed',
        'KSeWB',
        'JIzxK',
        'uUZfq',
        '.right-item-img\x20a',
        'nitefall_pseudo_elements_style',
        'left',
        'YNjro',
        'OpZGY',
        'gzEyO',
        'rgbString',
        'slategray',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.CodeMirror.CodeMirror-resizable\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'a.fl',
        'http',
        'mxESP',
        'DOMContentLoaded',
        'none\x20!important',
        'greenyellow',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20a.hx\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20lightgray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bd_btn,\x20.btn_img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        't.co',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.icon-img-nav,\x20a\x20i.icon,\x20ul\x20li.icon,\x20.swiper-button-prev,\x20.swiper-button-next\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.van-tabbar-item__icon,\x20.header-nav-m\x20>\x20.icon\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.5)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.estroe-main-s\x20.icon-contentFixedh5,\x20.gnb__depth1-container,\x20.gnb__menu-wrap.open\x20.gnb__depth1-container:after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.estroe-main-s\x20.icon-contentFixed\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.gnb__logo:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert(0.2)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'rcpPX',
        'KyFUz',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article\x20#commentaire,\x20#article\x20#links,\x20#article\x20#retroviseur,\x20#article\x20.cadre,\x20#article\x20.springboard,\x20#article\x20.pub,\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20#article\x20article,\x20#article\x20h1.listeTitle,\x20#pagination,\x20#search,\x20#search-title,\x20#tagcloud,\x20#team,\x20.auteurInfo,\x20#article\x20#shareit\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'dark-gray',
        'body',
        '.com.ec',
        'lightcyan',
        'ul\x20.shortcut-tile',
        'NIPgZ',
        'split',
        '#ca-edit',
        'backgroundImage',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-body-c,\x20.ui-overlay-c,\x20.ui-btn-up-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'getComputedStyle',
        'IWdfq',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir=ltr]\x20.card-theme-module\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20[dir=ltr]\x20.app-body-container-auth:before,\x20[dir=ltr]\x20.app-body-container-landing:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '.filter-PAINT',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#brand-logo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.category-wrap,\x20.recently,\x20.sponsor,\x20.related,\x20.tips-tricks,\x20.author,\x20.sponsor-full,\x20.newsletter-sidebar,\x20.widget,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#side-bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'alofi',
        '.fhr_mobLogo',
        'UodVr',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#mw-page-base,\x20div.vectorTabs\x20span,\x20div.vectorTabs\x20ul\x20li,\x20#simpleSearch,\x20div.vectorTabs\x20ul\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'ABOyN',
        '.header',
        'hotpink',
        'toString',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#content.grid2colb-box,\x20#ossmain\x20.box\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.box\x20.boxtop,\x20.box\x20.boxbottom\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'rsKNu',
        'WbXLb',
        'FzQJg',
        '.cytyle-flat\x20#escape',
        '.accordion-item__header\x20button',
        'tr.msg-read',
        '.thumb-title\x20>\x20a',
        'EbasB',
        'nPrxY',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bd_btn,\x20.btn_img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_sub_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20text-shadow\x20:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.bubble\x20b[nitefall_imageType=\x22png\x22]\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'tr.msg-unread',
        'ebay.app',
        '.article-page\x20.article-details>.keywords-section\x20.keyword-actions\x20.keyword-actions-trigger',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20#main-content,\x20.ref-bg\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20none\x20!important;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'cXLyV',
        'VJfVg',
        'EhOgL',
        'AxGdw',
        '.product_img_area__cmeBU',
        'a[href^=\x22/travel/explore\x22]\x20div[style^=\x22background-image\x22]',
        'img[src$=\x22.svg\x22]',
        'ZfzaA',
        '.listitem',
        'Msyaa',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-btn-up-c\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20none\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ui-listview,\x20.ui-body-c,\x20.ui-overlay-c,\x20.ui-mobile\x20.ui-page-active\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-image:\x20linear-gradient(\x20theme_color,\x20theme_color\x20)\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'FILTER_ACCEPT',
        'NLUtd',
        '12px',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.primary_logo,\x20.mobile_logo_inside,\x20.icon-cart,\x20.icon-menu,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.mm-menu.mm-theme-white\x20.mm-listview>li\x20.mm-next:after\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'xDOhZ',
        'tFUGE',
        'div[class^=\x22videothumb_\x22]',
        '.entry-title',
        '#000000',
        'ulmVu',
        'opfWT',
        'li.notice\x20>\x20a[nitefall_imagetype=\x22gif\x22]',
        'filter',
        'JOQnk',
        'darkred',
        'handing\x20mutabtion',
        'zlern',
        'cLFWK',
        'nitefall_image_invert_png_style',
        '.js--hidden',
        '.docs-sheet-tab-name',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.ArticleHeader-wrapperHero:before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'UoaPq',
        'UhvER',
        '.bundle_sc\x20.u_hc',
        '[stroke]',
        'tgoXl',
        'ssznY',
        '\x0a\x20\x20\x20\x20\x20\x20\x20\x20.product_button_wrap{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background:\x20theme_color\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search_btn\x20.search\x20button,\x20.basket\x20.btn_basket,\x20.top_menu\x20a,\x0a\x20\x20\x20\x20\x20\x20\x20\x20html\x20#aside\x20.categoryList\x20>\x20li\x20>\x20a.cate::after,\x20#center\x20a::after,\x0a\x20\x20\x20\x20\x20\x20\x20\x20#header\x20.top_logo\x20.xans-layout-logotop\x20img,\x20#layout\x20.top_logo\x20.xans-layout-logotop\x20img,\x0a\x20\x20\x20\x20\x20\x20\x20\x20.slide-logo\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20filter:\x20invert()\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.thumbnail\x20>\x20img\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20position:\x20initial\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20.search_left\x20>\x20ul:first-child\x20li::before\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20gray\x20!important;\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20',
        'LyXVb',
        'a[ping]\x20div[role=\x22heading\x22]',
        'LEyrd'
    ];
    _0x12c6 = function () {
        return _0x134460;
    };
    return _0x12c6();
}
var WEBPAGE_COLORS = {
        'bgColors': new Map(),
        'textColors': new Map()
    }, globalSettings;
const setNewColor = (_0x579da9, _0x1ee5ce, _0x508bcd) => {
        var _0x231720 = _0x52102f;
        switch (_0x579da9) {
        case 'bg':
            WEBPAGE_COLORS[_0x231720(0x3f6)][_0x231720(0x609)](_0x1ee5ce[_0x231720(0x50e)](), _0x508bcd[_0x231720(0x50e)]());
            break;
        case _0x231720(0x17f):
            WEBPAGE_COLORS[_0x231720(0x4fe)][_0x231720(0x609)](_0x1ee5ce[_0x231720(0x50e)](), _0x508bcd[_0x231720(0x50e)]());
            break;
        }
    }, getNewColor = (_0x427df8, _0x413ff1) => {
        var _0x14dc0c = _0x52102f, _0xf070da = { 'KtGRH': _0x14dc0c(0x17f) };
        switch (_0x427df8) {
        case 'bg':
            return WEBPAGE_COLORS['bgColors']['get'](_0x413ff1);
        case _0xf070da[_0x14dc0c(0x3de)]:
            return WEBPAGE_COLORS[_0x14dc0c(0x4fe)]['get'](_0x413ff1);
        }
    }, getPageColor = () => {
        var _0x1b15e1 = _0x52102f, _0x138fbb = {
                'EhOgL': _0x1b15e1(0x51d),
                'PPanl': function (_0x29182a, _0x67d9d4) {
                    return _0x29182a == _0x67d9d4;
                },
                'CdRhU': _0x1b15e1(0x409)
            };
        if (currentTheme == _0x138fbb[_0x1b15e1(0x546)])
            return new NFColor(0x16, 0x17, 0x16, 0x1);
        else
            return _0x138fbb[_0x1b15e1(0x4ba)](currentTheme, _0x138fbb[_0x1b15e1(0x608)]) ? new NFColor(0x28, 0x28, 0x27, 0x1) : new NFColor(0x0, 0x0, 0x0, 0x1);
    }, getPageSubColor = () => {
        var _0x626e54 = _0x52102f, _0x4fd663 = {
                'luYLy': function (_0x519898, _0x48a27e) {
                    return _0x519898 == _0x48a27e;
                },
                'VMeJN': _0x626e54(0x409)
            };
        if (currentTheme == _0x626e54(0x51d))
            return new NFColor(0x24, 0x23, 0x23, 0x1);
        else
            return _0x4fd663[_0x626e54(0x2b2)](currentTheme, _0x4fd663['VMeJN']) ? new NFColor(0x2e, 0x2e, 0x2e, 0x1) : new NFColor(0x19, 0x19, 0x19, 0x1);
    }, iterateElementsWithShadowHost = (_0x5bfed2, _0x265fb5) => {
        var _0x5f1fc1 = _0x52102f, _0x324574 = {
                'ynoFs': function (_0xea546a, _0x301fca) {
                    return _0xea546a == _0x301fca;
                },
                'ZWTbx': function (_0x4445c3, _0x4c3bb5) {
                    return _0x4445c3 == _0x4c3bb5;
                },
                'BlnPs': function (_0x1782b0, _0x4fc82c) {
                    return _0x1782b0 != _0x4fc82c;
                },
                'PDiTN': function (_0x2ac222, _0x4560d9) {
                    return _0x2ac222(_0x4560d9);
                },
                'WbXLb': function (_0x18814f, _0x544e1d, _0x3614d1) {
                    return _0x18814f(_0x544e1d, _0x3614d1);
                }
            };
        if (_0x324574[_0x5f1fc1(0x49a)](_0x5bfed2, null))
            return;
        const _0x588967 = document[_0x5f1fc1(0x69d)](_0x5bfed2, NodeFilter[_0x5f1fc1(0x29d)], {
            'acceptNode'(_0x449d5d) {
                var _0x1008c2 = _0x5f1fc1;
                return _0x324574['ynoFs'](_0x449d5d['shadowRoot'], null) ? NodeFilter['FILTER_SKIP'] : NodeFilter[_0x1008c2(0x54f)];
            }
        });
        for (let _0x34c487 = _0x5bfed2[_0x5f1fc1(0x266)] ? _0x588967[_0x5f1fc1(0x419)] : _0x588967['nextNode'](); _0x324574[_0x5f1fc1(0x15f)](_0x34c487, null); _0x34c487 = _0x588967[_0x5f1fc1(0x48f)]()) {
            _0x324574[_0x5f1fc1(0x3ed)](_0x265fb5, _0x34c487), _0x324574[_0x5f1fc1(0x537)](iterateElementsWithShadowHost, _0x34c487[_0x5f1fc1(0x266)], _0x265fb5);
        }
    }, processElement = (_0x2f2c8c, _0x50e4a5) => {
        var _0x17be02 = _0x52102f, _0xc922f0 = {
                'cSqrA': function (_0x14fa51, _0x23cbdc) {
                    return _0x14fa51(_0x23cbdc);
                },
                'FZPfk': _0x17be02(0x5e2),
                'yIbzG': function (_0xb5fe8f, _0x5752eb) {
                    return _0xb5fe8f(_0x5752eb);
                },
                'TjZaU': function (_0x44b045, _0x5e4d29) {
                    return _0x44b045 && _0x5e4d29;
                },
                'NjEpP': function (_0x5bdd9c, _0x290516, _0x41a2ca, _0x2419f4) {
                    return _0x5bdd9c(_0x290516, _0x41a2ca, _0x2419f4);
                },
                'LwfGC': function (_0x42da2c) {
                    return _0x42da2c();
                },
                'xsJAL': function (_0x348a8a) {
                    return _0x348a8a();
                },
                'StWAP': function (_0x53ead0) {
                    return _0x53ead0();
                },
                'GtoXm': function (_0x3ed769, _0x2ce83d) {
                    return _0x3ed769 == _0x2ce83d;
                },
                'hjKuA': function (_0x1f2f39) {
                    return _0x1f2f39();
                },
                'cARbA': function (_0x28db75, _0x251f9d) {
                    return _0x28db75(_0x251f9d);
                },
                'mTVFE': function (_0x212558, _0x5ea047, _0x58c9e6) {
                    return _0x212558(_0x5ea047, _0x58c9e6);
                },
                'Sgtfi': function (_0x31fc0a, _0x394aca, _0x337d75, _0x5a0f68) {
                    return _0x31fc0a(_0x394aca, _0x337d75, _0x5a0f68);
                },
                'bCGYu': _0x17be02(0x17f),
                'ggRNd': function (_0x4e9e70, _0x3edc47, _0x3d75f1, _0x2340e3) {
                    return _0x4e9e70(_0x3edc47, _0x3d75f1, _0x2340e3);
                },
                'UodVr': function (_0x40ddd9, _0x5f167a, _0x4a26e0) {
                    return _0x40ddd9(_0x5f167a, _0x4a26e0);
                },
                'UMYwh': function (_0x705931) {
                    return _0x705931();
                },
                'avFJs': _0x17be02(0x384),
                'RRtZv': function (_0x5efd2c, _0x4fdc54) {
                    return _0x5efd2c(_0x4fdc54);
                },
                'VnzoA': _0x17be02(0x268),
                'tqyJR': 'none\x20!important',
                'TiAnN': 'BODY',
                'kNRjd': _0x17be02(0x3b0),
                'EymDq': 'SPAN',
                'VFMzU': function (_0x42e4e2, _0x156973, _0x3e5ee0) {
                    return _0x42e4e2(_0x156973, _0x3e5ee0);
                },
                'mfRcx': _0x17be02(0x20a),
                'HoSma': _0x17be02(0x601),
                'cnRlh': 'color',
                'ocPmf': _0x17be02(0x6b7)
            };
        if (!_0x2f2c8c)
            return;
        if ([
                0x3,
                0x8
            ][_0x17be02(0x205)](_0x2f2c8c[_0x17be02(0x47e)]) || ignoredElements[_0x17be02(0x205)](_0x2f2c8c[_0x17be02(0x25a)]['toUpperCase']()))
            return;
        if (_0xc922f0[_0x17be02(0x1b9)](isElementBlacklisted, _0x2f2c8c))
            return processElement(_0x2f2c8c['nextSibling'], _0x50e4a5);
        if (_0x50e4a5) {
            if (_0x2f2c8c[_0x17be02(0x488)][_0x17be02(0x65c)](_0xc922f0[_0x17be02(0x390)]))
                return;
            _0x2f2c8c[_0x17be02(0x266)] && Array[_0x17be02(0x22d)](_0x2f2c8c[_0x17be02(0x266)][_0x17be02(0x174)])['filter'](_0x34af40 => _0x34af40[_0x17be02(0x25a)] != _0x17be02(0x374))[_0x17be02(0x618)](_0x5203a4 => processElement(_0x5203a4, _0x50e4a5));
            var _0x5499dd = _0xc922f0[_0x17be02(0x381)](getComputedStyle, _0x2f2c8c), _0x3f4c2e = NFColorFromRGBString(_0x5499dd[_0x17be02(0x24f)]), _0x1c47d5 = _0xc922f0['yIbzG'](NFColorFromRGBString, _0x5499dd[_0x17be02(0x685)]), _0x5c258f, _0x41a86c;
            if (_0xc922f0[_0x17be02(0x2fd)](_0x3f4c2e, _0x1c47d5)) {
                if (!WEBPAGE_COLORS[_0x17be02(0x3f6)][_0x17be02(0x5c2)](_0x3f4c2e[_0x17be02(0x50e)]())) {
                    if (_0x3f4c2e['isTransparent']())
                        _0xc922f0[_0x17be02(0x489)](setNewColor, 'bg', _0x3f4c2e, _0xc922f0[_0x17be02(0x62e)](TransparentColor));
                    else {
                        if (_0x3f4c2e[_0x17be02(0x314)]()) {
                            var _0x413e57 = _0x3f4c2e[_0x17be02(0x6ce)](-0x14);
                            if (_0xc922f0[_0x17be02(0x381)](isBlack, _0x413e57))
                                _0x413e57 = _0xc922f0[_0x17be02(0x45d)](getPageColor);
                            setNewColor('bg', _0x3f4c2e, _0x413e57);
                        } else {
                            if (_0x3f4c2e['isLight']()) {
                                var _0x413e57 = _0x3f4c2e[_0x17be02(0x452)]()[_0x17be02(0x640)]();
                                if (isBlack(_0x413e57))
                                    _0x413e57 = _0xc922f0[_0x17be02(0x6cf)](getPageColor);
                                _0xc922f0[_0x17be02(0x489)](setNewColor, 'bg', _0x3f4c2e, _0x413e57);
                            } else {
                                var _0x413e57 = _0x3f4c2e[_0x17be02(0x6ce)](-0x32);
                                if (_0xc922f0[_0x17be02(0x381)](isBlack, _0x413e57))
                                    _0x413e57 = _0xc922f0[_0x17be02(0x6cf)](getPageColor);
                                setNewColor('bg', _0x3f4c2e, _0x413e57);
                            }
                        }
                    }
                }
                _0xc922f0['GtoXm'](_0x3f4c2e[_0x17be02(0x50e)](), getPageSubColor()[_0x17be02(0x50e)]()) || _0xc922f0[_0x17be02(0x2e8)](_0x3f4c2e['rgbString'](), _0xc922f0[_0x17be02(0x17b)](getPageColor)[_0x17be02(0x50e)]()) ? _0x5c258f = _0x3f4c2e : _0x5c258f = _0xc922f0['cARbA'](NFColorFromRGBString, _0xc922f0[_0x17be02(0x56f)](getNewColor, 'bg', _0x3f4c2e[_0x17be02(0x50e)]()));
                if (!WEBPAGE_COLORS[_0x17be02(0x4fe)]['has'](_0x1c47d5[_0x17be02(0x50e)]())) {
                    if (_0x1c47d5[_0x17be02(0x501)]())
                        _0xc922f0[_0x17be02(0x1fb)](setNewColor, _0xc922f0['bCGYu'], _0x1c47d5, _0xc922f0[_0x17be02(0x17b)](TransparentColor));
                    else
                        _0x1c47d5[_0x17be02(0x314)]() ? !_0x1c47d5[_0x17be02(0x43c)]() ? _0xc922f0['ggRNd'](setNewColor, _0xc922f0[_0x17be02(0x288)], _0x1c47d5, _0x1c47d5['shade'](0x32)) : _0xc922f0[_0x17be02(0x282)](setNewColor, _0x17be02(0x17f), _0x1c47d5, _0x1c47d5) : !_0x1c47d5[_0x17be02(0x43c)]() ? _0xc922f0[_0x17be02(0x282)](setNewColor, 'text', _0x1c47d5, _0x1c47d5[_0x17be02(0x452)]()[_0x17be02(0x640)]()) : _0xc922f0[_0x17be02(0x282)](setNewColor, _0xc922f0[_0x17be02(0x288)], _0x1c47d5, _0x1c47d5);
                }
                _0x41a86c = _0xc922f0['cARbA'](NFColorFromRGBString, _0xc922f0[_0x17be02(0x52f)](getNewColor, _0xc922f0[_0x17be02(0x288)], _0x1c47d5['rgbString']()));
                if (!_0x5c258f)
                    _0x5c258f = _0xc922f0['hjKuA'](getPageColor);
                if (!_0x41a86c)
                    _0x41a86c = _0xc922f0[_0x17be02(0x4f5)](GrayColor);
                let _0x447f24 = _0x3f4c2e[_0x17be02(0x501)]() && _0x5499dd['background'][_0x17be02(0x205)](_0x17be02(0x268)), _0x420a97 = [
                        _0xc922f0[_0x17be02(0x156)],
                        _0x17be02(0x1ef)
                    ];
                for (let _0x2d9b8c of _0x420a97) {
                    let _0x43e9a8 = getComputedStyle(_0x2f2c8c, _0x2d9b8c), _0x38580c = _0xc922f0['RRtZv'](NFColorFromRGBString, _0x43e9a8[_0x17be02(0x24f)]), _0x43b82a;
                    if (_0x38580c[_0x17be02(0x43c)]())
                        _0x43b82a = { 'background-color': _0xc922f0[_0x17be02(0x4f5)](getPageColor)[_0x17be02(0x50e)]() + _0x17be02(0x61f) };
                    else
                        _0x43e9a8[_0x17be02(0x40c)][_0x17be02(0x205)](_0xc922f0['VnzoA']) && (_0x43b82a = {
                            'background': _0x17be02(0x515),
                            'background-image': _0xc922f0[_0x17be02(0x1a8)]
                        });
                    let _0x5e716d = _0x2f2c8c['id'][_0x17be02(0x362)] || _0x2f2c8c[_0x17be02(0x1c1)][_0x17be02(0x362)];
                    if (_0x43b82a && _0x5e716d)
                        _0xc922f0[_0x17be02(0x282)](addStyleForPseudoElement, _0x2f2c8c, _0x2d9b8c, _0x43b82a);
                }
                switch (_0x2f2c8c[_0x17be02(0x25a)]) {
                case _0xc922f0[_0x17be02(0x287)]:
                    applyColorChange(_0x2f2c8c, {
                        'backgroundColor': _0x5c258f,
                        'textColor': _0x41a86c,
                        'borderColor': darkBorderColorIfNeeded(_0x5499dd)
                    });
                    break;
                case 'CANVAS':
                    _0x2f2c8c[_0x17be02(0x164)]['removeChild'](_0x2f2c8c);
                    break;
                case _0xc922f0[_0x17be02(0x4f6)]:
                case _0xc922f0['EymDq']:
                    var _0x992616 = {
                        'backgroundColor': _0x5c258f,
                        'textColor': _0x5c258f ? !_0x5c258f[_0x17be02(0x43c)]() ? _0x41a86c : null : _0x41a86c,
                        'borderColor': _0xc922f0[_0x17be02(0x201)](darkBorderColorIfNeeded, _0x5499dd),
                        'background': _0x447f24 ? 'none' : null
                    };
                    _0xc922f0[_0x17be02(0x2ae)](applyColorChange, _0x2f2c8c, _0x992616);
                    break;
                default:
                    _0xc922f0[_0x17be02(0x2ae)](applyColorChange, _0x2f2c8c, {
                        'backgroundColor': _0x5c258f,
                        'textColor': _0x41a86c,
                        'borderColor': darkBorderColorIfNeeded(_0x5499dd),
                        'background': _0x447f24 ? _0xc922f0[_0x17be02(0x6cc)] : null
                    });
                    break;
                }
            }
        } else {
            _0x2f2c8c[_0x17be02(0x488)][_0x17be02(0x26c)](_0xc922f0['FZPfk']);
            switch (_0x2f2c8c['tagName']) {
            default:
                _0x2f2c8c[_0x17be02(0x39b)][_0x17be02(0x479)](_0xc922f0[_0x17be02(0x1ba)]), _0x2f2c8c['style'][_0x17be02(0x479)](_0xc922f0[_0x17be02(0x359)]), _0x2f2c8c[_0x17be02(0x39b)][_0x17be02(0x479)](_0xc922f0[_0x17be02(0x439)]);
            }
        }
        _0x2f2c8c = _0x2f2c8c['firstChild'];
        while (_0x2f2c8c) {
            _0xc922f0[_0x17be02(0x2ae)](processElement, _0x2f2c8c, _0x50e4a5), _0x2f2c8c = _0x2f2c8c[_0x17be02(0x28a)];
        }
    }, selectorForElement = _0x379f75 => {
        var _0xfef956 = _0x52102f, _0x545f75 = {
                'NyiTo': function (_0x28594e, _0x4fabaf) {
                    return _0x28594e != _0x4fabaf;
                },
                'MMJDH': function (_0xb5624c, _0x2aa971) {
                    return _0xb5624c === _0x2aa971;
                },
                'AdpKd': _0xfef956(0x295),
                'yWMnF': function (_0x396887, _0x2ea888) {
                    return _0x396887 < _0x2ea888;
                },
                'TwOZM': function (_0x6bb091, _0x4a89e9) {
                    return _0x6bb091 + _0x4a89e9;
                },
                'kxhYU': function (_0x13b333, _0x3f8a96) {
                    return _0x13b333 + _0x3f8a96;
                }
            };
        let _0x2c4b21;
        if (_0x379f75['id'])
            _0x2c4b21 = '#' + _0x379f75['id'];
        else {
            if (_0x379f75[_0xfef956(0x1c1)]) {
                for (var _0x192b0c = '', _0xd94e42 = _0x379f75; _0x545f75[_0xfef956(0x5dc)](null, _0xd94e42);)
                    if (_0xd94e42['className']) {
                        var _0x18590e = '';
                        if (_0x545f75[_0xfef956(0x2a7)](_0x545f75[_0xfef956(0x643)], _0xd94e42[_0xfef956(0x25a)]))
                            _0x18590e = _0xd94e42[_0xfef956(0x1c1)]['baseVal'];
                        else {
                            for (var _0x43d5a0 = 0x0; _0x545f75[_0xfef956(0x229)](_0x43d5a0, _0xd94e42[_0xfef956(0x488)][_0xfef956(0x362)]); ++_0x43d5a0)
                                _0x18590e += _0x545f75['TwOZM']('.', _0xd94e42[_0xfef956(0x488)][_0x43d5a0]);
                        }
                        _0x192b0c = _0x545f75[_0xfef956(0x2a7)]('', _0x192b0c) ? _0x18590e : _0x545f75[_0xfef956(0x279)](_0x545f75['kxhYU'](_0x18590e, '\x20'), _0x192b0c), _0xd94e42 = _0xd94e42[_0xfef956(0x164)];
                    } else
                        _0x545f75[_0xfef956(0x2a7)]('', _0x192b0c) && (_0x192b0c = _0xd94e42['tagNam']), _0xd94e42 = _0xd94e42[_0xfef956(0x164)];
                _0x2c4b21 = _0x192b0c;
            } else
                _0x2c4b21 = _0x379f75[_0xfef956(0x5c0)];
        }
        return _0x2c4b21;
    }, addStyleForPseudoElement = (_0x3ccb25, _0x401fc3, _0x7ff8ca) => {
        var _0x54ec8c = _0x52102f, _0x58c3e7 = {
                'glERQ': function (_0x544a83, _0xfdb6d4) {
                    return _0x544a83(_0xfdb6d4);
                },
                'qczrf': function (_0x1e7753, _0x5570d1, _0x59f0dc) {
                    return _0x1e7753(_0x5570d1, _0x59f0dc);
                }
            };
        let _0x1ca6ea = _0x58c3e7['glERQ'](selectorForElement, _0x3ccb25);
        if (!_0x1ca6ea)
            return;
        _0x1ca6ea = _0x1ca6ea['replaceAll'](_0x54ec8c(0x4d7), ''), _0x1ca6ea = '' + _0x1ca6ea + _0x401fc3, _0x58c3e7[_0x54ec8c(0x214)](addCSSRule, _0x1ca6ea, _0x7ff8ca);
    }, addCSSRule = (_0x395888, _0x375643) => {
        var _0xa26037 = _0x52102f, _0x283624 = {
                'lCFwW': function (_0x28e2c6, _0x38027f) {
                    return _0x28e2c6 + _0x38027f;
                },
                'uIMud': _0xa26037(0x509),
                'CKopo': _0xa26037(0x39b),
                'aBMtM': function (_0x50ba35, _0x3d7101) {
                    return _0x50ba35 == _0x3d7101;
                }
            };
        let _0xa296a7 = _0x283624[_0xa26037(0x33d)];
        var _0x1ddd27 = document[_0xa26037(0x6a3)](_0xa296a7);
        !_0x1ddd27 && (_0x1ddd27 = document[_0xa26037(0x4f1)](_0x283624[_0xa26037(0x190)]), _0x1ddd27['id'] = _0xa296a7, document['head'][_0xa26037(0x437)](_0x1ddd27));
        var _0x2eca04 = _0x1ddd27[_0xa26037(0x605)];
        for (rule of _0x2eca04[_0xa26037(0x3d5)]) {
            if (_0x283624[_0xa26037(0x352)](rule['selectorText'][_0xa26037(0x468)]('::', ':'), _0x395888))
                return;
        }
        let _0x41695a = Object[_0xa26037(0x630)](_0x375643)['map'](_0x564f0b => {
            var _0x3101a2 = _0xa26037;
            return _0x283624[_0x3101a2(0x621)](_0x283624[_0x3101a2(0x621)](_0x564f0b, ':'), _0x375643[_0x564f0b]);
        })[_0xa26037(0x265)](';');
        try {
            _0x2eca04[_0xa26037(0x5b5)](_0x283624[_0xa26037(0x621)](_0x283624['lCFwW'](_0x395888, '{') + _0x41695a, '}'), _0x2eca04[_0xa26037(0x63d)][_0xa26037(0x362)]);
        } catch (_0x36b0dd) {
            console[_0xa26037(0x674)](_0x36b0dd);
        }
    }, darkBorderColorIfNeeded = _0x46fecc => {
        var _0x2941ac = _0x52102f, _0x4233ac = {
                'MwJRS': _0x2941ac(0x606),
                'mrNqJ': _0x2941ac(0x50a),
                'wnPGt': function (_0x578703, _0x11c780) {
                    return _0x578703 < _0x11c780;
                },
                'kvRQH': function (_0x5c436f, _0x108609) {
                    return _0x5c436f + _0x108609;
                },
                'zvJfA': function (_0x406e4f, _0x3297fc) {
                    return _0x406e4f + _0x3297fc;
                },
                'wwNZU': _0x2941ac(0x25e),
                'AnDjS': _0x2941ac(0x1ca),
                'GLwBd': function (_0x3006f2, _0x23d3b7) {
                    return _0x3006f2 > _0x23d3b7;
                },
                'LpoPz': function (_0xbbfd78, _0x4dc71d) {
                    return _0xbbfd78 + _0x4dc71d;
                },
                'NIPgZ': _0x2941ac(0x2de),
                'cSpZU': function (_0x59f547, _0x197b9b) {
                    return _0x59f547(_0x197b9b);
                },
                'YgvsE': function (_0x35e646) {
                    return _0x35e646();
                }
            };
        let _0x52fe14 = ![], _0x30b3c0 = [
                _0x2941ac(0x34d),
                _0x2941ac(0x35a),
                _0x4233ac[_0x2941ac(0x6b9)],
                _0x4233ac[_0x2941ac(0x36e)]
            ];
        for (var _0x3fc9c9 = 0x0, _0x2a0841 = _0x30b3c0['length']; _0x4233ac[_0x2941ac(0x3ca)](_0x3fc9c9, _0x2a0841); _0x3fc9c9++) {
            let _0x58d056 = Math[_0x2941ac(0x24d)](0x0, parseInt(_0x46fecc[_0x2941ac(0x225)](_0x4233ac['kvRQH'](_0x4233ac[_0x2941ac(0x242)](_0x4233ac['wwNZU'], _0x30b3c0[_0x3fc9c9]), _0x4233ac[_0x2941ac(0x2db)]))));
            if (_0x4233ac[_0x2941ac(0x291)](_0x58d056, 0x0)) {
                let _0x1dcc52 = _0x46fecc['getPropertyValue'](_0x4233ac[_0x2941ac(0x333)](_0x4233ac['LpoPz'](_0x4233ac[_0x2941ac(0x4d4)], _0x30b3c0[_0x3fc9c9]), _0x4233ac[_0x2941ac(0x522)]));
                if (_0x1dcc52) {
                    if (_0x4233ac[_0x2941ac(0x188)](NFColorFromRGBString, _0x1dcc52)[_0x2941ac(0x43c)]()) {
                        _0x52fe14 = !![];
                        break;
                    }
                }
            }
        }
        if (_0x52fe14)
            return _0x4233ac[_0x2941ac(0x173)](getPageSubColor);
        return null;
    }, isElementBlacklisted = _0x555be5 => {
        var _0x3615b2 = _0x52102f, _0xe9f22f = {
                'ZAAgM': function (_0x2150fe, _0x477e6a) {
                    return _0x2150fe != _0x477e6a;
                }
            };
        for (var _0x6845e of ignoredBackgroundSelectors) {
            let _0x5a488c = _0xe9f22f[_0x3615b2(0x37d)](_0x555be5[_0x3615b2(0x4b7)](_0x6845e), null);
            if (_0x555be5[_0x3615b2(0x6da)](_0x6845e) || _0x5a488c)
                return !![];
        }
        return ![];
    }, applyColorChange = (_0x540de7, _0x5e2c5d) => {
        var _0x3d490a = _0x52102f, _0x53cb32 = {
                'uQduw': function (_0x3967e0, _0x122c72, _0x5352f2) {
                    return _0x3967e0(_0x122c72, _0x5352f2);
                },
                'HXcHm': function (_0x15551f, _0x19119d, _0x37edb7) {
                    return _0x15551f(_0x19119d, _0x37edb7);
                }
            };
        if (_0x5e2c5d['textColor'])
            _0x53cb32[_0x3d490a(0x2a5)](applyTextColor, _0x540de7, _0x5e2c5d[_0x3d490a(0x680)]);
        if (_0x5e2c5d['borderColor'])
            applyBorderColor(_0x540de7, _0x5e2c5d[_0x3d490a(0x69f)]);
        if (_0x5e2c5d[_0x3d490a(0x40c)])
            _0x53cb32[_0x3d490a(0x478)](applyBackground, _0x540de7, _0x5e2c5d['background']);
        if (_0x5e2c5d[_0x3d490a(0x24f)])
            _0x53cb32[_0x3d490a(0x478)](applyBackgroundColor, _0x540de7, _0x5e2c5d[_0x3d490a(0x24f)]);
    }, applyBorderColor = (_0x304668, _0x3ab4aa) => {
        var _0x5583d3 = _0x52102f, _0x40cce5 = {
                'OpZGY': _0x5583d3(0x6b7),
                'LuMPI': _0x5583d3(0x22f),
                'uXvuq': 'nitefall_processed'
            };
        _0x304668[_0x5583d3(0x39b)]['setProperty'](_0x40cce5[_0x5583d3(0x50c)], _0x3ab4aa['rgbString'](), _0x40cce5[_0x5583d3(0x5c8)]), _0x304668[_0x5583d3(0x488)][_0x5583d3(0x4c3)](_0x40cce5[_0x5583d3(0x498)]);
    }, applyTextColor = (_0x4bf2dc, _0xb5258) => {
        var _0x2ebe02 = _0x52102f, _0xdce4eb = {
                'QDGiy': _0x2ebe02(0x685),
                'vYbvu': _0x2ebe02(0x22f)
            };
        _0x4bf2dc[_0x2ebe02(0x39b)][_0x2ebe02(0x6c4)](_0xdce4eb[_0x2ebe02(0x60a)], _0xb5258[_0x2ebe02(0x50e)](), _0xdce4eb[_0x2ebe02(0x4a1)]), _0x4bf2dc['classList'][_0x2ebe02(0x4c3)](_0x2ebe02(0x5e2));
    }, applyBackground = (_0x45c0f9, _0xa4ad6c) => {
        var _0x2e8a68 = _0x52102f, _0x24841e = {
                'oBLVR': _0x2e8a68(0x40c),
                'DWcrR': 'important'
            };
        _0x45c0f9[_0x2e8a68(0x39b)]['setProperty'](_0x24841e[_0x2e8a68(0x36d)], _0xa4ad6c, _0x24841e[_0x2e8a68(0x3f2)]), _0x45c0f9[_0x2e8a68(0x488)][_0x2e8a68(0x4c3)]('nitefall_processed');
    }, applyBackgroundColor = (_0x46b253, _0x5a1966) => {
        var _0x1b4d51 = _0x52102f, _0x235dc0 = {
                'iAYwd': function (_0xd01833, _0x32407e) {
                    return _0xd01833 != _0x32407e;
                },
                'GlEgu': 'data-target',
                'PXAjV': _0x1b4d51(0x3bd),
                'NYWsV': _0x1b4d51(0x601),
                'RcXZc': _0x1b4d51(0x22f)
            };
        _0x235dc0[_0x1b4d51(0x264)](_0x46b253[_0x1b4d51(0x5fb)](_0x235dc0['GlEgu']), _0x235dc0[_0x1b4d51(0x18a)]) && (_0x46b253[_0x1b4d51(0x39b)][_0x1b4d51(0x6c4)](_0x235dc0['NYWsV'], _0x5a1966['rgbString'](), _0x235dc0[_0x1b4d51(0x3fb)]), _0x46b253['classList']['add'](_0x1b4d51(0x5e2)));
    }, handleMutations = _0x1052c7 => {
        var _0x2bc2fe = _0x52102f, _0x121115 = {
                'SyKEd': function (_0x4d856c) {
                    return _0x4d856c();
                },
                'AUQTR': function (_0xd6aa37, _0x1fb5e6) {
                    return _0xd6aa37 != _0x1fb5e6;
                },
                'Msyaa': function (_0xa46455, _0x533b37, _0x28a42e) {
                    return _0xa46455(_0x533b37, _0x28a42e);
                },
                'rPHCv': function (_0x1de246, _0x25adcf) {
                    return _0x1de246(_0x25adcf);
                }
            };
        _0x1052c7[_0x2bc2fe(0x618)](_0x40eab2 => {
            var _0x1aa23b = _0x2bc2fe;
            _0x40eab2['addedNodes'][_0x1aa23b(0x618)](_0x4e3f69 => {
                var _0x2035c7 = _0x1aa23b, _0x408aef = {
                        'ymXJP': function (_0xbd265e) {
                            var _0x1e28b7 = _0x3451;
                            return _0x121115[_0x1e28b7(0x4e0)](_0xbd265e);
                        },
                        'StBDZ': function (_0x5179bf, _0x567db3) {
                            var _0x5a4afc = _0x3451;
                            return _0x121115[_0x5a4afc(0x66b)](_0x5179bf, _0x567db3);
                        },
                        'jUwlu': _0x2035c7(0x2c6),
                        'BbivA': function (_0x448ec0, _0x1fd61f, _0x5400ab) {
                            var _0x12fa2e = _0x2035c7;
                            return _0x121115[_0x12fa2e(0x54d)](_0x448ec0, _0x1fd61f, _0x5400ab);
                        },
                        'MQpOB': function (_0x1f9288, _0x53a3f3) {
                            return _0x121115['rPHCv'](_0x1f9288, _0x53a3f3);
                        }
                    };
                _0x121115['rPHCv'](queueMicrotask, () => {
                    var _0x2c84a2 = _0x2035c7;
                    if (_0x408aef[_0x2c84a2(0x3ef)](isSystemDarkModeOn)) {
                        var _0xc606d3 = _0x408aef[_0x2c84a2(0x5e9)](document[_0x2c84a2(0x286)]['getAttribute'](_0x2c84a2(0x3da)), null);
                        if (_0xc606d3) {
                            var _0x286e91 = _0x4e3f69[_0x2c84a2(0x488)] ? _0x4e3f69[_0x2c84a2(0x488)][_0x2c84a2(0x65c)](_0x408aef[_0x2c84a2(0x44f)]) : ![];
                            !_0x286e91 && (console['log'](_0x2c84a2(0x55e), _0x4e3f69['tagName'], _0x4e3f69['classList']), _0x408aef[_0x2c84a2(0x43a)](processElement, _0x4e3f69, !![]), _0x408aef['MQpOB'](findAndTagSvgs, _0x4e3f69));
                        }
                    }
                });
            });
        });
    }, addCustomDarkCss = () => {
        var _0x147003 = _0x52102f, _0x15efea = {
                'aIDYt': 'nitefall',
                'Cdtrn': _0x147003(0x5cd),
                'sEarP': 'style',
                'UrMiN': function (_0x2e0b1f, _0x408462) {
                    return _0x2e0b1f(_0x408462);
                },
                'FlSwa': function (_0x3cc630) {
                    return _0x3cc630();
                },
                'KbbBb': _0x147003(0x44a),
                'EwfJP': _0x147003(0x6a6),
                'zpKEi': function (_0x2306d6, _0xe84063) {
                    return _0x2306d6 == _0xe84063;
                },
                'DvTUy': _0x147003(0x280),
                'sCiof': _0x147003(0x2b4),
                'ZSMXE': function (_0x368444, _0x39ac19, _0x19fd8c) {
                    return _0x368444(_0x39ac19, _0x19fd8c);
                }
            };
        if (document[_0x147003(0x6a3)](NITEFALL_CUSTOM_CSS_ID))
            return;
        var _0x1715ca = document[_0x147003(0x4f1)](_0x15efea[_0x147003(0x64f)]), _0x183d21 = _0x15efea[_0x147003(0x5fc)](getCustomCss, _0x15efea[_0x147003(0x657)](getHost));
        _0x183d21 = _0x183d21['replaceAll'](_0x15efea['KbbBb'], _0x15efea[_0x147003(0x657)](getPageColor)['rgbString']()), _0x183d21 = _0x183d21[_0x147003(0x5f0)](_0x15efea['EwfJP'], _0x15efea[_0x147003(0x657)](getPageSubColor)[_0x147003(0x50e)]()), _0x1715ca[_0x147003(0x217)] = _0x183d21, _0x1715ca[_0x147003(0x4b8)]('id', NITEFALL_CUSTOM_CSS_ID);
        if (_0x15efea['zpKEi'](document[_0x147003(0x269)][_0x147003(0x378)], _0x15efea[_0x147003(0x346)])) {
            let _0x2e398e = /mobile|phone/i[_0x147003(0x316)](navigator[_0x147003(0x411)]);
            _0x2e398e && (_0x1715ca[_0x147003(0x4b8)](_0x15efea[_0x147003(0x19e)], null), _0x15efea['ZSMXE'](setTimeout, () => {
                var _0x259590 = _0x147003;
                document[_0x259590(0x286)][_0x259590(0x4b8)](_0x15efea[_0x259590(0x613)], _0x15efea[_0x259590(0x4f7)]);
            }, 0x514));
        }
        if (document[_0x147003(0x600)])
            document[_0x147003(0x600)][_0x147003(0x437)](_0x1715ca);
        else
            document[_0x147003(0x286)][_0x147003(0x437)](_0x1715ca);
    }, removeStyleWithId = _0x281507 => {
        var _0x2293b3 = _0x52102f, _0x73b275 = document[_0x2293b3(0x6a3)](_0x281507);
        _0x73b275 && _0x73b275[_0x2293b3(0x164)]['removeChild'](_0x73b275);
    }, removeDarkCss = () => {
        var _0x5c8568 = _0x52102f, _0x209f11 = {
                'OAAIh': _0x5c8568(0x5fe),
                'wrDZO': function (_0x1f8a24, _0x94bb2c) {
                    return _0x1f8a24(_0x94bb2c);
                },
                'ATWGH': function (_0xb7439d, _0x53fac7, _0x1b7a75) {
                    return _0xb7439d(_0x53fac7, _0x1b7a75);
                },
                'VFOjI': function (_0x524f37) {
                    return _0x524f37();
                },
                'CCifm': _0x5c8568(0x509),
                'UoaPq': function (_0x159307, _0x5ce511) {
                    return _0x159307 == _0x5ce511;
                },
                'zJJLp': _0x5c8568(0x1f1),
                'ngjWr': _0x5c8568(0x60e)
            };
        console['log'](_0x209f11[_0x5c8568(0x396)]), document[_0x5c8568(0x286)]['removeAttribute'](_0x5c8568(0x3da)), _0x209f11[_0x5c8568(0x593)](removeStyleWithId, NITEFALL_CUSTOM_CSS_ID), _0x209f11['ATWGH'](processElement, document[_0x5c8568(0x51e)], ![]), _0x209f11[_0x5c8568(0x6a5)](removeStartWorkAround), removeStyleWithId(_0x5c8568(0x5d7)), _0x209f11[_0x5c8568(0x593)](removeStyleWithId, _0x209f11['CCifm']);
        if (_0x209f11[_0x5c8568(0x565)](window, window[_0x5c8568(0x34d)])) {
            var _0x28f6d2 = document[_0x5c8568(0x15e)](_0x209f11['zJJLp']);
            for (var _0x1ee9ff of _0x28f6d2) {
                _0x1ee9ff[_0x5c8568(0x4e6)][_0x5c8568(0x1a7)](_0x209f11['ngjWr'], '*');
            }
        }
    }, findAndTagSvgs = _0x53d34b => {
        var _0x4a073d = _0x52102f, _0x53d742 = {
                'PZbJB': _0x4a073d(0x304),
                'cLFWK': _0x4a073d(0x54a),
                'qELPn': _0x4a073d(0x360),
                'BNVhA': _0x4a073d(0x1ab)
            }, _0x185cb6 = _0x53d742[_0x4a073d(0x3c8)][_0x4a073d(0x523)]('|'), _0x572e29 = 0x0;
        while (!![]) {
            switch (_0x185cb6[_0x572e29++]) {
            case '0':
                if (!_0x53d34b[_0x4a073d(0x27c)])
                    return;
                continue;
            case '1':
                _0x53d34b[_0x4a073d(0x27c)](_0x53d742[_0x4a073d(0x560)])[_0x4a073d(0x618)](_0x9add98 => classifySVGAsDark(_0x9add98, _0x9add98[_0x4a073d(0x383)]));
                continue;
            case '2':
                Array['prototype']['forEach'][_0x4a073d(0x649)](_0x53d34b['querySelectorAll'](_0x53d742[_0x4a073d(0x2ef)]), detectElementWithBackgroundImages);
                continue;
            case '3':
                _0x53d34b['querySelectorAll'](_0x4a073d(0x295))['forEach'](_0x47b030 => classifySVGAsDark(_0x47b030, _0x47b030[_0x4a073d(0x493)]));
                continue;
            case '4':
                _0x53d34b[_0x4a073d(0x27c)](_0x53d742['BNVhA'])[_0x4a073d(0x618)](_0x3ba8e7 => classifySVGAsDark(_0x3ba8e7, _0x3ba8e7['src']));
                continue;
            }
            break;
        }
    }, removeAllCss = () => {
        var _0x1fe778 = _0x52102f, _0x19108f = {
                'nyBfl': _0x1fe778(0x61d),
                'mMeiN': function (_0x5f38cf) {
                    return _0x5f38cf();
                }
            }, _0x30b1d6 = _0x19108f[_0x1fe778(0x2e5)]['split']('|'), _0x3002d9 = 0x0;
        while (!![]) {
            switch (_0x30b1d6[_0x3002d9++]) {
            case '0':
                _0x19108f[_0x1fe778(0x426)](removeInvertedPngStyle);
                continue;
            case '1':
                removeStyleWithId(_0x1fe778(0x251));
                continue;
            case '2':
                _0x19108f['mMeiN'](removeDarkMapCss);
                continue;
            case '3':
                if (mutationObserver)
                    mutationObserver['disconnect']();
                continue;
            case '4':
                _0x19108f['mMeiN'](removeStartWorkAround);
                continue;
            case '5':
                removeDarkCss();
                continue;
            }
            break;
        }
    }, isEmailInDarkMode = () => {
        var _0x5a366f = _0x52102f, _0x44cc4c = {
                'QKETv': _0x5a366f(0x210),
                'zlern': _0x5a366f(0x642),
                'MpOty': 'img',
                'chiEQ': function (_0x4b630c, _0x21c383) {
                    return _0x4b630c < _0x21c383;
                },
                'lOTWm': function (_0x164473, _0x2624b7) {
                    return _0x164473 > _0x2624b7;
                },
                'brDia': _0x5a366f(0x1d9),
                'LeiEG': function (_0x127aaa, _0x282b9f) {
                    return _0x127aaa !== _0x282b9f;
                },
                'AclAz': _0x5a366f(0x20a),
                'ursOh': _0x5a366f(0x433),
                'VtGWG': function (_0x3087d7, _0x4a9fa4) {
                    return _0x3087d7 == _0x4a9fa4;
                }
            }, _0x57f5e5 = ![], _0xe96b2f = !![], _0x3adb35 = maillApp_declaredColorSchemes();
        if (_0x3adb35)
            _0xe96b2f = ![], (_0x3adb35[_0x5a366f(0x205)](_0x44cc4c[_0x5a366f(0x47b)]) || _0x3adb35[_0x5a366f(0x205)]('only')) && !_0x3adb35[_0x5a366f(0x205)](_0x44cc4c[_0x5a366f(0x55f)]) && (_0x57f5e5 = !![]);
        else {
            var _0x55b3bf = document['body'][_0x5a366f(0x27c)](_0x44cc4c['MpOty']);
            for (i = 0x0; _0x44cc4c[_0x5a366f(0x57e)](i, _0x55b3bf['length']); i++) {
                var _0x40689a = _0x55b3bf[i];
                if (_0x40689a[_0x5a366f(0x383)]['startsWith'](_0x5a366f(0x512)) && (_0x40689a[_0x5a366f(0x6ca)] > 0x1 || _0x44cc4c[_0x5a366f(0x67c)](_0x40689a[_0x5a366f(0x6bc)], 0x1)) && !_0x40689a[_0x5a366f(0x1c1)][_0x5a366f(0x6b6)](_0x44cc4c[_0x5a366f(0x6b3)])) {
                    _0x57f5e5 = !![];
                    break;
                }
            }
            var _0x168cfc = window[_0x5a366f(0x527)](document[_0x5a366f(0x51e)]);
            _0x44cc4c['LeiEG'](_0x168cfc[_0x5a366f(0x525)], _0x44cc4c[_0x5a366f(0x694)]) && (_0x57f5e5 = !![]);
        }
        var _0xe8713b;
        if (_0x57f5e5)
            _0xe8713b = 'apple-mail-light-only';
        else
            _0xe96b2f && (_0xe8713b = _0x44cc4c['ursOh']);
        return _0x44cc4c[_0x5a366f(0x353)](_0xe8713b, _0x44cc4c['ursOh']);
    }, maillApp_declaredColorSchemes = () => {
        var _0x3083db = _0x52102f, _0x4660e8 = {
                'bJfiz': _0x3083db(0x399),
                'GYIOm': _0x3083db(0x35f),
                'ZcCeT': _0x3083db(0x20d),
                'uRbjx': _0x3083db(0x6d1)
            };
        document[_0x3083db(0x286)][_0x3083db(0x488)]['add'](_0x4660e8[_0x3083db(0x204)]);
        var _0x206715 = window[_0x3083db(0x527)](document['documentElement'])[_0x3083db(0x361)];
        if (_0x206715 && _0x206715 !== _0x4660e8['GYIOm']) {
            let _0x556635 = _0x206715[_0x3083db(0x523)](/\s+/);
            if (_0x556635 && _0x556635[_0x3083db(0x362)])
                return document['documentElement'][_0x3083db(0x488)][_0x3083db(0x26c)](_0x4660e8[_0x3083db(0x204)]), _0x556635;
        }
        document['documentElement'][_0x3083db(0x488)][_0x3083db(0x26c)](_0x4660e8[_0x3083db(0x204)]);
        var _0x44e483 = document[_0x3083db(0x27c)](_0x4660e8['ZcCeT']);
        if (!_0x44e483)
            _0x44e483 = document[_0x3083db(0x27c)](_0x4660e8['uRbjx']);
        var _0x409f08 = _0x44e483 ? _0x44e483[_0x44e483[_0x3083db(0x362)] - 0x1] : null;
        if (_0x409f08 && _0x409f08[_0x3083db(0x4de)]) {
            let _0x4307b7 = _0x409f08[_0x3083db(0x4de)][_0x3083db(0x3ec)]()[_0x3083db(0x523)](/\s+/);
            if (_0x4307b7 && _0x4307b7[_0x3083db(0x362)])
                return _0x4307b7;
        }
        return null;
    }, onPageLoadedForNitefall = () => {
        var _0x10e19f = _0x52102f, _0x23b60e = {
                'SsPNw': _0x10e19f(0x599),
                'IEBdF': function (_0xa3fd9d, _0x35f2a5, _0x51c5ba) {
                    return _0xa3fd9d(_0x35f2a5, _0x51c5ba);
                },
                'uioHG': function (_0x4f76b8) {
                    return _0x4f76b8();
                },
                'AWUZT': _0x10e19f(0x4c9),
                'SsLPA': function (_0xb1fdf, _0x2be4ca) {
                    return _0xb1fdf == _0x2be4ca;
                },
                'kuaXC': _0x10e19f(0x1cf),
                'UmenB': _0x10e19f(0x5e2),
                'DQVSs': function (_0x3f97c2, _0x16ab78) {
                    return _0x3f97c2 > _0x16ab78;
                },
                'ueSHI': _0x10e19f(0x551),
                'JqALC': _0x10e19f(0x3ac),
                'FIINM': function (_0x57fd1a, _0x5b467c) {
                    return _0x57fd1a(_0x5b467c);
                },
                'nOxnZ': function (_0x49286b) {
                    return _0x49286b();
                },
                'UaFgH': function (_0x49db6b, _0x253817) {
                    return _0x49db6b != _0x253817;
                },
                'oBHpr': _0x10e19f(0x3da),
                'HfFPU': _0x10e19f(0x5cd),
                'GtpyO': function (_0x239624) {
                    return _0x239624();
                },
                'oIiEU': function (_0x28803a) {
                    return _0x28803a();
                },
                'sunai': function (_0x27a12c, _0x334c9d) {
                    return _0x27a12c(_0x334c9d);
                }
            };
        if (!globalSettings)
            return;
        _0x23b60e[_0x10e19f(0x4e4)](removeStartWorkAround);
        if (!document[_0x10e19f(0x51e)])
            return;
        if (document[_0x10e19f(0x269)][_0x10e19f(0x191)]['includes'](_0x23b60e[_0x10e19f(0x5df)]) && isEmailInDarkMode())
            return;
        if (hasTrialExpired(globalSettings)) {
            let _0x49b8dd = _0x10e19f(0x5d7);
            if (!document[_0x10e19f(0x6a3)](_0x49b8dd) && _0x23b60e['SsLPA'](window, window[_0x10e19f(0x34d)])) {
                var _0x4ab482 = document[_0x10e19f(0x4f1)](_0x23b60e[_0x10e19f(0x6c7)]);
                _0x4ab482['id'] = _0x49b8dd, _0x4ab482[_0x10e19f(0x1c1)] = _0x23b60e['UmenB'];
                let _0x29bfa0 = _0x23b60e['DQVSs'](screen[_0x10e19f(0x6ca)], 0x1f4) ? _0x10e19f(0x4c8) : _0x23b60e['ueSHI'];
                _0x4ab482['style'] = _0x10e19f(0x319) + _0x29bfa0 + ';\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20', _0x4ab482[_0x10e19f(0x2e6)] = _0x23b60e[_0x10e19f(0x24e)], document[_0x10e19f(0x51e)][_0x10e19f(0x60f)](_0x4ab482, document[_0x10e19f(0x51e)][_0x10e19f(0x174)][0x0]);
            }
            return;
        }
        _0x23b60e[_0x10e19f(0x4a5)](findAndTagSvgs, document);
        let _0x268eea = globalSettings[_0x23b60e['nOxnZ'](getHost)];
        if (_0x268eea[_0x10e19f(0x494)] < 0x1)
            dimImages(_0x268eea[_0x10e19f(0x494)]);
        if (_0x268eea[_0x10e19f(0x30e)])
            invertPng();
        if (_0x268eea[_0x10e19f(0x1e5)]) {
            var _0x234b36 = !![];
            let _0x58f4aa = _0x23b60e[_0x10e19f(0x62b)](window['top'], window);
            if (_0x58f4aa) {
                let _0xab738e = _0x23b60e['UaFgH'](window[_0x10e19f(0x269)], window[_0x10e19f(0x1d6)][_0x10e19f(0x269)]) ? document[_0x10e19f(0x2b7)] : document[_0x10e19f(0x269)][_0x10e19f(0x191)];
                if (_0xab738e) {
                    let _0x53db24 = new URL(_0xab738e)['hostname'];
                    if (_0x53db24) {
                        let _0x3252e9 = globalSettings[_0x53db24];
                        _0x3252e9 && (_0x234b36 = _0x3252e9[_0x10e19f(0x1e5)]);
                    }
                }
            }
            _0x234b36 && (document[_0x10e19f(0x286)][_0x10e19f(0x4b8)](_0x23b60e[_0x10e19f(0x602)], _0x23b60e['HfFPU']), _0x23b60e['GtpyO'](addCustomDarkCss), _0x23b60e[_0x10e19f(0x58a)](setDarkToolbar), _0x23b60e['sunai'](queueMicrotask, () => {
                var _0x25aca7 = _0x10e19f;
                processElement(document['body'], !![]), mutationObserver = new MutationObserver(handleMutations), document['location']['host'] != _0x23b60e[_0x25aca7(0x67e)] && mutationObserver[_0x25aca7(0x449)](document[_0x25aca7(0x51e)], {
                    'childList': !![],
                    'subtree': !![]
                }), _0x23b60e[_0x25aca7(0x3eb)](iterateElementsWithShadowHost, document[_0x25aca7(0x286)], _0x4974f0 => {
                    var _0x3cf15d = _0x25aca7;
                    if (_0x4974f0 && _0x4974f0[_0x3cf15d(0x266)]) {
                        var _0x2817db = new MutationObserver(handleMutations);
                        _0x2817db[_0x3cf15d(0x449)](_0x4974f0[_0x3cf15d(0x266)], {
                            'childList': !![],
                            'subtree': !![]
                        });
                    }
                });
            }));
        }
        globalSettings[_0x10e19f(0x57d)] && invertPdf(), globalSettings[_0x10e19f(0x5e3)] && addDarkMapsCss();
    }, setDarkToolbar = () => {
        var _0x38fcaf = _0x52102f, _0x1c2f07 = {
                'DKlHI': function (_0x481d62, _0xbbcc7a) {
                    return _0x481d62 != _0xbbcc7a;
                },
                'oefgZ': 'meta[name=\x22theme-color\x22]',
                'wGgpI': function (_0x182a2f) {
                    return _0x182a2f();
                },
                'tAjEL': _0x38fcaf(0x6b1),
                'wTtvG': _0x38fcaf(0x363),
                'gBhsn': 'content',
                'lurkD': _0x38fcaf(0x4ab),
                'DVeci': _0x38fcaf(0x42a)
            };
        if (_0x1c2f07[_0x38fcaf(0x634)](window['top'], window))
            return;
        if (!document[_0x38fcaf(0x600)])
            return;
        let _0x509539 = document['querySelector'](_0x1c2f07[_0x38fcaf(0x2ff)]), _0x3f7240 = _0x1c2f07[_0x38fcaf(0x283)](getPageColor)['hexString']();
        if (_0x509539) {
            _0x509539[_0x38fcaf(0x4b8)](_0x1c2f07['tAjEL'], _0x1c2f07[_0x38fcaf(0x3ba)]), _0x509539[_0x38fcaf(0x4b8)](_0x1c2f07[_0x38fcaf(0x5a0)], _0x3f7240);
            return;
        }
        _0x509539 = document[_0x38fcaf(0x4f1)](_0x1c2f07[_0x38fcaf(0x307)]), _0x509539[_0x38fcaf(0x4b8)](_0x38fcaf(0x6ab), _0x1c2f07['DVeci']), _0x509539[_0x38fcaf(0x4b8)](_0x1c2f07['tAjEL'], _0x1c2f07['wTtvG']), _0x509539['setAttribute'](_0x38fcaf(0x4de), _0x3f7240), document[_0x38fcaf(0x600)][_0x38fcaf(0x437)](_0x509539);
    }, dimImages = _0x2ca57e => {
        var _0x207eb5 = _0x52102f, _0x47743b = {
                'JlSSt': _0x207eb5(0x251),
                'otPHd': function (_0x334bc8, _0x4e7511) {
                    return _0x334bc8(_0x4e7511);
                },
                'oHRCV': _0x207eb5(0x39b)
            };
        let _0x17d000 = _0x47743b['JlSSt'];
        var _0x29e833 = document[_0x207eb5(0x6a3)](_0x17d000);
        if (_0x29e833 && _0x2ca57e == 0x1)
            return _0x47743b[_0x207eb5(0x15a)](removeStyleWithId, _0x17d000);
        if (!_0x29e833)
            _0x29e833 = document['createElement'](_0x47743b[_0x207eb5(0x58e)]);
        _0x29e833['id'] = _0x17d000, _0x29e833[_0x207eb5(0x217)] = _0x207eb5(0x27e) + _0x2ca57e + _0x207eb5(0x323);
        if (document['head'])
            document[_0x207eb5(0x600)][_0x207eb5(0x437)](_0x29e833);
        else
            document[_0x207eb5(0x286)][_0x207eb5(0x437)](_0x29e833);
    }, addDarkMapsCss = () => {
        var _0x20735c = _0x52102f, _0x1b86b9 = {
                'aeVyU': _0x20735c(0x1dc),
                'ZHHQs': 'style'
            };
        let _0x1788bf = _0x1b86b9[_0x20735c(0x5be)];
        var _0x147d64 = document[_0x20735c(0x6a3)](_0x1788bf);
        if (_0x147d64)
            return;
        _0x147d64 = document['createElement'](_0x1b86b9[_0x20735c(0x66e)]), _0x147d64['id'] = _0x1788bf, _0x147d64[_0x20735c(0x217)] = _0x20735c(0x5a7);
        if (document[_0x20735c(0x600)])
            document[_0x20735c(0x600)][_0x20735c(0x437)](_0x147d64);
        else
            document[_0x20735c(0x286)][_0x20735c(0x437)](_0x147d64);
    }, removeDarkMapCss = () => {
        var _0x119635 = _0x52102f, _0xe13fd8 = {
                'KSeWB': function (_0x343276, _0x5a0b15) {
                    return _0x343276(_0x5a0b15);
                }
            };
        _0xe13fd8[_0x119635(0x505)](removeStyleWithId, 'nitefall_dark_maps');
    }, invertPdf = () => {
        var _0x288199 = _0x52102f, _0x14943b = {
                'KXGwx': _0x288199(0x364),
                'iSyNU': _0x288199(0x39b)
            };
        let _0x4d5b9b = _0x14943b[_0x288199(0x29c)];
        var _0x6dc071 = document['getElementById'](_0x4d5b9b);
        if (_0x6dc071)
            return;
        _0x6dc071 = document[_0x288199(0x4f1)](_0x14943b['iSyNU']), _0x6dc071['id'] = _0x4d5b9b, _0x6dc071[_0x288199(0x217)] = _0x288199(0x611);
        if (document[_0x288199(0x600)])
            document[_0x288199(0x600)][_0x288199(0x437)](_0x6dc071);
        else
            document[_0x288199(0x286)][_0x288199(0x437)](_0x6dc071);
    }, removeInvertedPdfStyle = () => {
        var _0x2956f9 = _0x52102f, _0x197816 = {
                'pedQF': function (_0x561a8e, _0x3dc977) {
                    return _0x561a8e(_0x3dc977);
                },
                'DbwhG': _0x2956f9(0x364)
            };
        _0x197816[_0x2956f9(0x2b6)](removeStyleWithId, _0x197816[_0x2956f9(0x594)]);
    }, invertPng = () => {
        var _0x3b2738 = _0x52102f, _0xdd166c = {
                'JCvfT': 'invert\x20png\x20for\x20',
                'bWSJq': _0x3b2738(0x39b)
            };
        console['log'](_0xdd166c[_0x3b2738(0x5a8)], document[_0x3b2738(0x269)][_0x3b2738(0x378)]);
        let _0xba315f = _0x3b2738(0x561);
        var _0x4a770e = document[_0x3b2738(0x6a3)](_0xba315f);
        if (_0x4a770e)
            return;
        _0x4a770e = document['createElement'](_0xdd166c['bWSJq']), _0x4a770e['id'] = _0xba315f, _0x4a770e[_0x3b2738(0x217)] = _0x3b2738(0x150);
        if (document[_0x3b2738(0x600)])
            document[_0x3b2738(0x600)][_0x3b2738(0x437)](_0x4a770e);
        else
            document['documentElement'][_0x3b2738(0x437)](_0x4a770e);
    }, removeInvertedPngStyle = () => {
        var _0x44a36f = _0x52102f, _0x4ac8f8 = {
                'TRoeo': function (_0x340099, _0x5337a1) {
                    return _0x340099(_0x5337a1);
                },
                'yOOmR': _0x44a36f(0x561)
            };
        _0x4ac8f8[_0x44a36f(0x1e0)](removeStyleWithId, _0x4ac8f8['yOOmR']);
    }, containsAny = (_0x159d02, _0xf96637) => {
        var _0x4015e6 = _0x52102f, _0x2a6e89 = {
                'cfrMQ': function (_0x60d191, _0x3321d6) {
                    return _0x60d191 > _0x3321d6;
                }
            };
        return _0x2a6e89[_0x4015e6(0x32c)](_0xf96637[_0x4015e6(0x55b)](_0x2dc5b4 => _0x159d02[_0x4015e6(0x3ec)]()[_0x4015e6(0x205)](_0x2dc5b4[_0x4015e6(0x3ec)]()))[_0x4015e6(0x362)], 0x0);
    }, extractSVGColors = (_0x4cb8e2, _0x2ef9d5, _0x10ea9b) => {
        var _0x167a45 = _0x52102f, _0x113672 = {
                'ricOI': _0x167a45(0x49c),
                'qbXGf': function (_0x33a4f6, _0xeffd72) {
                    return _0x33a4f6(_0xeffd72);
                },
                'jZaec': function (_0x2cf006, _0x237601) {
                    return _0x2cf006 > _0x237601;
                },
                'pGQZF': function (_0x7eb76e, _0x57bb6e) {
                    return _0x7eb76e(_0x57bb6e);
                },
                'npcQP': function (_0x9a90ec, _0x4fe6f4) {
                    return _0x9a90ec(_0x4fe6f4);
                },
                'oYJiO': _0x167a45(0x557),
                'GOBtP': _0x167a45(0x6b2)
            };
        if (!_0x4cb8e2)
            return _0x10ea9b([]);
        getSVGColors(_0x4cb8e2, { 'flat': !![] })[_0x167a45(0x4bd)](_0x44ada0 => {
            var _0x29ffee = _0x167a45, _0x299ba9 = {
                    'dImtW': function (_0x3a13cf, _0x3f8854) {
                        return _0x3a13cf == _0x3f8854;
                    },
                    'QdUXs': _0x113672[_0x29ffee(0x625)],
                    'AxfLz': function (_0x5232f9, _0x735e66) {
                        return _0x113672['qbXGf'](_0x5232f9, _0x735e66);
                    }
                };
            if (_0x113672['jZaec'](_0x44ada0[_0x29ffee(0x362)], 0x0)) {
                var _0x36a062 = _0x44ada0[_0x29ffee(0x55b)](_0x1be92c => _0x1be92c != 'none')[_0x29ffee(0x22a)](_0x502cbe => {
                    var _0x13c679 = _0x29ffee;
                    if (_0x299ba9[_0x13c679(0x6d9)](_0x502cbe[_0x13c679(0x2f5)]('#'), 0x0))
                        return convertToHex6Digits(_0x502cbe)['toUpperCase']();
                    else
                        return _0x502cbe[_0x13c679(0x205)](_0x299ba9[_0x13c679(0x260)]) ? _0x299ba9[_0x13c679(0x17d)](rgbToHex, _0x502cbe) : namedColorToHex(_0x502cbe);
                });
                _0x113672[_0x29ffee(0x2a4)](_0x10ea9b, _0x36a062);
            } else {
                if (_0x2ef9d5 instanceof SVGElement) {
                    let _0x31dc3a = _0x113672['qbXGf'](getComputedStyle, _0x2ef9d5)[_0x29ffee(0x5a9)];
                    if (_0x31dc3a) {
                        if (_0x31dc3a[_0x29ffee(0x205)](_0x113672[_0x29ffee(0x625)]))
                            return _0x113672[_0x29ffee(0x5f2)](_0x10ea9b, [rgbToHex(_0x31dc3a)[_0x29ffee(0x481)]()]);
                        else
                            return _0x10ea9b([_0x31dc3a]);
                    }
                }
                return _0x113672[_0x29ffee(0x5a2)](_0x10ea9b, [_0x113672[_0x29ffee(0x592)]]);
            }
        })[_0x167a45(0x3f5)](_0x1ce0c6 => {
            var _0x4c2b85 = _0x167a45;
            console[_0x4c2b85(0x27f)](_0x113672['GOBtP'], _0x1ce0c6[_0x4c2b85(0x610)]), _0x10ea9b([]);
        });
    }, classifySVGAsDark = (_0x270e37, _0x5f14f6) => {
        var _0x44c921 = _0x52102f, _0x2b3691 = {
                'lBUtI': function (_0x46ae34, _0x2b8830) {
                    return _0x46ae34 == _0x2b8830;
                },
                'nNfdJ': function (_0x5aa1ab, _0x2cb067) {
                    return _0x5aa1ab(_0x2cb067);
                },
                'USxFW': 'nitefall_imageType',
                'VFnKB': 'svg',
                'Veqoi': _0x44c921(0x637),
                'sZCzn': _0x44c921(0x268),
                'sXhOP': 'url(',
                'OzYlc': function (_0x5e72da, _0x674c96) {
                    return _0x5e72da instanceof _0x674c96;
                },
                'mSilh': function (_0x1102ea, _0x47641b, _0x41c247, _0x5cde77) {
                    return _0x1102ea(_0x47641b, _0x41c247, _0x5cde77);
                }
            };
        if (_0x2b3691[_0x44c921(0x586)](isElementBlacklisted, _0x270e37))
            return;
        if (typeof _0x5f14f6 != _0x2b3691[_0x44c921(0x588)])
            _0x5f14f6 = null;
        if (_0x5f14f6) {
            if (_0x5f14f6[_0x44c921(0x6b6)](_0x2b3691['sZCzn'])) {
                var _0x29c698 = _0x5f14f6[_0x44c921(0x2f5)](_0x2b3691[_0x44c921(0x45c)]);
                if (_0x29c698 > -0x1)
                    _0x5f14f6 = _0x5f14f6[_0x44c921(0x443)](_0x29c698);
            }
            if (_0x5f14f6[_0x44c921(0x6b6)](_0x2b3691[_0x44c921(0x45c)])) {
                var _0x29c698 = _0x5f14f6[_0x44c921(0x2f5)](_0x44c921(0x4af));
                if (_0x29c698 > -0x1)
                    _0x5f14f6 = _0x5f14f6['substr'](_0x29c698);
                _0x5f14f6 = _0x5f14f6[_0x44c921(0x16b)](/\((.*?)\)/)[0x1][_0x44c921(0x468)](/('|")/g, '');
            }
        }
        let _0x52b4c2 = _0x2b3691['OzYlc'](_0x270e37, SVGElement);
        _0x2b3691[_0x44c921(0x219)](extractSVGColors, _0x5f14f6, _0x52b4c2 ? _0x270e37 : null, _0x4aa902 => {
            var _0xfb1f89 = _0x44c921;
            if (_0x2b3691[_0xfb1f89(0x4ff)](_0x4aa902[_0xfb1f89(0x362)], 0x1)) {
                if (!_0x2b3691[_0xfb1f89(0x586)](NFColorFromHexString, _0x4aa902[0x0])['isLight']())
                    _0x270e37[_0xfb1f89(0x4b8)](_0x2b3691[_0xfb1f89(0x1be)], _0x2b3691[_0xfb1f89(0x41c)]);
            }
        });
    }, detectElementWithBackgroundImages = _0x15a02f => {
        var _0x6f225b = _0x52102f, _0xd8441a = {
                'uVbuw': 'background-image',
                'AFPOt': function (_0xfc8772, _0x29b10c) {
                    return _0xfc8772 == _0x29b10c;
                },
                'MsYeI': _0x6f225b(0x20a),
                'LIiev': _0x6f225b(0x1ef),
                'BONfn': _0x6f225b(0x384),
                'AvlLw': function (_0x4621a2, _0x121982) {
                    return _0x4621a2 != _0x121982;
                },
                'tEDMA': function (_0x21a2d6, _0x3185b8, _0x214518) {
                    return _0x21a2d6(_0x3185b8, _0x214518);
                },
                'PVdcl': _0x6f225b(0x252),
                'IWdfq': _0x6f225b(0x46d),
                'nHGdi': _0x6f225b(0x3df),
                'ifSdK': function (_0x20a02a, _0xaa36de, _0x3727e8) {
                    return _0x20a02a(_0xaa36de, _0x3727e8);
                },
                'LIQrJ': _0x6f225b(0x5b7),
                'LxbQz': function (_0x552672, _0x2c08f8, _0x47e035) {
                    return _0x552672(_0x2c08f8, _0x47e035);
                },
                'VTagT': 'data:image/jpeg',
                'Ppovy': '.jpg',
                'StfDU': _0x6f225b(0x662),
                'tHOnh': _0x6f225b(0x677),
                'IYgDS': _0x6f225b(0x2a9),
                'ADTVd': '.SVG',
                'DZitr': _0x6f225b(0x2f0)
            }, _0x1956ac = window[_0x6f225b(0x527)](_0x15a02f)[_0xd8441a[_0x6f225b(0x158)]];
        let _0x34af7c = ![];
        if (_0xd8441a['AFPOt'](_0x1956ac, _0xd8441a['MsYeI'])) {
            _0x1956ac = window[_0x6f225b(0x527)](_0x15a02f, _0xd8441a[_0x6f225b(0x325)])[_0xd8441a['uVbuw']];
            if (_0x1956ac == _0xd8441a[_0x6f225b(0x3a2)])
                _0x1956ac = window['getComputedStyle'](_0x15a02f, _0xd8441a[_0x6f225b(0x203)])[_0xd8441a[_0x6f225b(0x158)]];
            _0x34af7c = _0xd8441a['AvlLw'](_0x1956ac, _0xd8441a[_0x6f225b(0x3a2)]);
        }
        if (_0xd8441a[_0x6f225b(0x67f)](_0x1956ac, _0xd8441a[_0x6f225b(0x3a2)]))
            return;
        var _0x4d9ea0;
        if (_0xd8441a[_0x6f225b(0x256)](containsAny, _0x1956ac, [
                'data:image/png',
                _0xd8441a[_0x6f225b(0x228)],
                _0xd8441a[_0x6f225b(0x528)]
            ]))
            _0x4d9ea0 = _0xd8441a['nHGdi'];
        else {
            if (_0xd8441a[_0x6f225b(0x5b2)](containsAny, _0x1956ac, [
                    '.gif',
                    _0x6f225b(0x4e1)
                ]))
                _0x4d9ea0 = _0xd8441a[_0x6f225b(0x271)];
            else {
                if (_0xd8441a[_0x6f225b(0x5b3)](containsAny, _0x1956ac, [
                        _0xd8441a[_0x6f225b(0x2f7)],
                        _0xd8441a[_0x6f225b(0x3b1)],
                        _0xd8441a['StfDU'],
                        _0x6f225b(0x450),
                        _0xd8441a[_0x6f225b(0x250)]
                    ]))
                    _0x4d9ea0 = _0xd8441a[_0x6f225b(0x171)];
                else {
                    if (!_0x34af7c && containsAny(_0x1956ac, [
                            _0x6f225b(0x4d9),
                            _0xd8441a[_0x6f225b(0x42c)],
                            'data:image/svg+xml'
                        ]))
                        classifySVGAsDark(_0x15a02f, _0x1956ac);
                    else
                        _0xd8441a[_0x6f225b(0x5b3)](containsAny, _0x1956ac, [
                            _0x6f225b(0x335),
                            _0x6f225b(0x2d6)
                        ]) && (_0x4d9ea0 = 'unknown');
                }
            }
        }
        _0x4d9ea0 ? _0x15a02f[_0x6f225b(0x4b8)](_0xd8441a[_0x6f225b(0x442)], _0x4d9ea0) : _0x15a02f[_0x6f225b(0x2d9)](_0xd8441a[_0x6f225b(0x442)]);
    }, DOMContentLoaded = () => {
        var _0x5ba5e5 = _0x52102f, _0x493599 = {
                'KyFUz': function (_0x582c20) {
                    return _0x582c20();
                }
            };
        if (hasProcessedPage)
            return;
        _0x493599[_0x5ba5e5(0x51b)](onPageLoadedForNitefall), document[_0x5ba5e5(0x49b)](_0x5ba5e5(0x514), DOMContentLoaded), hasProcessedPage = !![];
    }, getExtensionSettings = _0x58fdef => {
        var _0x4e8446 = _0x52102f, _0x5ace69 = {
                'GRVsv': function (_0x37e9d5, _0x43ce3b) {
                    return _0x37e9d5(_0x43ce3b);
                },
                'Npkgc': function (_0x20d520) {
                    return _0x20d520();
                }
            };
        getSettings(_0x5ace69[_0x4e8446(0x3a3)](getHost))[_0x4e8446(0x4bd)](_0x56448d => {
            var _0x329810 = _0x4e8446;
            _0x5ace69[_0x329810(0x1c6)](_0x58fdef, _0x56448d);
        });
    }, removeStartWorkAround = () => {
        var _0x2c42b5 = _0x52102f, _0x1b2161 = {
                'XQOvM': function (_0x328fee, _0x359d94) {
                    return _0x328fee(_0x359d94);
                }
            };
        _0x1b2161[_0x2c42b5(0x4cc)](removeStyleWithId, NITEFALL_START_WORKAROUND_CSS_ID);
    }, isNitefallActive = () => {
        var _0x2e1fd7 = _0x52102f;
        if (!document[_0x2e1fd7(0x286)])
            return JSON[_0x2e1fd7(0x5a6)]({ 'active': ![] });
        return JSON[_0x2e1fd7(0x5a6)]({ 'active': document[_0x2e1fd7(0x286)][_0x2e1fd7(0x29e)](_0x2e1fd7(0x3da)) });
    }, isSystemDarkModeOn = () => {
        var _0x3a83cc = _0x52102f, _0x58ca1b = {
                'osQzj': 'Cydia/',
                'Vpuyt': 'Zebra/',
                'JOQnk': _0x3a83cc(0x363)
            };
        if (navigator[_0x3a83cc(0x411)][_0x3a83cc(0x205)](_0x58ca1b['osQzj']) && !navigator[_0x3a83cc(0x411)][_0x3a83cc(0x205)](_0x58ca1b[_0x3a83cc(0x3b6)]))
            return !![];
        return window[_0x3a83cc(0x3e5)](_0x58ca1b[_0x3a83cc(0x55c)])['matches'];
    }, getHost = () => {
        var _0x4a1b0e = _0x52102f, _0x22791d = {
                'XaGGt': 'file:///private/var/mobile/Containers/',
                'FBAtc': function (_0x16fa84, _0xa5b33d) {
                    return _0x16fa84 != _0xa5b33d;
                },
                'UDvUz': _0x4a1b0e(0x166),
                'ugpuz': _0x4a1b0e(0x541)
            };
        let _0x5ca1f8 = document[_0x4a1b0e(0x269)][_0x4a1b0e(0x191)]['includes'](_0x4a1b0e(0x4c9));
        if (_0x5ca1f8)
            return 'com.apple.email.maild';
        if (document[_0x4a1b0e(0x269)][_0x4a1b0e(0x191)][_0x4a1b0e(0x205)](_0x22791d[_0x4a1b0e(0x579)]))
            return _0x4a1b0e(0x3fc);
        let _0x194180 = !document[_0x4a1b0e(0x269)][_0x4a1b0e(0x378)][_0x4a1b0e(0x362)] && _0x22791d[_0x4a1b0e(0x247)](document[_0x4a1b0e(0x2d1)](_0x22791d['UDvUz']), null);
        if (_0x194180)
            return _0x22791d[_0x4a1b0e(0x3e4)];
        return document['location'][_0x4a1b0e(0x378)][_0x4a1b0e(0x523)](':')[0x0];
    }, initNitefall = () => {
        var _0x1c103c = _0x52102f, _0x31656f = {
                'ebsDM': function (_0x324e9a, _0x3a861f) {
                    return _0x324e9a == _0x3a861f;
                },
                'kZQdE': _0x1c103c(0x60e),
                'mlYCo': function (_0x2cfba8) {
                    return _0x2cfba8();
                },
                'JFmBJ': function (_0x28b701, _0x4303f8) {
                    return _0x28b701 == _0x4303f8;
                },
                'lkUTd': _0x1c103c(0x601),
                'CjAXL': function (_0xfd7a36) {
                    return _0xfd7a36();
                },
                'Umwae': 'important',
                'OWbri': function (_0x1a1baa, _0x1cd2c4) {
                    return _0x1a1baa(_0x1cd2c4);
                },
                'YxRAt': '(prefers-color-scheme:\x20dark)',
                'rETld': function (_0x111a8b) {
                    return _0x111a8b();
                },
                'pPMTX': function (_0x4e8ac6) {
                    return _0x4e8ac6();
                },
                'XQlJG': function (_0x2b6a1f, _0x283aa4) {
                    return _0x2b6a1f !== _0x283aa4;
                },
                'iTHkl': _0x1c103c(0x63a),
                'nfWDc': _0x1c103c(0x514),
                'IbQMJ': function (_0x4c49b8, _0x5efaf1) {
                    return _0x4c49b8(_0x5efaf1);
                }
            };
        try {
            _0x31656f[_0x1c103c(0x26f)](getExtensionSettings, _0x17f933 => {
                var _0x3698ca = _0x1c103c, _0x121c55 = {
                        'oynnR': function (_0x612ecd) {
                            var _0x6332c6 = _0x3451;
                            return _0x31656f[_0x6332c6(0x461)](_0x612ecd);
                        }
                    };
                globalSettings = _0x17f933, currentTheme = _0x17f933[_0x3698ca(0x293)];
                if (!_0x17f933[_0x3698ca(0x684)]) {
                    _0x31656f[_0x3698ca(0x461)](removeStartWorkAround);
                    return;
                }
                for (styleSheet of document[_0x3698ca(0x213)]) {
                    var _0x374582 = styleSheet['ownerNode']['id'];
                    if (_0x374582 && _0x31656f[_0x3698ca(0x4ef)](_0x374582, NITEFALL_START_WORKAROUND_CSS_ID)) {
                        var _0x195d7f = styleSheet[_0x3698ca(0x3d5)]['item'](0x0);
                        _0x195d7f && _0x195d7f['style'][_0x3698ca(0x6c4)](_0x31656f[_0x3698ca(0x2be)], _0x31656f[_0x3698ca(0x5d8)](getPageColor)[_0x3698ca(0x50e)](), _0x31656f[_0x3698ca(0x412)]);
                    }
                }
                if (_0x31656f[_0x3698ca(0x686)](isAllowedToUseExtension, _0x17f933)) {
                    var _0x3540a3 = window[_0x3698ca(0x3e5)](_0x31656f[_0x3698ca(0x58c)]);
                    _0x3540a3[_0x3698ca(0x31c)](_0x4ef5a0 => {
                        getExtensionSettings(_0x39988a => {
                            var _0x3ac2fa = _0x3451, _0x2299a3 = _0x39988a[getHost()];
                            if (!_0x39988a['enabled'] || !_0x2299a3[_0x3ac2fa(0x1e5)])
                                return;
                            var _0x400a27 = window['matchMedia'](_0x3ac2fa(0x363))[_0x3ac2fa(0x6da)];
                            _0x400a27 ? _0x121c55[_0x3ac2fa(0x1b1)](onPageLoadedForNitefall) : removeAllCss();
                        });
                    });
                }
                var _0x582d96 = _0x31656f['CjAXL'](getHost), _0x240f79 = _0x17f933[_0x582d96];
                if (!_0x240f79) {
                    _0x31656f[_0x3698ca(0x5d8)](removeStartWorkAround);
                    return;
                }
                if (!_0x240f79[_0x3698ca(0x1e5)]) {
                    _0x31656f[_0x3698ca(0x639)](removeStartWorkAround);
                    return;
                }
                if (!_0x31656f[_0x3698ca(0x2f9)](isSystemDarkModeOn)) {
                    _0x31656f[_0x3698ca(0x2f9)](removeStartWorkAround);
                    return;
                }
                window != window[_0x3698ca(0x34d)] && window['addEventListener']('message', _0x4b1e9b => {
                    var _0x4b7aca = _0x3698ca;
                    if (_0x31656f['ebsDM'](_0x4b1e9b[_0x4b7aca(0x42b)], _0x31656f['kZQdE']) && window[_0x4b7aca(0x3da)])
                        window[_0x4b7aca(0x3da)]['disableTemporarily']();
                });
                if (window[_0x3698ca(0x3da)]) {
                    _0x31656f[_0x3698ca(0x2f9)](removeStartWorkAround);
                    return;
                }
                _0x31656f[_0x3698ca(0x194)](document[_0x3698ca(0x4cb)], _0x31656f[_0x3698ca(0x4f3)]) ? (onPageLoadedForNitefall(), hasProcessedPage = !![]) : document[_0x3698ca(0x3cd)](_0x31656f[_0x3698ca(0x644)], DOMContentLoaded), window['nitefall'] = {
                    'disableTemporarily': removeAllCss,
                    'dimImages': dimImages,
                    'invertPng': invertPng,
                    'isNitefallActive': isNitefallActive
                };
            });
        } catch (_0x34cf2f) {
            console['error'](_0x34cf2f);
        }
    };
let isMailComposePage = document[_0x52102f(0x269)][_0x52102f(0x191)][_0x52102f(0x205)](_0x52102f(0x5f4));
function _0x3451(_0x43a17e, _0x3e96ef) {
    var _0x12c62c = _0x12c6();
    return _0x3451 = function (_0x345189, _0x3366a5) {
        _0x345189 = _0x345189 - 0x144;
        var _0x15a307 = _0x12c62c[_0x345189];
        return _0x15a307;
    }, _0x3451(_0x43a17e, _0x3e96ef);
}
if (!isMailComposePage) {
    var isSystemInDarkMode = isSystemDarkModeOn();
    if (getHost() == _0x52102f(0x518) && document['documentElement']) {
        if (isSystemInDarkMode)
            document[_0x52102f(0x286)][_0x52102f(0x39b)][_0x52102f(0x24f)] = getPageColor()[_0x52102f(0x50e)]();
    } else {
        if (document['head'] || document[_0x52102f(0x286)]) {
            var SzYwSY = _0x52102f(0x253)[_0x52102f(0x523)]('|'), RGyVeO = 0x0;
            while (!![]) {
                switch (SzYwSY[RGyVeO++]) {
                case '0':
                    if (document[_0x52102f(0x600)])
                        document[_0x52102f(0x600)]['appendChild'](styleTag);
                    else
                        document[_0x52102f(0x286)][_0x52102f(0x437)](styleTag);
                    continue;
                case '1':
                    styleTag[_0x52102f(0x217)] = '\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/*\x20the\x20*\x20background\x20color\x20rule\x20has\x20to\x20be\x20first\x20because\x20it\x20will\x20updated\x20to\x20real\x20page\x20color\x20as\x20soon\x20we\x20fetch\x20the\x20settings\x20*/\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20*\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20' + bgColor + _0x52102f(0x6a8) + bgColor + _0x52102f(0x3ce);
                    continue;
                case '2':
                    styleTag['id'] = NITEFALL_START_WORKAROUND_CSS_ID;
                    continue;
                case '3':
                    var bgColor = isSystemInDarkMode ? getPageColor()['rgbString']() : _0x52102f(0x4dd);
                    continue;
                case '4':
                    var styleTag = document['createElement']('style');
                    continue;
                }
                break;
            }
        }
    }
    initNitefall();
}